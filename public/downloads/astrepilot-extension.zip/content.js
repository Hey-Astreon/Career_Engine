/**
 * StridePilot Content Script (Manifest V3)
 * ---------------------------------------
 * Injected on web pages to scan form fields, render the glassmorphic HUD,
 * and execute AI-powered autofill animations.
 */

(function () {
  'use strict';

  // Prevent multiple injections: tear down any previous instance (listeners + HUD)
  if (window.__STRIDEPILOT_CLEANUP__) {
    try { window.__STRIDEPILOT_CLEANUP__(); } catch (e) {}
  }
  if (window.__ASTREPILOT_CLEANUP__) {
    try { window.__ASTREPILOT_CLEANUP__(); } catch (e) {}
  }
  window.__STRIDEPILOT_INJECTED__ = true;
  window.__ASTREPILOT_INJECTED__ = true;

  let activeHud = null;
  let detectedFields = [];
  let userProfile = null;
  let activeSession = null;
  let mountPromise = null; // set while the HUD is initialising (prevents double mounts)
  let isFilling = false;  // re-entrancy guard for runAutofill
  let fillHeartbeatTimer = null; // heartbeat timer for active fill locks
  let lastFormFingerprint = null; // AstrePilot V3 Form Fingerprint Cache Key
  let cachedSchemaMappings = null; // AstrePilot V3 Schema Cache Mappings
  let cachedLiveJd = null;

  async function checkFormSchemaCache(fingerprint) {
    if (!fingerprint) return null;
    try {
      const res = await apFetch('/schema-cache?fingerprint=' + encodeURIComponent(fingerprint));
      if (res.ok) {
        const data = await res.json();
        if (data && data.cached && data.schema && Array.isArray(data.schema.mappings)) {
          cachedSchemaMappings = data.schema.mappings;
          return cachedSchemaMappings;
        }
      }
    } catch (e) {}
    return null;
  }

  function getCachedLiveJD() {
    if (cachedLiveJd) return cachedLiveJd;
    try {
      if (typeof extractPageContent === 'function') {
        const data = extractPageContent();
        if (data && data.pageText && data.pageText.length > 80) {
          cachedLiveJd = data.pageText.slice(0, 15000);
          return cachedLiveJd;
        }
      }
    } catch (e) {}
    return '';
  }

  function generateBrowserFormFingerprint(inputs) {
    if (!inputs || inputs.length === 0) return null;
    let str = '';
    for (let i = 0; i < inputs.length; i++) {
      const inp = inputs[i];
      const tag = inp.tagName || 'INPUT';
      const type = inp.type || '';
      const name = (inp.name || '').replace(/[0-9]+/g, '#');
      const id = (inp.id || '').replace(/[0-9]+/g, '#');
      str += tag + '|' + type + '|' + name + '|' + id + ';';
    }
    let hash = 2166136261;
    for (let i = 0; i < str.length; i++) {
      hash ^= str.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return 'fp_' + (hash >>> 0).toString(16);
  }

  // Autonomous Standalone / Offline Profiles (BCA Candidate Title Compliant)
  const STANDALONE_PROFILES = {
    roushan: {
      firstName: 'Roushan',
      lastName: 'Kumar',
      fullName: 'Roushan Kumar',
      preferredName: 'Roushan',
      email: 'roushanraut404@gmail.com',
      phone: '+919431483512',
      phoneType: 'Mobile',
      title: 'Software Developer — Backend & Cloud',
      location: 'Patna, Bihar, India',
      preferredLocation: 'Remote',
      workplacePreference: 'Remote',
      city: 'Patna',
      state: 'Bihar',
      country: 'India',
      streetAddress: 'Indrapuri, North Patel Nagar',
      zipCode: '800024',
      addressType: 'Home',
      linkedinUrl: 'https://linkedin.com/in/astreon4547',
      githubUrl: 'https://github.com/Hey-Astreon',
      portfolioUrl: 'https://astreon.me',
      school: 'Amity University',
      degree: 'Bachelor of Computer Applications (BCA)',
      discipline: 'Computer Science',
      highestEducation: 'Bachelor of Computer Applications (BCA)',
      startMonth: 'July',
      startYear: '2025',
      endMonth: 'July',
      endYear: '2028',
      graduationYear: '2028',
      currentRole: true,
      workAuthorized: true,
      requiresVisa: true,
      is18OrOlder: 'Yes',
      gender: 'Male',
      pronouns: 'He/Him',
      hispanicLatino: 'No',
      veteranStatus: 'I am not a protected veteran',
      disabilityStatus: "No, I don't have a disability",
      race: 'Asian',
      company: 'Stride',
      employmentTitle: 'Creator & Lead Backend Developer',
      noticePeriod: 'Immediate',
      willingnessToRelocate: true,
      languages: 'English, Hindi',
      privacyConsent: 'Confirmed',
      aiConsent: 'Yes',
      aiUsage: 'regularly use AI tools and developer copilots',
      professionalSummary: 'Software Developer focused on backend systems, distributed data pipelines, and cloud infrastructure. Architected and operate Stride on Oracle Cloud (OCI ARM64), utilizing Dockerized background workers, Turso SQLite, and Redis caching to orchestrate high-throughput distributed workflows. Also shipped an AST code-graph analysis sandbox with sub-200ms execution and a client-side AES-256-GCM password vault.',
      slug: 'roushan',
      token: 'eyJ1aWQiOiJjYTBkNDQyYi0yNjg5LTRlYjMtYjQzZS02OTQzOGI3YjlkZWIiLCJleHAiOjE4MDAzMDE3Mjg3Nzd9.7ZEI2esQ6tghubLS1yHMmDs_a9ODwJmN5PhC09v-2bs',
      _isStandalone: true
    },
    ayushi: {
      firstName: 'Ayushi',
      lastName: 'Raj',
      fullName: 'Ayushi Raj',
      preferredName: 'Ayushi',
      email: 'ayushi29507@gmail.com',
      phone: '+918709852305',
      phoneType: 'Mobile',
      title: 'Software Developer — Full-Stack & AI',
      location: 'Nawada, Bihar, India',
      preferredLocation: 'Remote',
      workplacePreference: 'Remote',
      city: 'Nawada',
      state: 'Bihar',
      country: 'India',
      streetAddress: 'Mirzapur, Nawada, Bihar',
      zipCode: '805110',
      addressType: 'Home',
      linkedinUrl: 'https://www.linkedin.com/in/alrya404/',
      githubUrl: 'https://github.com/Silenttears-cloud',
      portfolioUrl: 'https://ayushiraj.me',
      slug: 'ayushi',
      school: 'Amity University',
      degree: 'Bachelor of Computer Applications (BCA)',
      discipline: 'Computer Science',
      highestEducation: 'Bachelor of Computer Applications (BCA)',
      startMonth: 'July',
      startYear: '2025',
      endMonth: 'July',
      endYear: '2028',
      graduationYear: '2028',
      currentRole: true,
      workAuthorized: true,
      requiresVisa: false,
      is18OrOlder: 'Yes',
      gender: 'Female',
      pronouns: 'She/Her',
      hispanicLatino: 'No',
      veteranStatus: 'I am not a protected veteran',
      disabilityStatus: "No, I don't have a disability",
      race: 'Asian',
      company: 'Stride',
      employmentTitle: 'Co-Developer & Lead Frontend Architect',
      noticePeriod: 'Immediate',
      willingnessToRelocate: true,
      languages: 'English, Hindi',
      privacyConsent: 'Confirmed',
      aiConsent: 'Yes',
      aiUsage: 'regularly use AI tools and developer copilots',
      professionalSummary: 'Full-Stack Software Developer building React 19, Next.js, TypeScript, and AI-powered web applications. Co-developed Stride and the StridePilot Chrome Extension (MV3), designing the 6-stage Shadow DOM autofill HUD, real-time ATS resume canvas, and multi-LLM routing layer across Gemini and Groq. Also built the interactive React Flow graph explorer for Astra Vision and the PBKDF2 zero-knowledge vault interface for Alyra Lock.',
      _isStandalone: true
    }
  };

  function isValidProfile(p) {
    return !!(p && typeof p === 'object' && !p.error && (p.firstName || p.fullName) && p.email);
  }

  // Pillar E: Cross-Tab Broadcast Channel & Message Bus
  let syncChannel = null;
  let syncChannel2 = null;
  try {
    if (typeof BroadcastChannel !== 'undefined') {
      syncChannel = new BroadcastChannel('stridepilot_application_sync');
      syncChannel2 = new BroadcastChannel('astrepilot_application_sync');
      const onSyncMsg = (event) => {
        const msg = event && event.data;
        if (!msg) return;
        handleCrossTabSyncMessage(msg);
      };
      syncChannel.onmessage = onSyncMsg;
      syncChannel2.onmessage = onSyncMsg;
    }
  } catch (e) {
    /* BroadcastChannel fallback */
  }

  function broadcastSync(payload) {
    try { if (syncChannel) syncChannel.postMessage(payload); } catch (e) {}
    try { if (syncChannel2) syncChannel2.postMessage(payload); } catch (e) {}
  }

  function handleCrossTabSyncMessage(msg) {
    if (!msg || !msg.type) return;
    if (msg.type === 'FILL_LOCK_ACQUIRED') {
      const payload = msg.payload || {};
      const currentUrl = (window.location.href || '').toLowerCase();
      const lockUrl = (payload.url || '').toLowerCase();
      if (lockUrl && currentUrl.includes(lockUrl) && activeHud) {
        activeHud.setRemoteLock(payload);
      }
    } else if (msg.type === 'FILL_LOCK_RELEASED') {
      if (activeHud) {
        activeHud.clearRemoteLock();
      }
    } else if (msg.type === 'APPLICATION_CONFIRMED') {
      const payload = msg.payload || {};
      const currentUrl = (window.location.href || '').toLowerCase();
      const confirmedUrl = (payload.siteUrl || '').toLowerCase();
      if (confirmedUrl && currentUrl.includes(confirmedUrl) && activeHud) {
        activeHud.setState('done', { isConfirmed: true });
      }
    }
  }

  async function acquireFillLock(force = false) {
    return new Promise((resolve) => {
      const timer = setTimeout(() => resolve({ success: true }), 400);
      try {
        if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
          clearTimeout(timer);
          return resolve({ success: true });
        }
        chrome.runtime.sendMessage({
          type: 'ACQUIRE_FILL_LOCK',
          url: window.location.href,
          company: activeSession ? activeSession.company : document.title.replace(/ \|.*/, '').trim().slice(0, 80),
          jobTitle: activeSession ? activeSession.jobTitle : '',
          ttlMs: 45000,
          force: force
        }, (res) => {
          clearTimeout(timer);
          resolve(res || { success: true });
        });
      } catch (e) {
        clearTimeout(timer);
        resolve({ success: true });
      }
    });
  }

  function startFillHeartbeat() {
    if (fillHeartbeatTimer) clearInterval(fillHeartbeatTimer);
    fillHeartbeatTimer = setInterval(() => {
      try {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
          chrome.runtime.sendMessage({
            type: 'HEARTBEAT_FILL_LOCK',
            url: window.location.href,
            ttlMs: 45000
          });
        }
      } catch (e) {}
    }, 10000);
  }

  function releaseFillLock() {
    if (fillHeartbeatTimer) {
      clearInterval(fillHeartbeatTimer);
      fillHeartbeatTimer = null;
    }
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({
          type: 'RELEASE_FILL_LOCK',
          url: window.location.href
        }, () => {});
      }
    } catch (e) {}
    broadcastSync({
      type: 'FILL_LOCK_RELEASED',
      timestamp: Date.now(),
      payload: { url: window.location.href }
    });
  }

  /* -- PILLAR F: CDP HARDWARE INPUT BRIDGE -- */
  function cdpInput(action, params = {}) {
    return new Promise((resolve) => {
      try {
        if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
          return resolve({ success: false, error: 'Extension runtime unavailable' });
        }
        chrome.runtime.sendMessage({
          type: 'CDP_DISPATCH_INPUT',
          action,
          ...params
        }, (res) => {
          if (chrome.runtime.lastError) {
            return resolve({ success: false, error: chrome.runtime.lastError.message });
          }
          resolve(res || { success: true });
        });
      } catch (e) {
        resolve({ success: false, error: e.message });
      }
    });
  }

  /* -- MESSAGE LISTENER -- */
  // All responses are synchronous, so the channel is not kept open.
  const messageListener = (request, sender, sendResponse) => {
    // Top-level window guard: subframes (tracking pixels, analytics, recaptcha) must ignore HUD/page actions
    if (window !== window.top && (
      request.action === 'TOGGLE_HUD' ||
      request.action === 'SCAN_FIELDS' ||
      request.action === 'AUTOFILL' ||
      request.action === 'DOWNLOAD_RESUME' ||
      request.action === 'EXTRACT_PAGE' ||
      request.action === 'CLICK_APPLY'
    )) {
      return false;
    }

    if (request.action === 'TOGGLE_HUD') {
      toggleAstrePilotHUD();
      sendResponse({ status: 'toggled' });
    } else if (request.action === 'SCAN_FIELDS') {
      const fields = scanFields();
      sendResponse({ count: fields.length, fields: fields.map(f => ({ type: f.type, id: f.id })) });
    } else if (request.action === 'AUTOFILL') {
      // Ensure HUD is open, wait for scan/profile loading to finish, then immediately run autofill
      (async () => {
        try {
          if (!activeHud) {
            await toggleAstrePilotHUD();
          }
          if (mountPromise) {
            await mountPromise;
          }
          await new Promise(r => setTimeout(r, 120));
          await runAutofill();
        } catch (err) {
          console.error('[AstrePilot] AUTOFILL handler error:', err);
        }
      })();
      sendResponse({ status: 'autofilling' });
    } else if (request.action === 'DOWNLOAD_RESUME') {
      runDownloadResume()
        .then(() => sendResponse({ status: 'downloaded' }))
        .catch(err => sendResponse({ status: 'error', error: err.message }));
      return true;
    } else if (request.action === 'EXTRACT_PAGE') {
      sendResponse(extractPageContent());
    } else if (request.action === 'CLICK_APPLY') {
      sendResponse({ success: findAndClickApplyButton() });
    } else if (request.type === 'FILL_LOCK_ACQUIRED' || request.type === 'FILL_LOCK_RELEASED' || request.type === 'APPLICATION_CONFIRMED') {
      handleCrossTabSyncMessage(request);
      sendResponse({ status: 'handled' });
    }
    return false;
  };
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    try { chrome.runtime.onMessage.addListener(messageListener); } catch (e) {}
  }

  let childFrameSource = null;
  let childFrameOrigin = null;

  // Window message bus for Cross-Origin Subframe coordination (Pillar 1)
  const windowMessageListener = (event) => {
    if (!event || !event.data || typeof event.data !== 'object') return;

    // A. Top-level window receiving telemetry from a child application iframe
    if (window === window.top) {
      if (event.data.type === 'ASTREPILOT_CHILD_FRAME_FIELDS') {
        childFrameSource = event.source;
        childFrameOrigin = event.origin;
        if (event.data.fields && event.data.fields.length > 0) {
          if (!detectedFields || detectedFields.length === 0) {
            detectedFields = event.data.fields;
            if (activeHud) {
              activeHud.setDetectedFields(event.data.fields);
            }
          }
        }
      } else if (event.data.type === 'ASTREPILOT_CHILD_ROW_UPDATE') {
        if (activeHud) {
          activeHud.markRow(event.data.id, event.data.status, event.data.preview);
        }
      } else if (event.data.type === 'ASTREPILOT_CHILD_STATE_UPDATE') {
        if (activeHud) {
          activeHud.setState(event.data.state, event.data.data);
        }
      }
    }

    // B. Subframe window receiving execution triggers from Top-level HUD
    if (window !== window.top) {
      if (event.data.type === 'ASTREPILOT_CHILD_TRIGGER_AUTOFILL') {
        if (event.data.profile) userProfile = event.data.profile;
        if (event.data.session) activeSession = event.data.session;

        const proxyHud = {
          setState: (st, d) => {
            try { window.top.postMessage({ type: 'ASTREPILOT_CHILD_STATE_UPDATE', state: st, data: d }, '*'); } catch (e) {}
          },
          markRow: (id, st, p) => {
            try { window.top.postMessage({ type: 'ASTREPILOT_CHILD_ROW_UPDATE', id, status: st, preview: p }, '*'); } catch (e) {}
          }
        };

        (async () => {
          if (!detectedFields || !detectedFields.length) {
            detectedFields = scanFields();
          }
          if (detectedFields && detectedFields.length > 0) {
            await fillAllFields(proxyHud);
          }
        })();
      }
    }
  };
  window.addEventListener('message', windowMessageListener);

  // If running in subframe, announce fields to top-level window after DOM idle
  if (window !== window.top) {
    setTimeout(() => {
      try {
        const inputs = document.querySelectorAll('input:not([type="hidden"]), select, textarea');
        if (inputs.length >= 2) {
          const frameFields = scanFields();
          if (frameFields && frameFields.length > 0) {
            window.top.postMessage({
              type: 'ASTREPILOT_CHILD_FRAME_FIELDS',
              fields: frameFields.map(f => ({ type: f.type, id: f.id }))
            }, '*');
          }
        }
      } catch (e) {}
    }, 400);
  }

  window.__ASTREPILOT_CLEANUP__ = () => {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
      try { chrome.runtime.onMessage.removeListener(messageListener); } catch (e) {}
    }
    window.removeEventListener('message', windowMessageListener);
    if (syncChannel) {
      try { syncChannel.close(); } catch (e) {}
      syncChannel = null;
    }
    if (fillHeartbeatTimer) {
      clearInterval(fillHeartbeatTimer);
      fillHeartbeatTimer = null;
    }
    if (activeHud) { try { activeHud.destroy(); } catch (e) {} activeHud = null; }
  };

  /* -- IN-PAGE KEYBOARD SHORTCUT LISTENER -- */
  // Shortcut: Alt+Shift+A (primary), Alt+A when not in a text field (secondary)
  // Note: On Windows, Alt+Shift may be consumed by IME/language switcher.
  // The extension command in manifest.json also triggers this via background.js -> TOGGLE_HUD message.
  const keydownListener = (e) => {
    const tag = document.activeElement ? document.activeElement.tagName : '';
    const isEditable = tag === 'INPUT' || tag === 'TEXTAREA' || Boolean(document.activeElement && document.activeElement.isContentEditable);
    // Alt+Shift+A — works regardless of focus
    if (e.altKey && e.shiftKey && (e.key === 'a' || e.key === 'A')) {
      e.preventDefault();
      e.stopPropagation();
      toggleAstrePilotHUD();
      return;
    }
    // Alt+A — only when not focused inside a text field
    if (e.altKey && !e.shiftKey && !e.ctrlKey && !e.metaKey && (e.key === 'a' || e.key === 'A') && !isEditable) {
      e.preventDefault();
      toggleAstrePilotHUD();
      return;
    }
  };
  window.addEventListener('keydown', keydownListener);

  /* -- MULTI-STEP STATE MACHINE & NAVIGATIONAL MEMORY (PILLAR C) -- */
  const STEP_CATEGORY_LABELS = {
    GATEKEEPER: 'Login / Gateway',
    CONTACT_INFO: 'Contact Information',
    EXPERIENCE: 'Work Experience',
    EDUCATION: 'Education & Academics',
    EEO_COMPLIANCE: 'Voluntary Self-ID / EEO',
    SCREENING: 'Screening & Questions',
    REVIEW_SUBMIT: 'Review & Submit',
    GENERIC_STEP: 'Application Step'
  };

  const NEXT_STEP_REGEX = /^(next|continue|save\s*&\s*continue|save\s*and\s*continue|next\s*step|proceed|review(?:\s*application)?|go\s*to\s*next\s*step|continue\s*to\s*next\s*step|step\s*\d+\s*->|log\s*in|login|sign\s*in|signin|get\s*started|start\s*application|enter|submit\s*profile|update\s*profile)$/i;
  const SUBMIT_APPLICATION_REGEX = /^(submit|submit\s*application|complete\s*application|apply|apply\s*now|send\s*application|finish\s*and\s*submit)$/i;

  let navSession = null;
  function getNavSession() {
    if (navSession) return navSession;
    try {
      const raw = sessionStorage.getItem('ap_nav_session');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed.currentStepIndex === 'number') {
          navSession = parsed;
        }
      }
    } catch (e) {}
    return navSession;
  }

  function saveNavSession(session) {
    navSession = session;
    try {
      sessionStorage.setItem('ap_nav_session', JSON.stringify(session));
      sessionStorage.setItem('ap_auto_open', 'true');
    } catch (e) {}
  }

  function clearNavSession() {
    navSession = null;
    try {
      sessionStorage.removeItem('ap_nav_session');
      sessionStorage.removeItem('ap_auto_open');
    } catch (e) {}
  }

  function isGatekeeperStep(fields = detectedFields, url = window.location.href) {
    if (!fields || !fields.length) return false;
    const cleanUrl = url.toLowerCase();
    const isAuthUrl = cleanUrl.includes('/login') || cleanUrl.includes('/signin') || cleanUrl.includes('/sign-in') || cleanUrl.includes('/auth') || cleanUrl.includes('from=login') || cleanUrl.includes('login_or_register') || cleanUrl.includes('login.jsp');
    
    const AUTH_TYPES = new Set(['EMAIL', 'LOGIN_ID', 'PASSWORD', 'CONFIRM_PASSWORD']);
    const nonAuthFields = fields.filter(f => !AUTH_TYPES.has(f.type));
    
    // If only 1 or 2 fields and all are auth types
    if (nonAuthFields.length === 0 && fields.length <= 2) {
      return true;
    }
    // Or on an auth URL with at most 1 other field (e.g. remember me / terms checkbox)
    if (isAuthUrl && nonAuthFields.length <= 1) {
      return true;
    }
    return false;
  }

  function createDefaultNavSession(siteUrl, company, jobTitle) {
    return {
      sessionId: 'nav_' + Math.random().toString(36).slice(2, 9),
      siteUrl: siteUrl || window.location.href,
      company: company || '',
      jobTitle: jobTitle || '',
      currentStepIndex: 0,
      stepName: STEP_CATEGORY_LABELS.CONTACT_INFO,
      stepCategory: 'CONTACT_INFO',
      stepHistory: [],
      cumulativeFieldsTotal: 0,
      cumulativeFieldsFilled: 0,
      activeFillId: null,
      activeApplicationId: null,
      isFinalStep: false,
      lastUpdated: Date.now()
    };
  }

  function classifyCurrentStep(url = '', stepIndicatorsText = '', fieldTypes = []) {
    const combined = `${url} ${stepIndicatorsText}`.toLowerCase();
    if (combined.includes('login') || combined.includes('signin') || combined.includes('sign-in') || isGatekeeperStep(detectedFields, url)) {
      return { category: 'GATEKEEPER', label: STEP_CATEGORY_LABELS.GATEKEEPER };
    }
    if (combined.includes('review') || combined.includes('confirm') || combined.includes('summary') || combined.includes('final')) {
      return { category: 'REVIEW_SUBMIT', label: STEP_CATEGORY_LABELS.REVIEW_SUBMIT };
    }
    if (combined.includes('eeo') || combined.includes('diversity') || combined.includes('self-id') || combined.includes('voluntary')) {
      return { category: 'EEO_COMPLIANCE', label: STEP_CATEGORY_LABELS.EEO_COMPLIANCE };
    }
    if (combined.includes('experience') || combined.includes('employment') || combined.includes('work_history')) {
      return { category: 'EXPERIENCE', label: STEP_CATEGORY_LABELS.EXPERIENCE };
    }
    if (combined.includes('education') || combined.includes('academic') || combined.includes('school')) {
      return { category: 'EDUCATION', label: STEP_CATEGORY_LABELS.EDUCATION };
    }
    if (combined.includes('contact') || combined.includes('personal') || combined.includes('candidate_info')) {
      return { category: 'CONTACT_INFO', label: STEP_CATEGORY_LABELS.CONTACT_INFO };
    }
    if (fieldTypes && fieldTypes.length > 0) {
      const counts = {};
      fieldTypes.forEach(t => { counts[t] = (counts[t] || 0) + 1; });
      const scoreContact = ['FIRST_NAME', 'LAST_NAME', 'FULL_NAME', 'EMAIL', 'PHONE', 'ADDRESS', 'CITY', 'STATE', 'ZIP', 'RESUME'].reduce((acc, k) => acc + (counts[k] || 0), 0);
      const scoreExp = ['COMPANY', 'EMPLOYMENT_TITLE', 'START_MONTH', 'START_YEAR', 'END_MONTH', 'END_YEAR', 'CURRENT_ROLE'].reduce((acc, k) => acc + (counts[k] || 0), 0);
      const scoreEdu = ['SCHOOL', 'DEGREE', 'DISCIPLINE'].reduce((acc, k) => acc + (counts[k] || 0), 0);
      const scoreEeo = ['GENDER', 'PRONOUNS', 'VETERAN', 'DISABILITY', 'RACE_ETHNICITY', 'HISPANIC_LATINO'].reduce((acc, k) => acc + (counts[k] || 0), 0);
      const scoreScreen = ['SCREENING', 'SCREENING_SELECT', 'COVER_LETTER', 'WORK_AUTH', 'VISA', 'SALARY', 'NOTICE_PERIOD', 'PREFERRED_LOCATION', 'WORKPLACE_TYPE'].reduce((acc, k) => acc + (counts[k] || 0), 0);
      const max = Math.max(scoreContact, scoreExp, scoreEdu, scoreEeo, scoreScreen);
      if (max > 0) {
        if (max === scoreContact) return { category: 'CONTACT_INFO', label: STEP_CATEGORY_LABELS.CONTACT_INFO };
        if (max === scoreExp) return { category: 'EXPERIENCE', label: STEP_CATEGORY_LABELS.EXPERIENCE };
        if (max === scoreEdu) return { category: 'EDUCATION', label: STEP_CATEGORY_LABELS.EDUCATION };
        if (max === scoreEeo) return { category: 'EEO_COMPLIANCE', label: STEP_CATEGORY_LABELS.EEO_COMPLIANCE };
        if (max === scoreScreen) return { category: 'SCREENING', label: STEP_CATEGORY_LABELS.SCREENING };
      }
    }
    return { category: 'GENERIC_STEP', label: STEP_CATEGORY_LABELS.GENERIC_STEP };
  }

  function isNextStepButton(btn) {
    if (!btn) return false;
    // Strict isolation: Never match buttons inside StridePilot / AstrePilot HUD
    if (btn.closest && (btn.closest('#stridepilot-root') || btn.closest('#astrepilot-root') || btn.closest('.stridepilot-ui') || btn.closest('.astrepilot-ui'))) return false;

    const txt = (btn.innerText || btn.textContent || btn.value || '').trim();
    // Exclude page-level autofill buttons (e.g. Greenhouse "Autofill my application" or external scrapers)
    if (/autofill\s+my/i.test(txt) || /autofill\s+with/i.test(txt) || /^autofill/i.test(txt)) return false;

    const ariaLabel = (btn.getAttribute ? btn.getAttribute('aria-label') : '') || '';
    if (/autofill/i.test(ariaLabel)) return false;

    const automationId = (btn.getAttribute ? btn.getAttribute('data-automation-id') : '') || '';
    const isGate = isGatekeeperStep(detectedFields, window.location.href);
    if (!isGate && SUBMIT_APPLICATION_REGEX.test(txt)) return false;
    if (NEXT_STEP_REGEX.test(txt)) return true;
    if (isGate && /^(submit|log\s*in|login|sign\s*in|signin|enter|continue|next)$/i.test(txt)) return true;
    if (automationId.toLowerCase().includes('next') || automationId.toLowerCase().includes('continue')) return true;
    if (ariaLabel && NEXT_STEP_REGEX.test(ariaLabel)) return true;
    return false;
  }

  function findNextStepButton(targetDoc = document) {
    const selectors = [
      'button[data-automation-id*="next"]',
      'button[data-automation-id*="continue"]',
      'button[data-automation-id="bottom-navigation-next-button"]',
      'input[type="submit"][value*="Next" i]',
      'input[type="button"][value*="Next" i]',
      'input[type="submit"][value*="Continue" i]',
      'input[type="button"][value*="Continue" i]',
      'input[type="submit"][value*="Log In" i]',
      'input[type="submit"][value*="Login" i]',
      'input[type="submit"][value*="Sign In" i]',
      'input[name="profileButton"]',
      'input#cp_form_submit_1',
      'input[value*="Submit Profile" i]',
      'input[value*="Update Profile" i]',
      'button[type="submit"]',
      'input[type="submit"]'
    ].join(', ');
    const elements = targetDoc.querySelectorAll(selectors);
    for (let i = 0; i < elements.length; i++) {
      if (isNextStepButton(elements[i])) {
        return elements[i];
      }
    }
    // Also traverse same-origin iframes
    try {
      const iframes = targetDoc.querySelectorAll('iframe');
      for (let f = 0; f < iframes.length; f++) {
        try {
          const idoc = iframes[f].contentDocument || (iframes[f].contentWindow && iframes[f].contentWindow.document);
          if (idoc) {
            const btn = findNextStepButton(idoc);
            if (btn) return btn;
          }
        } catch (err) {}
      }
    } catch (e) {}
    return null;
  }

  let activeStepObserver = null;
  function watchForStepTransition(onReady) {
    if (activeStepObserver) {
      activeStepObserver.disconnect();
      activeStepObserver = null;
    }
    let debounceTimer = null;
    const startTime = Date.now();
    const safetyTimeout = setTimeout(() => {
      if (activeStepObserver) {
        activeStepObserver.disconnect();
        activeStepObserver = null;
      }
      if (onReady) onReady();
    }, 4000);

    activeStepObserver = new MutationObserver(() => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        const inputs = document.querySelectorAll('input:not([type="hidden"]), select, textarea, button[role="combobox"]');
        if (inputs.length > 0 || Date.now() - startTime > 1500) {
          clearTimeout(safetyTimeout);
          if (activeStepObserver) {
            activeStepObserver.disconnect();
            activeStepObserver = null;
          }
          if (onReady) onReady();
        }
      }, 300);
    });

    activeStepObserver.observe(document.body, { childList: true, subtree: true });
  }

  async function runContinueNextStep() {
    const hud = activeHud;
    if (!hud) return;

    const nextBtn = findNextStepButton(document);
    if (!nextBtn) {
      hud.setState('done', { isConfirmed: false });
      return;
    }

    hud.setState('transitioning', { step: 'Advancing to next ATS stage...' });

    // Click next button
    try {
      nextBtn.focus();
      nextBtn.click();
    } catch (e) {
      try { nextBtn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true })); } catch (err) {}
    }

    watchForStepTransition(async () => {
      if (!activeHud) return;
      rescanFields();
    });
  }

  const clickNavListener = (e) => {
    const target = e.target && e.target.closest ? e.target.closest('button, a, input[type="submit"], input[type="button"]') : null;
    if (!target) return;
    if (isNextStepButton(target)) {
      try { sessionStorage.setItem('ap_auto_open', 'true'); } catch (err) {}
      if (activeHud) {
        activeHud.setState('transitioning', { step: 'Advancing to next step...' });
        watchForStepTransition(() => {
          if (activeHud && !isFilling) {
            rescanFields();
          }
        });
      }
    }
  };
  function attachFrameClickListeners() {
    try {
      const iframes = document.querySelectorAll('iframe');
      iframes.forEach(frame => {
        try {
          const doc = frame.contentDocument || (frame.contentWindow && frame.contentWindow.document);
          if (doc && !doc.__ap_click_bound) {
            doc.addEventListener('click', clickNavListener, true);
            doc.__ap_click_bound = true;
          }
        } catch (e) {}
      });
    } catch (e) {}
  }
  document.addEventListener('click', clickNavListener, true);
  setInterval(attachFrameClickListeners, 2000);

  const oldCleanup = window.__ASTREPILOT_CLEANUP__;
  window.__ASTREPILOT_CLEANUP__ = () => {
    if (oldCleanup) try { oldCleanup(); } catch(e) {}
    window.removeEventListener('keydown', keydownListener);
    document.removeEventListener('click', clickNavListener, true);
    if (activeStepObserver) {
      try { activeStepObserver.disconnect(); } catch (e) {}
      activeStepObserver = null;
    }
  };

  /* -- HELPERS -- */
  function el(tag, attrs, children) {
    const e = document.createElement(tag);
    Object.entries(attrs || {}).forEach(([k, v]) => {
      if (k === 'style') e.style.cssText = v;
      else if (k === 'className') e.className = v;
      else e.setAttribute(k, v);
    });
    (children || []).forEach(c => {
      e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
    return e;
  }

  async function getStoredConfig() {
    return new Promise((resolve) => {
      if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.sync) {
        return resolve({
          token: STANDALONE_PROFILES.roushan.token,
          origin: 'https://stride.app',
          activeContext: 'roushan'
        });
      }
      const keys = ['stridepilot_token', 'astrepilot_token', 'stridepilot_origin', 'astrepilot_origin', 'stridepilot_active_context', 'astrepilot_active_context'];
      chrome.storage.sync.get(keys, (res) => {
        const safeRes = res || {};
        chrome.storage.local.get(keys, (localRes) => {
          const merged = { ...(localRes || {}), ...safeRes };
          const origin = 'https://stride.app';
          if (merged.stridepilot_origin !== origin && chrome.storage.sync) {
            chrome.storage.sync.set({ stridepilot_origin: origin, astrepilot_origin: origin });
          }
          const activeCtx = merged.stridepilot_active_context || merged.astrepilot_active_context || 'roushan';
          const token = merged.stridepilot_token || merged.astrepilot_token || STANDALONE_PROFILES.roushan.token;
          resolve({
            token,
            origin,
            activeContext: activeCtx
          });
        });
      });
    });
  }

  async function apFetch(path, opts = {}) {
    const config = await getStoredConfig();
    const headers = Object.assign(
      { 'Authorization': 'Bearer ' + config.token },
      opts.headers || {}
    );
    if (opts.body && !headers['Content-Type']) {
      headers['Content-Type'] = 'application/json';
    }
    const cleanOrigin = config.origin.replace(/\/$/, '');
    const url = cleanOrigin + (path.startsWith('/api/') ? path : ('/api/autopilot' + path));

    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({
        type: 'PROXY_FETCH',
        url: url,
        options: {
          method: opts.method || 'GET',
          headers: headers,
          body: opts.body
        }
      }, (response) => {
        if (chrome.runtime.lastError) {
          return reject(new Error(chrome.runtime.lastError.message));
        }
        if (!response || response.error) {
          return resolve({
            ok: false,
            status: (response && response.status) ? response.status : 500,
            json: async () => ({ error: (response && response.error) ? response.error : 'Network error' })
          });
        }
        resolve({
          ok: response.ok,
          status: response.status,
          json: async () => response.data
        });
      });
    });
  }

  function extractRecruiterInfo() {
    try {
      // 1. LinkedIn Job View Hiring Team Card Selectors
      const hirerCard = document.querySelector(
        '.hirer-card__hirer-information, [data-view-name="job-details-hiring-team"], .jobs-poster, .job-details-jobs-unified-top-card__hiring-team, .hirer-card'
      );
      
      if (hirerCard) {
        const linkEl = hirerCard.querySelector('a[href*="/in/"], a[href*="linkedin.com/in/"]');
        const nameEl = hirerCard.querySelector('.jobs-poster__name, .hirer-card__hirer-information a, .inline-show-more-text, strong, h3');
        const titleEl = hirerCard.querySelector('.jobs-poster__title, .hirer-card__job-poster-headline, .jobs-poster__headline, .linked-area');
        
        let profileUrl = linkEl ? linkEl.href : null;
        if (profileUrl) {
          profileUrl = profileUrl.split('?')[0].replace(/\/+$/, '');
        }
        
        const rawName = nameEl ? nameEl.innerText.trim() : null;
        const rawTitle = titleEl ? titleEl.innerText.trim() : 'Recruiter / Hiring Lead';
        
        let linkedinId = null;
        if (profileUrl) {
          const match = profileUrl.match(/\/in\/([a-zA-Z0-9_%-]+)/);
          if (match) linkedinId = decodeURIComponent(match[1]);
        }
        
        if (profileUrl || rawName) {
          return {
            name: rawName || 'Hiring Lead',
            title: rawTitle,
            profileUrl: profileUrl,
            linkedinId: linkedinId,
          };
        }
      }

      // 2. Generic ATS / Career Page Scans (e.g. Greenhouse, Ashby, Lever hiring manager link)
      const genericLink = document.querySelector(
        'a[href*="linkedin.com/in/"]:not([href*="linkedin.com/company/"])'
      );
      if (genericLink && (window.location.hostname.includes('greenhouse.io') || window.location.hostname.includes('ashbyhq.com') || window.location.hostname.includes('lever.co') || window.location.hostname.includes('jobs.'))) {
        let profileUrl = genericLink.href.split('?')[0].replace(/\/+$/, '');
        let linkedinId = null;
        const match = profileUrl.match(/\/in\/([a-zA-Z0-9_%-]+)/);
        if (match) linkedinId = decodeURIComponent(match[1]);
        const name = genericLink.innerText.trim() || genericLink.closest('.team-member, .hiring-lead')?.querySelector('h3, h4, strong')?.innerText.trim() || 'Hiring Lead';
        return {
          name: name,
          title: 'Hiring Lead',
          profileUrl: profileUrl,
          linkedinId: linkedinId,
        };
      }
    } catch (e) {
      console.warn('[AstrePilot] Recruiter extraction error:', e);
    }
    return null;
  }

  function extractCatalogJobs() {
    try {
      const hostname = window.location.hostname.toLowerCase();
      const isWellfound = hostname.includes('wellfound.com');
      const isJobright = hostname.includes('jobright.ai');
      const isInternList = hostname.includes('intern-list.com');
      
      if (!isWellfound && !isJobright && !isInternList) return null;

      // CRITICAL SAFEGUARD: Never hijack the page with catalog harvesting if candidate is actively applying!
      if (document.querySelector('textarea[name="userNote"], textarea#userNote, [data-test*="ApplicationModal"], [data-test*="apply"], [class*="ApplicationModal"], [class*="application-modal"], form[action*="apply"]')) {
        return null;
      }
      
      const source = isInternList ? 'INTERN_LIST' : (isJobright ? 'JOBRIGHT' : 'WELLFOUND');
      const harvested = [];
      const seenUrls = new Set();

      if (isWellfound) {
        // 1. First-class Loophole: Apollo Store & __NEXT_DATA__ in-memory extraction
        try {
          const nextScript = document.getElementById('__NEXT_DATA__');
          if (nextScript && nextScript.textContent) {
            const parsed = JSON.parse(nextScript.textContent);
            const store = parsed?.props?.pageProps?.apolloState || parsed?.props?.pageProps?.initialApolloState;
            if (store) {
              for (const [key, val] of Object.entries(store)) {
                if ((key.includes('JobListing') || key.includes('JobPosting') || key.startsWith('Job:')) && val && val.title) {
                  let company = 'Startup';
                  if (val.startup && val.startup.name) {
                    company = val.startup.name;
                  } else if (val.company && val.company.name) {
                    company = val.company.name;
                  } else if (val.startup && val.startup.__ref && store[val.startup.__ref]) {
                    company = store[val.startup.__ref].name || company;
                  } else if (val.company && val.company.__ref && store[val.company.__ref]) {
                    company = store[val.company.__ref].name || company;
                  }
                  const isRemote = val.remote === true || val.remote === 'REMOTE' || val.remoteType === 'REMOTE' || 
                    (Array.isArray(val.locationNames) && val.locationNames.some(l => typeof l === 'string' && l.toLowerCase().includes('remote')));
                  const loc = isRemote ? 'Remote' : ((Array.isArray(val.locationNames) && val.locationNames[0]) || 'Remote');
                  const slug = val.slug || (val.id ? `job-${val.id}` : 'startup-job');
                  const url = val.id ? `https://wellfound.com/jobs/${val.id}-${slug}` : `https://wellfound.com/jobs/${slug}`;
                  if (seenUrls.has(url)) continue;
                  seenUrls.add(url);

                  harvested.push({
                    title: val.title,
                    company,
                    location: loc,
                    salary: val.compensation || null,
                    url,
                    rawDescription: val.description || `${val.title} at ${company}. Live startup role on Wellfound.`,
                  });
                }
              }
            }
          }
        } catch (apolloErr) {
          console.warn('[AstrePilot] Apollo store parsing note:', apolloErr);
        }

        // 2. DOM fallback for rendered search cards
        if (harvested.length === 0) {
          const jobLinks = document.querySelectorAll('a[href*="/jobs/"]');
          jobLinks.forEach(linkEl => {
            try {
              let url = linkEl.getAttribute('href');
              if (!url || ['/signup', '/faq', '/login'].some(s => url.includes(s)) || url.endsWith('/jobs')) return;
              if (url.startsWith('/')) url = 'https://wellfound.com' + url;
              if (seenUrls.has(url)) return;

              const card = linkEl.closest('div[class*="styles_jobListing"], div[class*="styles_company"], div[class*="styles_result"], [data-test*="JobListing"], [data-test*="JobCard"], li, tr, article') || linkEl.parentElement;
              const titleEl = card ? card.querySelector('a[class*="title"], h2, h3, [data-test="JobTitle"]') : null;
              const title = (titleEl ? titleEl.innerText : linkEl.innerText).split('\n')[0].trim();
              if (!title || title.length < 3 || title.toLowerCase().includes('open position')) return;

              let company = 'Startup';
              const companyEl = card ? card.querySelector('a[href*="/company/"], [data-test="StartupName"], h4, strong') : null;
              if (companyEl) {
                company = companyEl.innerText.split('\n')[0].trim() || company;
              }

              const locEl = card ? card.querySelector('span[class*="location"], [data-test="Location"]') : null;
              const compEl = card ? card.querySelector('span[class*="compensation"], span[class*="salary"]') : null;

              if (title && url) {
                seenUrls.add(url);
                harvested.push({
                  title,
                  company,
                  location: locEl ? locEl.innerText.trim() : 'Remote',
                  salary: compEl ? compEl.innerText.trim() : null,
                  url,
                  rawDescription: `${title} at ${company}. Live startup role on Wellfound.`,
                });
              }
            } catch (e) {}
          });
        }
      } else if (isJobright || isInternList) {
        // 1. Minisite Next.js __NEXT_DATA__ in-memory extraction
        try {
          const nextScript = document.getElementById('__NEXT_DATA__');
          if (nextScript && nextScript.textContent) {
            const parsed = JSON.parse(nextScript.textContent);
            const initialJobs = parsed?.props?.pageProps?.initialJobs;
            if (Array.isArray(initialJobs) && initialJobs.length > 0) {
              for (const job of initialJobs) {
                const title = job.title;
                const company = job.company || 'Tech Startup';
                const isRemote = job.workModel === 'Remote' || (job.location && job.location.toLowerCase().includes('remote'));
                const location = isRemote ? (job.location ? `Remote (${job.location})` : 'Remote') : (job.location || 'Remote');
                const url = job.applyUrl || `https://jobright.ai/jobs/info/${job.id}`;
                if (!title || seenUrls.has(url)) continue;
                seenUrls.add(url);
                harvested.push({
                  title,
                  company,
                  location,
                  salary: job.salary || null,
                  url,
                  rawDescription: `${title} at ${company}. ${job.qualifications || ''}`,
                });
              }
            }
          }
        } catch (nextErr) {
          console.warn('[AstrePilot] Jobright Next.js extraction note:', nextErr);
        }

        // 2. DOM fallback for rendered cards or table rows
        if (harvested.length === 0) {
          // Check for minisite table rows & links
          const applyLinks = document.querySelectorAll('a[class*="airtableApplyLink"], a[href*="/jobs/info/"], a[class*="apply"]');
          applyLinks.forEach(linkEl => {
            try {
              const url = linkEl.href;
              if (!url || seenUrls.has(url)) return;
              const row = linkEl.closest('tr, div[class*="row"], div[role="row"], div[role="listitem"], li, article');
              if (!row) return;

              const titleEl = row.querySelector('[class*="title"], [class*="jobtitle"], strong, h3, h4');
              const companyEl = row.querySelector('[class*="company"], [class*="companyname"], span, p');
              const locEl = row.querySelector('[class*="location"], [class*="badge"], [class*="tag"]');

              const title = titleEl ? titleEl.innerText.trim() : null;
              const company = companyEl ? companyEl.innerText.trim() : 'Tech Startup';
              const location = locEl ? locEl.innerText.trim() : 'Remote';

              if (title && url) {
                seenUrls.add(url);
                harvested.push({
                  title,
                  company,
                  location,
                  url,
                  rawDescription: `${title} at ${company}. Harvested from ${source}.`,
                });
              }
            } catch (e) {}
          });

          // Check standard job cards (Jobright main site)
          if (harvested.length === 0) {
            const cards = document.querySelectorAll('[class*="job-card"], [class*="JobCard"], div[role="article"]');
            cards.forEach(card => {
              try {
                const titleEl = card.querySelector('h2, h3, a[class*="title"]');
                const companyEl = card.querySelector('p[class*="company"], span[class*="company"], strong');
                const linkEl = card.querySelector('a[href*="/job/"], a[href*="http"]');
                const locEl = card.querySelector('[class*="location"]');

                const title = titleEl ? titleEl.innerText.trim() : null;
                const company = companyEl ? companyEl.innerText.trim() : null;
                const url = linkEl ? linkEl.href : null;

                if (title && company && url) {
                  if (seenUrls.has(url)) return;
                  seenUrls.add(url);
                  harvested.push({
                    title,
                    company,
                    location: locEl ? locEl.innerText.trim() : 'Remote',
                    url,
                    rawDescription: `${title} at ${company}. Harvested from ${source}.`,
                  });
                }
              } catch (e) {}
            });
          }
        }
      }

      return harvested.length > 0 ? { source, jobs: harvested, count: harvested.length } : null;
    } catch (err) {
      console.warn('[AstrePilot Harvester] Error detecting jobs:', err);
      return null;
    }
  }

  function extractPageContent() {
    // 1. Gather text from same-origin iframes FIRST (crucial for iCIMS, embedded Workday, Taleo)
    let iframeTextChunks = [];
    try {
      const iframes = document.querySelectorAll('iframe');
      for (let i = 0; i < iframes.length; i++) {
        try {
          const doc = iframes[i].contentDocument || (iframes[i].contentWindow && iframes[i].contentWindow.document);
          if (doc && doc.body) {
            const cloneFrame = doc.body.cloneNode(true);
            const removeSelectors = ['nav', 'footer', 'header', 'script', 'style', 'noscript', 'svg', 'img'];
            removeSelectors.forEach(s => {
              const els = cloneFrame.querySelectorAll(s);
              for (let j = 0; j < els.length; j++) els[j].remove();
            });
            const frameText = (cloneFrame.textContent || '').replace(/\s+/g, ' ').trim();
            if (frameText.length > 80) {
              iframeTextChunks.push(frameText);
            }
          }
        } catch (frameErr) {
          // Cross-origin iframe, cannot read directly
        }
      }
    } catch (e) {
      console.warn('[AstrePilot] iframe text extraction note:', e);
    }

    const clone = document.body.cloneNode(true);
    const removeSelectors = ['nav', 'footer', 'header', 'script', 'style', 'noscript', 'iframe', 'svg', 'img'];
    removeSelectors.forEach(s => {
      const els = clone.querySelectorAll(s);
      for (let i = 0; i < els.length; i++) els[i].remove();
    });
    
    // textContent is safer on disconnected nodes than innerText
    let text = clone.textContent || '';
    text = text.replace(/\s+/g, ' ').trim();

    // If iframe text exists, append it with priority
    if (iframeTextChunks.length > 0) {
      text = (text + '\n\n' + iframeTextChunks.join('\n\n')).trim();
    }
    
    return {
      pageText: text,
      pageUrl: window.location.href,
      pageTitle: document.title,
      recruiter: extractRecruiterInfo()
    };
  }

  function findAndClickApplyButton() {
    const keywords = /^(apply|apply now|apply for this job|apply for this job online|apply online|easy apply|submit application)$/i;
    const targetDocs = [document];
    try {
      const iframes = document.querySelectorAll('iframe');
      for (let i = 0; i < iframes.length; i++) {
        try {
          const doc = iframes[i].contentDocument || (iframes[i].contentWindow && iframes[i].contentWindow.document);
          if (doc && doc.body) targetDocs.push(doc);
        } catch (e) {}
      }
    } catch (e) {}

    for (const targetDoc of targetDocs) {
      const elements = targetDoc.querySelectorAll('a, button, [role="button"]');
      for (let i = 0; i < elements.length; i++) {
        const txt = (elements[i].innerText || elements[i].textContent || '').trim();
        if (keywords.test(txt)) {
          try { chrome.runtime.sendMessage({ type: 'NOTIFY_CLICK_APPLY' }); } catch(e) {}
          sessionStorage.setItem('ap_auto_open', 'true');
          elements[i].click();
          return true;
        }
      }
    }
    return false;
  }

  /* -- FIELD CLASSIFIER -- */
  /* -- FIELD CLASSIFIER -- */
  const FIELD_PATTERNS = [
    { type: 'FIRST_NAME',   kw: ['first_name', 'firstname', 'fname', 'given_name', 'first-name', 'first name', 'givenname'] },
    { type: 'LAST_NAME',    kw: ['last_name', 'lastname', 'lname', 'family_name', 'surname', 'last-name', 'last name', 'familyname'] },
    { type: 'FULL_NAME',    kw: ['full_name', 'fullname', 'legal_name', 'full-name', 'full-legal', 'full legal', 'full name', 'cname'] },
    { type: 'EMAIL',        kw: ['email', 'e-mail', 'email_address', 'emailaddress'] },
    { type: 'PHONE_TYPE',   kw: ['phone_type', 'phone type', 'phonetype', 'number_type', 'number type', 'telephone_type', 'telephonetype'] },
    { type: 'PHONE',        kw: ['phone', 'telephone', 'mobile', 'cell', 'contact_number', 'phone_number', 'phonenumber', 'phone number', 'contact number', 'mobile number'] },
    { type: 'ADDRESS_TYPE', kw: ['address_type', 'address type', 'addresstype', 'location_type', 'location type'] },
    { type: 'APT',          kw: ['apartment', 'suite', 'apt', 'address line 2', 'address_line_2', 'address2', 'address 2', 'line 2', 'line2', 'address_2'] },
    { type: 'ZIP',          kw: ['zip', 'zip_code', 'zip code', 'postal code', 'postal_code', 'postal', 'postcode', 'pin code', 'pincode'] },
    { type: 'ADDRESS',      kw: ['street_address', 'street address', 'address line 1', 'address_line_1', 'address 1', 'address_1', 'address1', 'street', 'address'] },
    { type: 'CITY',         kw: ['city', 'town', 'municipality'] },
    { type: 'STATE',        kw: ['state', 'province', 'state_province', 'state/province', 'region', 'state or province'] },
    { type: 'COUNTRY',      kw: ['country', 'nation', 'country_region', 'country/region'] },
    { type: 'PREFERRED_LOCATION', kw: ['preferred office location', 'preferred office', 'office location', 'preferred location', 'office preference', 'location preference', 'preferred workplace', 'workplace preference', 'work arrangement', 'desired office', 'desired location', 'which office', 'where would you like to work'] },
    { type: 'WORKPLACE_TYPE', kw: ['workplace type', 'workplace arrangement', 'work model', 'remote hybrid on-site', 'remote or on-site', 'remote eligible'] },
    { type: 'LOCATION',     kw: ['current_location', 'city_state', 'city_country', 'current location', 'location'] },
    { type: 'HEAR_ABOUT_DETAIL', kw: ['specify further', 'please specify', 'source detail', 'referral detail', 'specify'] },
    { type: 'HEAR_ABOUT',   kw: ['how did you hear', 'hear about us', 'source', 'referral_source', 'how_did_you_hear', 'hear_about', 'hear about', 'referral'] },
    { type: 'LINKEDIN',     kw: ['linkedin', 'linkedin_url', 'linkedin_profile'] },
    { type: 'GITHUB',       kw: ['github', 'github_url', 'github_profile'] },
    { type: 'PORTFOLIO',    kw: ['portfolio', 'portfolio_url', 'personal_website', 'personal_site', 'website'] },
    { type: 'RESUME',       kw: ['resume', 'cv', 'curriculum', 'curriculum vitae', 'curriculum_vitae', 'resume/cv', 'resume_file', 'cv_file', 'attach_resume', 'upload_resume', 'attach resume', 'upload resume', 'resume document'] },
    { type: 'TITLE',        kw: ['headline', 'current_title', 'job_title', 'current_role', 'current_position'] },
    { type: 'COVER_LETTER', kw: ['cover_letter', 'coverletter', 'cover letter', 'motivation_letter', 'brief summary', 'cover note'] },
    { type: 'SUMMARY',      kw: ['summary', 'about_yourself', 'professional_summary', 'about you'] },
    { type: 'WORK_AUTH',    kw: ['work_auth', 'work_authorization', 'authorized to work', 'legally authorized', 'authorized'] },
    { type: 'VISA',         kw: ['visa', 'sponsorship', 'require sponsorship', 'sponsor'] },
    { type: 'SALARY',       kw: ['salary', 'expected_salary', 'desired_salary', 'salary_expectation', 'compensation'] },
    { type: 'NOTICE_PERIOD',kw: ['notice_period', 'notice period', 'availability', 'start date', 'how soon'] },
    { type: 'RELOCATE',     kw: ['relocate', 'willing to relocate', 'relocation'] },
    { type: 'EDUCATION',    kw: ['highest_education', 'highest education', 'degree', 'education level', 'education'] },
    { type: 'GENDER',       kw: ['gender', 'sex', 'identify as'] },
    { type: 'PRONOUNS',     kw: ['pronouns', 'preferred pronouns'] },
    // Employment granular patterns
    { type: 'COMPANY',      kw: ['company_name', 'company name', 'employer', 'organization', 'company'] },
    { type: 'EMPLOYMENT_TITLE', kw: ['employment_title', 'role_title', 'position title'] },
    { type: 'EXP_STATE',    kw: ['company_state', 'work_state', 'employer_state'] },
    { type: 'EXP_CITY',     kw: ['company_city', 'work_city', 'employer_city'] },
    { type: 'EXP_COUNTRY',  kw: ['company_country', 'work_country', 'employer_country'] },
    { type: 'START_MONTH',  kw: ['start_date_month', 'start date month', 'start month', 'start_month'] },
    { type: 'START_DAY',    kw: ['start_date_day', 'start date day', 'start day', 'start_day'] },
    { type: 'START_YEAR',   kw: ['start_date_year', 'start date year', 'start year', 'start_year'] },
    { type: 'END_MONTH',    kw: ['end_date_month', 'end date month', 'end month', 'end_month'] },
    { type: 'END_DAY',      kw: ['end_date_day', 'end date day', 'end day', 'end_day'] },
    { type: 'END_YEAR',     kw: ['end_date_year', 'end date year', 'end year', 'end_year'] },
    { type: 'CURRENT_ROLE', kw: ['current_role', 'current role', 'currently work here', 'i currently work here'] },
    { type: 'REASON_FOR_LEAVING', kw: ['reason for leaving', 'reason_for_leaving', 'leaving reason', 'reason_leaving', 'reason'] },
    // Education granular patterns
    { type: 'SCHOOL',       kw: ['school_name', 'school name', 'university', 'college', 'institution', 'school'] },
    { type: 'DEGREE',       kw: ['degree_type', 'degree level', 'degree'] },
    { type: 'DISCIPLINE',   kw: ['discipline', 'major', 'field of study', 'specialization', 'branch'] },
    // Compliance & Voluntary self-identification
    { type: 'TEXT_CONSENT', kw: ['text consent', 'text messages', 'receive text messages', 'sms consent', 'text_consent', 'sms'] },
    { type: 'AGE_18',       kw: ['18 years', '18 years of age', 'at least 18', 'age 18', 'legal age', '18 or older'] },
    { type: 'PREVIOUS_EMPLOYED', kw: ['previously been employed', 'previously employed', 'prior employment', 'former employee', 'worked here before', 'worked for coinbase'] },
    { type: 'PRIVACY_CONSENT', kw: ['privacy notice', 'privacy policy', 'arbitration agreement', 'global data privacy', 'receipt of the above linked'] },
    { type: 'AI_CONSENT',   kw: ['may use ai tools', 'use ai tools to assist', 'ai tools assist'] },
    { type: 'AI_USAGE',     kw: ['how you use ai tools', 'use ai tools today', 'describe how you use ai'] },
    { type: 'GOVT_OFFICIAL',kw: ['government official', 'civil service position', 'holder of public office'] },
    { type: 'GOVT_RELATIVE',kw: ['relative of a government official', 'relative of a government', 'close relative of a government'] },
    { type: 'CONFLICT_INTEREST', kw: ['conflict of interest', 'perceived conflict', 'actual or perceived conflict'] },
    { type: 'REFERRED_BY_LEADER', kw: ['referred to this position by a senior', 'senior leader or decision-maker'] },
    { type: 'HISPANIC_LATINO', kw: ['hispanic/latino', 'hispanic or latino', 'hispanic', 'latino'] },
    { type: 'VETERAN',      kw: ['veteran status', 'protected veteran', 'veterans act', 'vevraa'] },
    { type: 'DISABILITY',   kw: ['disability status', 'have a disability', 'disability'] },
    { type: 'RACE_ETHNICITY', kw: ['race & ethnicity', 'race and ethnicity', 'race/ethnicity', 'ethnicity', 'race'] },
    // Work Experience Granular Description
    { type: 'WORK_DESCRIPTION', kw: ['job_description', 'role_description', 'work_description', 'responsibilities', 'duties', 'describe your role', 'describe your responsibilities', 'role description', 'job description'] },
    // Authentication & Credential Vault
    { type: 'PASSWORD',     kw: ['password', 'create password', 'new password', 'set password', 'choose password', 'user password'] },
    { type: 'CONFIRM_PASSWORD', kw: ['confirm password', 're-enter password', 'repeat password', 'verify password', 'confirm_password'] },
    { type: 'LOGIN_ID',     kw: ['username', 'login', 'user id', 'user name', 'account id', 'login id', 'login_id'] },
  ];

  function parseLocation(loc) {
    if (!loc) return { city: '', state: '', country: '' };
    const parts = String(loc).split(',').map(s => s.trim()).filter(Boolean);
    if (parts.length >= 3) {
      return { city: parts[0], state: parts[1], country: parts[parts.length - 1] };
    }
    if (parts.length === 2) {
      return { city: parts[0], state: parts[1], country: parts[1] };
    }
    return { city: parts[0] || '', state: '', country: parts[0] || '' };
  }

  function getLabelText(input) {
    const ariaLabel = (input.getAttribute('aria-label') || '').toLowerCase();
    let labelText = '';
    const labelEl = input.labels && input.labels[0];
    if (labelEl) {
      for (let n = 0; n < labelEl.childNodes.length; n++) {
        if (labelEl.childNodes[n].nodeType === 3) labelText += labelEl.childNodes[n].textContent;
      }
      if (!labelText) labelText = labelEl.textContent || '';
    }
    // Check aria-labelledby if label is empty
    const ownerDoc = input.ownerDocument || document;
    if (!labelText && input.getAttribute('aria-labelledby')) {
      const labelledByEl = ownerDoc.getElementById(input.getAttribute('aria-labelledby'));
      if (labelledByEl) labelText = labelledByEl.textContent || '';
    }
    // Check explicit label[for="id"]
    if (!labelText && input.id && ownerDoc) {
      try {
        const forLabel = ownerDoc.querySelector(`label[for="${CSS.escape(input.id)}"]`);
        if (forLabel) labelText = forLabel.textContent || '';
      } catch (e) {}
    }
    // Check parent or sibling container label (crucial for Greenhouse, Workday, Lever, Taleo)
    if (!labelText) {
      const container = input.closest('.select__container, .select, .field, .form-group, .form-row, [class*="field"], [class*="form-group"], tr');
      if (container) {
        const nearLabel = container.querySelector('label, .iCIMS_Label, .field-label, [class*="label" i]');
        if (nearLabel) labelText = nearLabel.textContent || '';
      }
      if (!labelText) {
        let p = input.parentElement;
        while (p && p !== ownerDoc.body && p !== ownerDoc.documentElement) {
          const l = p.querySelector('label, [class*="label" i]');
          if (l) {
            labelText = l.textContent || '';
            break;
          }
          p = p.parentElement;
        }
      }
    }
    const placeholder = (input.placeholder || '').toLowerCase();
    return [ariaLabel, labelText.toLowerCase(), placeholder].join(' ').replace(/\s+/g, ' ');
  }

  // Short keywords that appear inside unrelated words ("excellent", "electricity", "advisable")
  // must match on word boundaries; longer, specific keywords keep substring matching.
  const BOUNDARY_KW = new Set(['cell', 'city', 'visa', 'apt']);
  function kwMatch(signal, kw) {
    if (!BOUNDARY_KW.has(kw)) return signal.includes(kw);
    return new RegExp('(^|[^a-z])' + kw + '($|[^a-z])').test(signal);
  }

  function isComboboxOrSelect(el) {
    if (!el) return false;
    if (el.tagName === 'SELECT') return true;
    if (el.tagName === 'TEXTAREA') return false;
    const role = (el.getAttribute && el.getAttribute('role') || '').toLowerCase();
    const hasPopup = (el.getAttribute && el.getAttribute('aria-haspopup') || '').toLowerCase();
    if (role === 'combobox' || hasPopup === 'listbox') return true;
    if (el.hasAttribute && (el.hasAttribute('data-radix-collection-item') || el.hasAttribute('data-headlessui-state') || el.hasAttribute('data-state'))) return true;
    const autoId = (el.getAttribute && el.getAttribute('data-automation-id') || '').toLowerCase();
    if (autoId.includes('select-box') || autoId.includes('promptoption') || autoId.includes('searchbox')) return true;
    if (el.classList && (el.classList.contains('select__input') || el.classList.contains('select-shell') || el.classList.contains('react-select__input') || el.classList.contains('select__control'))) return true;
    if (el.closest && el.closest('.select-shell, .select__control, .select__container, [class*="react-select"], [class*="Select-control"], [data-automation-id="select-box"], [data-radix-popper-content-wrapper], [role="combobox"]')) return true;
    return false;
  }

  function isReactSelect(el) {
    if (!el || el.tagName === 'SELECT' || el.tagName === 'TEXTAREA') return false;
    if (el.classList && (el.classList.contains('select__input') || el.classList.contains('select-shell') || el.classList.contains('react-select__input'))) return true;
    if (el.getAttribute && el.getAttribute('role') === 'combobox') return true;
    if (el.closest && el.closest('.select-shell, .select__control, .select__container, [class*="react-select"], [class*="Select-control"]')) return true;
    return false;
  }

  function detectComboboxType(el) {
    if (!el) return 'WAI_ARIA';
    if (el.tagName === 'SELECT') return 'NATIVE';
    const autoId = (el.getAttribute && el.getAttribute('data-automation-id') || '').toLowerCase();
    const cls = (el.className || '').toLowerCase();
    const id = (el.id || '').toLowerCase();
    if (autoId.includes('select-box') || autoId.includes('promptoption') || autoId.includes('searchbox') || cls.includes('workday') || id.includes('wd-')) {
      return 'WORKDAY';
    }
    if (cls.includes('select__control') || cls.includes('select__input') || cls.includes('select-shell') || cls.includes('react-select') || id.includes('react-select') || (el.closest && el.closest('.select-shell, .select__control, .select__container, [class*="react-select"], .select'))) {
      return 'REACT_SELECT';
    }
    if (isGreenhouseEnvironment() && ((el.getAttribute && el.getAttribute('role') === 'combobox') || (el.closest && el.closest('.select-shell, [class*="select"]')))) {
      return 'REACT_SELECT';
    }
    if ((el.hasAttribute && (el.hasAttribute('data-radix-collection-item') || el.hasAttribute('data-state'))) || cls.includes('radix') || id.includes('radix') || (el.closest && el.closest('[data-radix-popper-content-wrapper], [data-radix-select-viewport]'))) {
      return 'RADIX';
    }
    if ((el.hasAttribute && el.hasAttribute('data-headlessui-state')) || cls.includes('headlessui') || id.includes('headlessui')) {
      return 'HEADLESS_UI';
    }
    return 'WAI_ARIA';
  }

  /* =========================================================================
     ASTREPILOT V3: UNIVERSAL SEMANTIC FIELD DISCOVERY (SFD) ENGINE
     ========================================================================= */

  function sfdClean(str) {
    if (!str) return '';
    return String(str)
      .toLowerCase()
      .replace(/[*:\(\)\[\]?#]+/g, ' ')
      .replace(/[\s\-_]+/g, ' ')
      .trim();
  }

  function sfdCompact(str) {
    if (!str) return '';
    return String(str).toLowerCase().replace(/[^a-z0-9]/g, '');
  }

  const SFD_TAXONOMY = [
    // Upload
    {
      type: 'RESUME',
      attrs: ['resume', 'cv', 'curriculum', 'resume_file', 'attach_resume', 'dropzone'],
      labels: ['resume', 'cv', 'curriculum vitae', 'attach resume', 'upload resume'],
      baseConf: 0.98
    },
    {
      type: 'COVER_LETTER_FILE',
      attrs: ['coverletter_file', 'cover_letter_upload', 'cover_letter_file'],
      labels: ['cover letter file', 'upload cover letter', 'attach cover letter'],
      baseConf: 0.95
    },
    // Identity
    {
      type: 'FIRST_NAME',
      attrs: ['firstname', 'first_name', 'first-name', 'fname', 'givenname', 'given_name'],
      labels: ['first name', 'given name', 'first name*'],
      autocompletes: ['given-name', 'first-name'],
      forbidden: ['company', 'referral', 'contact', 'emergency'],
      baseConf: 0.96
    },
    {
      type: 'LAST_NAME',
      attrs: ['lastname', 'last_name', 'last-name', 'lname', 'surname', 'familyname', 'family_name'],
      labels: ['last name', 'surname', 'family name', 'last name*'],
      autocompletes: ['family-name', 'last-name'],
      forbidden: ['company', 'referral', 'contact', 'emergency'],
      baseConf: 0.96
    },
    {
      type: 'FULL_NAME',
      attrs: ['fullname', 'full_name', 'candidate_name', 'your_name', 'applicant_name'],
      labels: ['full name', 'your name', 'candidate name', 'legal name'],
      autocompletes: ['name'],
      forbidden: ['first', 'last', 'company', 'school', 'emergency'],
      baseConf: 0.92
    },
    {
      type: 'PREFERRED_NAME',
      attrs: ['preferred_name', 'preferredname', 'nickname', 'chosen_name'],
      labels: ['preferred name', 'nickname', 'what should we call you'],
      baseConf: 0.94
    },
    {
      type: 'PRONOUNS',
      attrs: ['pronoun', 'pronouns', 'gender_pronouns'],
      labels: ['pronouns', 'preferred pronouns', 'your pronouns'],
      baseConf: 0.95
    },
    // Contact
    {
      type: 'EMAIL',
      attrs: ['email', 'e-mail', 'email_address', 'electronic_mail'],
      labels: ['email', 'e-mail', 'email address', 'electronic mail', 'email*'],
      autocompletes: ['email'],
      forbidden: ['referral', 'referrer', 'emergency'],
      baseConf: 0.98
    },
    {
      type: 'PHONE',
      attrs: ['phone', 'phonenumber', 'phone_number', 'mobile', 'telephone', 'cellular', 'cell', 'cell_phone', 'cellphone'],
      labels: ['phone', 'phone number', 'mobile', 'mobile number', 'telephone', 'cell', 'cellular', 'contact number'],
      autocompletes: ['tel', 'mobile'],
      forbidden: ['country', 'code', 'type', 'emergency', 'referral'],
      baseConf: 0.95
    },
    {
      type: 'PHONE_COUNTRY_CODE',
      attrs: ['phone_country_code', 'country_code', 'phonecode', 'dialing_code'],
      labels: ['country code', 'phone code', 'dialing code', 'prefix'],
      baseConf: 0.92
    },
    {
      type: 'PHONE_TYPE',
      attrs: ['phone_type', 'phonetype', 'phone_device_type'],
      labels: ['phone type', 'device type', 'type of phone'],
      baseConf: 0.93
    },
    {
      type: 'LINKEDIN',
      attrs: ['linkedin', 'linkedin_url', 'linkedin_profile', 'linkedinurl'],
      labels: ['linkedin', 'linkedin profile', 'linkedin url', 'linkedin.com'],
      baseConf: 0.98
    },
    {
      type: 'GITHUB',
      attrs: ['github', 'github_url', 'github_profile', 'githuburl'],
      labels: ['github', 'github profile', 'github url', 'github.com'],
      baseConf: 0.98
    },
    {
      type: 'PORTFOLIO',
      attrs: ['portfolio', 'portfolio_url', 'personal_website', 'website_url'],
      labels: ['portfolio', 'portfolio url', 'personal website', 'personal site', 'showcase'],
      baseConf: 0.94
    },
    {
      type: 'WEBSITE',
      attrs: ['website', 'other_website', 'other_url', 'web_url', 'homepage'],
      labels: ['website', 'other website', 'url', 'link'],
      forbidden: ['linkedin', 'github', 'portfolio'],
      baseConf: 0.90
    },
    // Location
    {
      type: 'ZIP_CODE',
      attrs: ['zip', 'postal', 'pincode', 'pin_code', 'postcode', 'zip_code', 'postal_code'],
      labels: ['zip', 'postal code', 'zip code', 'pin code', 'pincode', 'postal'],
      autocompletes: ['postal-code'],
      baseConf: 0.95
    },
    {
      type: 'COUNTRY',
      attrs: ['country', 'country_name', 'candidate_country', 'country_id'],
      labels: ['country', 'country / region', 'country/region', 'nationality'],
      autocompletes: ['country', 'country-name'],
      forbidden: ['code', 'phone'],
      baseConf: 0.94
    },
    {
      type: 'STATE',
      attrs: ['state', 'province', 'region', 'state_province'],
      labels: ['state', 'province', 'state / province', 'region'],
      autocompletes: ['address-level1'],
      forbidden: ['state which', 'please state', 'state whether', 'state your', 'regulations', 'export'],
      baseConf: 0.92
    },
    {
      type: 'CITY',
      attrs: ['city', 'town', 'locality', 'location_city'],
      labels: ['city', 'town', 'city / town', 'location (city)'],
      autocompletes: ['address-level2'],
      baseConf: 0.93
    },
    {
      type: 'LOCATION_AUTOCOMPLETE',
      attrs: ['job_application_location', 'candidate_location', 'location_search', 'geo_location'],
      labels: ['location', 'current location', 'where are you located', 'city, state, country'],
      baseConf: 0.91
    },
    {
      type: 'ADDRESS',
      attrs: ['address', 'street', 'street_address', 'address_line_1'],
      labels: ['address', 'street address', 'address line 1', 'residential address'],
      autocompletes: ['street-address', 'address-line1'],
      forbidden: ['email', 'ip'],
      baseConf: 0.93
    },
    // Education
    {
      type: 'SCHOOL',
      attrs: ['school', 'university', 'college', 'institution', 'school--0'],
      labels: ['school', 'university', 'college', 'institution', 'school / university', 'college/university'],
      baseConf: 0.95
    },
    {
      type: 'DEGREE',
      attrs: ['degree', 'degree--0', 'education_level', 'highest_education', 'qualification'],
      labels: ['degree', 'degree level', 'highest degree', 'qualification', 'highest degree earned'],
      baseConf: 0.95
    },
    {
      type: 'DISCIPLINE',
      attrs: ['discipline', 'major', 'field_of_study', 'discipline--0', 'area_of_study'],
      labels: ['discipline', 'major', 'field of study', 'specialization', 'course'],
      baseConf: 0.96
    },
    {
      type: 'GRADUATION_YEAR',
      attrs: ['grad_year', 'graduation_year', 'gradyear', 'year_of_graduation'],
      labels: ['graduation year', 'year of graduation', 'grad year', 'expected graduation'],
      baseConf: 0.94
    },
    {
      type: 'GPA',
      attrs: ['gpa', 'grade_point_average', 'marks_cgpa', 'cgpa'],
      labels: ['gpa', 'cgpa', 'grade point average'],
      baseConf: 0.95
    },
    {
      type: 'START_MONTH',
      attrs: ['start_month', 'start-month', 'start_date_month'],
      labels: ['start date month', 'start month', 'from month'],
      baseConf: 0.93
    },
    {
      type: 'START_YEAR',
      attrs: ['start_year', 'start-year', 'start_date_year'],
      labels: ['start date year', 'start year', 'from year'],
      baseConf: 0.93
    },
    {
      type: 'END_MONTH',
      attrs: ['end_month', 'end-month', 'end_date_month'],
      labels: ['end date month', 'end month', 'to month'],
      baseConf: 0.93
    },
    {
      type: 'END_YEAR',
      attrs: ['end_year', 'end-year', 'end_date_year'],
      labels: ['end date year', 'end year', 'to year'],
      baseConf: 0.93
    },
    // Experience
    {
      type: 'COMPANY',
      attrs: ['company_name', 'employer', 'organization', 'work_company', 'previous_company'],
      labels: ['company', 'employer', 'current company', 'previous company', 'organization'],
      autocompletes: ['organization'],
      baseConf: 0.92
    },
    {
      type: 'EMPLOYMENT_TITLE',
      attrs: ['job_title', 'role_title', 'designation', 'position_title', 'current_title'],
      labels: ['job title', 'title', 'designation', 'current role', 'role'],
      autocompletes: ['organization-title'],
      baseConf: 0.92
    },
    {
      type: 'CURRENT_ROLE',
      attrs: ['is_current', 'currently_work_here', 'current_role', 'present_job'],
      labels: ['i currently work here', 'current role', 'presently working'],
      baseConf: 0.94
    },
    {
      type: 'WORK_DESCRIPTION',
      attrs: ['work_description', 'job_description', 'responsibilities', 'duties'],
      labels: ['description', 'responsibilities', 'summary of work', 'role description'],
      baseConf: 0.91
    },
    // Legal & Work Auth
    {
      type: 'WORK_AUTH',
      attrs: ['work_authorization', 'authorized_to_work', 'work_auth', 'legally_authorized'],
      labels: ['authorized to work', 'legally authorized', 'work authorization', 'right to work'],
      baseConf: 0.96
    },
    {
      type: 'VISA',
      attrs: ['visa_sponsorship', 'require_sponsorship', 'visa', 'sponsorship_required'],
      labels: ['require sponsorship', 'sponsorship', 'visa sponsorship', 'will you require sponsorship'],
      baseConf: 0.96
    },
    {
      type: 'SALARY',
      attrs: ['salary', 'compensation', 'expected_salary', 'desired_salary', 'hourly_rate'],
      labels: ['salary', 'desired salary', 'expected salary', 'compensation', 'salary expectation'],
      baseConf: 0.94
    },
    {
      type: 'NOTICE_PERIOD',
      attrs: ['notice_period', 'availability_days', 'notice', 'start_availability'],
      labels: ['notice period', 'how soon can you start', 'availability to start', 'days notice'],
      baseConf: 0.94
    },
    // Credentials
    {
      type: 'LOGIN_ID',
      attrs: ['login', 'username', 'login_id', 'user_name'],
      labels: ['login', 'username', 'login id', 'user id'],
      autocompletes: ['username'],
      baseConf: 0.94
    },
    {
      type: 'PASSWORD',
      attrs: ['password', 'user_password', 'passwd'],
      labels: ['password', 'create password', 'enter password'],
      autocompletes: ['new-password', 'current-password'],
      forbidden: ['confirm', 'verify', 'reenter', 're-enter'],
      baseConf: 0.97
    },
    {
      type: 'CONFIRM_PASSWORD',
      attrs: ['confirm_password', 'password_confirm', 'reenter_password', 'verify_password'],
      labels: ['confirm password', 're-enter password', 'verify password', 'retype password'],
      baseConf: 0.97
    },
    // Diversity & EEO
    {
      type: 'GENDER',
      attrs: ['gender', 'gender_identity', 'sex'],
      labels: ['gender', 'gender identity', 'what is your gender'],
      baseConf: 0.96
    },
    {
      type: 'RACE_ETHNICITY',
      attrs: ['race', 'ethnicity', 'race_ethnicity', 'ethnic_background'],
      labels: ['race', 'ethnicity', 'race/ethnicity', 'ethnic origin'],
      baseConf: 0.95
    },
    {
      type: 'HISPANIC_LATINO',
      attrs: ['hispanic', 'latino', 'hispanic_latino'],
      labels: ['hispanic', 'latino', 'hispanic or latino', 'are you hispanic/latino'],
      baseConf: 0.96
    },
    {
      type: 'VETERAN',
      attrs: ['veteran', 'veteran_status', 'military_status'],
      labels: ['veteran', 'veteran status', 'military service', 'protected veteran'],
      baseConf: 0.96
    },
    {
      type: 'DISABILITY',
      attrs: ['disability', 'disability_status', 'handicap'],
      labels: ['disability', 'disability status', 'do you have a disability'],
      baseConf: 0.96
    },
    // Logistics & Preferences
    {
      type: 'HEAR_ABOUT',
      attrs: ['hear_about', 'how_did_you_hear', 'referral_source', 'source'],
      labels: ['how did you hear about us', 'how did you hear', 'source', 'referral source'],
      baseConf: 0.95
    },
    {
      type: 'REFERRAL',
      attrs: ['referred_by', 'referrer', 'employee_referral'],
      labels: ['referred by', 'employee referral', 'who referred you'],
      baseConf: 0.94
    },
    {
      type: 'PREFERRED_LOCATION',
      attrs: ['preferred_location', 'desired_location', 'work_location'],
      labels: ['preferred location', 'desired location', 'preferred office', 'location preference'],
      baseConf: 0.92
    },
    {
      type: 'WORKPLACE_TYPE',
      attrs: ['workplace_type', 'work_mode', 'remote_preference'],
      labels: ['workplace type', 'remote / hybrid / onsite', 'work preference', 'work model'],
      baseConf: 0.93
    },
    // Consent
    {
      type: 'TEXT_CONSENT',
      attrs: ['sms_consent', 'text_consent', 'sms', 'text_message'],
      labels: ['text message', 'sms consent', 'consent to receive text messages', 'sms updates'],
      baseConf: 0.96
    },
    {
      type: 'PRIVACY_CONSENT',
      attrs: ['privacy_policy', 'privacy_consent', 'agree_terms', 'terms_consent'],
      labels: ['privacy policy', 'i agree to the privacy policy', 'terms and conditions', 'data processing consent'],
      baseConf: 0.96
    },
    // Open-ended / Custom Screening
    {
      type: 'COVER_LETTER',
      attrs: ['cover_letter', 'coverletter', 'letter_to_hiring_manager', 'message_to_recruiter'],
      labels: ['cover letter', 'message to hiring manager', 'why should we hire you', 'additional information'],
      baseConf: 0.93
    },
    {
      type: 'WHY_US',
      attrs: ['why_company', 'why_us', 'why_interested', 'whyus'],
      labels: ['why do you want to work', 'why do you want to work here', 'why are you interested in this role', 'why us', 'why our company', 'why our organization', 'interest in company'],
      baseConf: 0.94
    }
  ];

  function computeSemanticScoreForDOM(input) {
    if (!input) return null;

    const rawAttr = [
      input.getAttribute('name') || '',
      input.getAttribute('id') || '',
      input.getAttribute('placeholder') || '',
      input.getAttribute('autocomplete') || '',
      input.getAttribute('data-automation-id') || '',
      input.getAttribute('aria-label') || ''
    ].join(' ').toLowerCase();

    const cleanAttr = sfdClean(rawAttr);
    const compactAttr = sfdCompact(rawAttr);

    const rawLabel = (getLabelText(input) || '').toLowerCase();
    const cleanLabel = sfdClean(rawLabel);
    const compactLabel = sfdCompact(rawLabel);

    let contextSignal = '';
    let curr = input.parentElement;
    for (let depth = 0; depth < 4 && curr; depth++) {
      const cls = curr.getAttribute('class') || '';
      const id = curr.id || '';
      const heading = curr.querySelector('h1, h2, h3, h4, legend, .section-title, .form-title');
      const headingText = heading ? (heading.textContent || '') : '';
      contextSignal += ' ' + cls + ' ' + id + ' ' + headingText;
      curr = curr.parentElement;
    }
    const cleanContext = sfdClean(contextSignal);

    const autoSignal = (input.getAttribute('autocomplete') || '').toLowerCase().trim();
    const isCB = isComboboxOrSelect(input);
    const isSelect = input.tagName === 'SELECT' || isCB;
    const isTextarea = input.tagName === 'TEXTAREA';
    const isFile = input.tagName === 'INPUT' && input.type === 'file';

    // File Upload Fast Path
    if (isFile) {
      if (cleanAttr.includes('cover') || cleanLabel.includes('cover')) {
        return { fieldType: 'COVER_LETTER_FILE', confidence: 0.98, reasoning: 'File input matching cover letter' };
      }
      return { fieldType: 'RESUME', confidence: 0.99, reasoning: 'File input recognized as resume/CV' };
    }

    const isEmploymentSection =
      cleanContext.includes('employment') ||
      cleanContext.includes('experience') ||
      cleanContext.includes('job history') ||
      cleanAttr.includes('employment') ||
      cleanAttr.includes('job history');

    let best = { fieldType: 'UNKNOWN', confidence: 0.0, reasoning: '' };

    for (const pattern of SFD_TAXONOMY) {
      let score = 0.0;

      // Tag geometry constraints: Textarea can only match multi-line text fields
      if (isTextarea && ![
        'COVER_LETTER',
        'SCREENING',
        'NOTE',
        'WHY_US',
        'WORK_DESCRIPTION',
        'SUMMARY',
        'REASON_FOR_LEAVING'
      ].includes(pattern.type)) {
        continue;
      }

      // Phone numbers are scalar text/tel inputs, never comboboxes/dropdowns
      if (isSelect && pattern.type === 'PHONE') {
        continue;
      }

      if (pattern.forbidden && pattern.forbidden.some(f => cleanAttr.includes(f) || compactAttr.includes(f) || cleanLabel.includes(f))) {
        continue;
      }

      if (pattern.autocompletes && pattern.autocompletes.length > 0) {
        if (pattern.autocompletes.some(ac => autoSignal === ac || autoSignal.includes(ac))) {
          score += 0.60;
        }
      }

      if (cleanLabel) {
        for (const kw of pattern.labels) {
          const cleanKw = sfdClean(kw);
          if (rawLabel.includes(kw) || cleanLabel.includes(cleanKw) || compactLabel.includes(sfdCompact(kw))) {
            const isHighPrecisionLabel = cleanKw.split(' ').length >= 2 || cleanKw.length >= 6;
            score += isHighPrecisionLabel ? 0.85 : 0.65;
            break;
          }
        }
      }

      for (const kw of pattern.attrs) {
        if (rawAttr.includes(kw) || cleanAttr.includes(sfdClean(kw)) || compactAttr.includes(sfdCompact(kw))) {
          score += 0.45;
          break;
        }
      }

      let assignedType = pattern.type;
      if (isEmploymentSection) {
        if (assignedType === 'COUNTRY') assignedType = 'EXP_COUNTRY';
        else if (assignedType === 'STATE') assignedType = 'EXP_STATE';
        else if (assignedType === 'CITY') assignedType = 'EXP_CITY';
      }

      const conf = Math.min(1.0, score * pattern.baseConf);
      if (conf > best.confidence && conf >= 0.40) {
        best = {
          fieldType: assignedType,
          confidence: Number(conf.toFixed(2)),
          reasoning: `SFD V3 (${assignedType} @ ${(conf * 100).toFixed(0)}%)`
        };
      }
    }

    if (best.confidence < 0.50 || best.fieldType === 'UNKNOWN') {
      if (isSelect) {
        if (rawLabel.includes('?') || cleanLabel.includes('select') || cleanAttr.includes('question') || cleanAttr.includes('custom')) {
          return { fieldType: 'SCREENING_SELECT', confidence: 0.85, reasoning: 'SFD V3 (Screening Select Dropdown)' };
        }
      } else if (isTextarea) {
        if (
          rawLabel.includes('?') ||
          cleanLabel.includes('why') ||
          cleanLabel.includes('describe') ||
          cleanLabel.includes('explain') ||
          cleanLabel.includes('tell us') ||
          cleanLabel.includes('share') ||
          cleanLabel.includes('accomplish') ||
          cleanLabel.includes('achievement') ||
          cleanLabel.includes('proud') ||
          cleanLabel.includes('what is') ||
          cleanLabel.includes('what are') ||
          cleanLabel.includes('how do') ||
          cleanLabel.includes('how did') ||
          cleanAttr.includes('question')
        ) {
          return { fieldType: 'SCREENING', confidence: 0.88, reasoning: 'SFD V3 (Behavioral/Technical Textarea)' };
        }
        return { fieldType: 'NOTE', confidence: 0.75, reasoning: 'SFD V3 (Multi-line Note)' };
      } else if (cleanAttr.includes('question') || rawLabel.includes('?')) {
        return { fieldType: 'SCREENING', confidence: 0.82, reasoning: 'SFD V3 (Custom Screening Input)' };
      }
    }

    return best;
  }

  function classifyField(input) {
    // 0. AstrePilot V3 Form Schema Cache Hit (Network Effect Moat - 0ms)
    if (cachedSchemaMappings && (input.id || input.name)) {
      const key = input.id || input.name;
      const hit = cachedSchemaMappings.find(m => m.elementId === key);
      if (hit && hit.fieldType && hit.fieldType !== 'UNKNOWN') {
        try {
          input.__sfdConfidence = 1.0;
          input.__sfdReasoning = 'Form Schema Cache Hit (Verified)';
        } catch (e) {}
        return hit.fieldType;
      }
    }

    // 1. AstrePilot V3: Universal Semantic Field Discovery (SFD) Engine
    const sfdResult = computeSemanticScoreForDOM(input);
    if (sfdResult && sfdResult.confidence >= 0.75 && sfdResult.fieldType !== 'UNKNOWN') {
      try {
        input.__sfdConfidence = sfdResult.confidence;
        input.__sfdReasoning = sfdResult.reasoning;
      } catch (e) {}
      return sfdResult.fieldType;
    }

    const attrSignal = [
      (input.getAttribute('name') || '').toLowerCase(),
      (input.getAttribute('id') || '').toLowerCase(),
      (input.getAttribute('placeholder') || '').toLowerCase(),
      (input.getAttribute('autocomplete') || '').toLowerCase(),
      (input.getAttribute('data-automation-id') || '').toLowerCase(),
    ].join(' ');

    const labelSignal = getLabelText(input);

    let contextSignal = '';
    let curr = input.parentElement;
    for (let depth = 0; depth < 4 && curr; depth++) {
      const cls = curr.getAttribute('class') || '';
      const id = curr.id || '';
      const ariaLabel = curr.getAttribute('aria-label') || '';
      const heading = curr.querySelector('h1, h2, h3, h4, legend, .section-title, .form-title');
      const headingText = heading ? (heading.textContent || '') : '';
      contextSignal += ' ' + cls + ' ' + id + ' ' + ariaLabel + ' ' + headingText;
      curr = curr.parentElement;
    }
    contextSignal = contextSignal.toLowerCase();

    const isCB = isComboboxOrSelect(input);
    const isSelect = input.tagName === 'SELECT' || isCB;

    // 0. SECTION-AWARE FAST HEURISTICS: Employment pre-detection
    const isEmploymentSection = contextSignal.includes('employment') || contextSignal.includes('experience') || attrSignal.includes('employment') || attrSignal.includes('job_history') || labelSignal.includes('experience') || attrSignal.includes('experience');

    // 1. SELECT-SPECIFIC FAST HEURISTICS
    if (isSelect) {
      if ((labelSignal.includes('type') || attrSignal.includes('type')) && (contextSignal.includes('phone') || attrSignal.includes('phone'))) return 'PHONE_TYPE';
      if (attrSignal.includes('phone_type') || attrSignal.includes('phonetype')) return 'PHONE_TYPE';
      if ((labelSignal.includes('type') || attrSignal.includes('type')) && (contextSignal.includes('address') || attrSignal.includes('address'))) return 'ADDRESS_TYPE';
      if (labelSignal.includes('text consent') || labelSignal.includes('text message') || labelSignal.includes('sms') || attrSignal.includes('text_consent') || attrSignal.includes('sms')) {
        return 'TEXT_CONSENT';
      }
      if (labelSignal.includes('country') || attrSignal.includes('country')) return isEmploymentSection ? 'EXP_COUNTRY' : 'COUNTRY';
      if (labelSignal.includes('state') || labelSignal.includes('province') || attrSignal.includes('state') || attrSignal.includes('province')) {
        return isEmploymentSection ? 'EXP_STATE' : 'STATE';
      }
      if (labelSignal.includes('city') || attrSignal.includes('city') || labelSignal.includes('town')) {
        return isEmploymentSection ? 'EXP_CITY' : 'CITY';
      }
      if (labelSignal.includes('hear about') || labelSignal.includes('how did you hear') || labelSignal.includes('source') || attrSignal.includes('source') || attrSignal.includes('referral')) {
        if (labelSignal.includes('further') || labelSignal.includes('specify') || attrSignal.includes('specify') || attrSignal.includes('detail')) {
          return 'HEAR_ABOUT_DETAIL';
        }
        return 'HEAR_ABOUT';
      }
      if (labelSignal.includes('gender') || attrSignal.includes('gender') || labelSignal.includes('sex')) return 'GENDER';
      if (labelSignal.includes('pronoun') || attrSignal.includes('pronoun')) return 'PRONOUNS';
      if (labelSignal.includes('education') || labelSignal.includes('degree') || attrSignal.includes('education')) return 'EDUCATION';
      if (labelSignal.includes('relocate') || attrSignal.includes('relocate')) return 'RELOCATE';
      if (labelSignal.includes('authorized') || labelSignal.includes('work auth') || attrSignal.includes('work_auth')) return 'WORK_AUTH';
      if (labelSignal.includes('sponsorship') || labelSignal.includes('visa') || attrSignal.includes('visa')) return 'VISA';
      if (
        labelSignal.includes('preferred office') ||
        labelSignal.includes('office location') ||
        labelSignal.includes('preferred location') ||
        labelSignal.includes('location preference') ||
        labelSignal.includes('office preference') ||
        labelSignal.includes('workplace preference') ||
        labelSignal.includes('workplace') ||
        labelSignal.includes('work arrangement') ||
        labelSignal.includes('desired office') ||
        labelSignal.includes('desired location') ||
        labelSignal.includes('which office') ||
        labelSignal.includes('where would you like to work') ||
        attrSignal.includes('preferred_office') ||
        attrSignal.includes('preferred_location') ||
        attrSignal.includes('office_location') ||
        attrSignal.includes('workplace')
      ) {
        return 'PREFERRED_LOCATION';
      }
      if (labelSignal.includes('phone') || attrSignal.includes('phone')) return 'PHONE_TYPE'; // A select with phone is ALWAYS a phone type!
    }

    // 2. INPUT-SPECIFIC FAST HEURISTICS
    if (!isSelect) {
      if (input.type === 'file' || (input.tagName === 'INPUT' && input.type === 'file')) {
        if (labelSignal.includes('cover') || attrSignal.includes('cover') || labelSignal.includes('letter')) return 'COVER_LETTER';
        if (labelSignal.includes('transcript') || attrSignal.includes('transcript')) return null;
        if (labelSignal.includes('portfolio') || attrSignal.includes('portfolio')) return 'PORTFOLIO';
        return 'RESUME';
      }

      if (attrSignal.includes('dropzone') || attrSignal.includes('upload') || attrSignal.includes('resume-upload')) {
        if (labelSignal.includes('cover') || attrSignal.includes('cover')) return 'COVER_LETTER';
        if (labelSignal.includes('transcript') || attrSignal.includes('transcript')) return null;
        if (labelSignal.includes('resume') || labelSignal.includes('cv') || attrSignal.includes('resume') || attrSignal.includes('cv') || Boolean(input.querySelector && input.querySelector('input[type="file"]'))) {
          return 'RESUME';
        }
      }

      if (input.type === 'password' || attrSignal.includes('password') || labelSignal.includes('password')) {
        if (labelSignal.includes('confirm') || attrSignal.includes('confirm') || labelSignal.includes('re-enter') || labelSignal.includes('repeat') || labelSignal.includes('verify')) {
          return 'CONFIRM_PASSWORD';
        }
        return 'PASSWORD';
      }
      if (attrSignal.includes('username') || labelSignal.includes('username') || attrSignal.includes('login_id') || labelSignal.includes('login id')) {
        return 'LOGIN_ID';
      }

      if (input.type === 'tel') return 'PHONE';
      if ((labelSignal.includes('number') || attrSignal.includes('number')) && (contextSignal.includes('phone') || attrSignal.includes('phone'))) {
        return 'PHONE';
      }

      // Check ZIP and APT before generic ADDRESS so that compound IDs (e.g. iCIMS Address_PostalCode) don't hijack singleton ADDRESS
      if (labelSignal.includes('zip') || labelSignal.includes('postal') || attrSignal.includes('zip') || attrSignal.includes('postal') || labelSignal.includes('pin code') || labelSignal.includes('pincode') || attrSignal.includes('postalcode') || attrSignal.includes('postal_code') || attrSignal.includes('postal-code')) {
        return 'ZIP';
      }
      if (labelSignal.includes('address 2') || labelSignal.includes('address line 2') || attrSignal.includes('address2') || attrSignal.includes('address_2') || attrSignal.includes('line2') || attrSignal.includes('line_2') || labelSignal.includes('apartment') || labelSignal.includes('suite') || labelSignal.includes('apt')) {
        return 'APT';
      }
      if ((labelSignal.includes('address') || attrSignal.includes('address') || labelSignal.includes('street') || attrSignal.includes('street')) &&
          !labelSignal.includes('email') && !attrSignal.includes('email') &&
          !labelSignal.includes('web') && !attrSignal.includes('url') &&
          !labelSignal.includes('zip') && !attrSignal.includes('zip') &&
          !labelSignal.includes('postal') && !attrSignal.includes('postal') &&
          !labelSignal.includes('city') && !attrSignal.includes('city') &&
          !labelSignal.includes('state') && !attrSignal.includes('state') &&
          !labelSignal.includes('country') && !attrSignal.includes('country')) {
        return 'ADDRESS';
      }
      if (labelSignal.includes('city') || attrSignal.includes('city') || labelSignal.includes('town')) {
        return isEmploymentSection ? 'EXP_CITY' : 'CITY';
      }
      if (labelSignal.includes('state') || labelSignal.includes('province') || attrSignal.includes('state') || attrSignal.includes('province')) {
        return isEmploymentSection ? 'EXP_STATE' : 'STATE';
      }
      if (labelSignal.includes('country') || attrSignal.includes('country')) {
        return isEmploymentSection ? 'EXP_COUNTRY' : 'COUNTRY';
      }
    }

    // 3. SECTION-AWARE FAST HEURISTICS: Employment
    if (isEmploymentSection) {
      if (labelSignal.includes('company') || attrSignal.includes('company') || labelSignal.includes('employer') || attrSignal.includes('employer') || labelSignal.includes('organization')) return 'COMPANY';
      if ((labelSignal.includes('title') || attrSignal.includes('title')) && !labelSignal.includes('degree')) return 'EMPLOYMENT_TITLE';
      
      if (labelSignal.includes('reason for leaving') || labelSignal.includes('reason') || attrSignal.includes('reason_for_leaving') || attrSignal.includes('leaving_reason')) {
        return 'REASON_FOR_LEAVING';
      }

      if (input.type === 'checkbox' && (labelSignal.includes('current') || attrSignal.includes('current'))) return 'CURRENT_ROLE';
      if (input.tagName === 'TEXTAREA' || labelSignal.includes('description') || labelSignal.includes('responsibilities') || labelSignal.includes('duties') || attrSignal.includes('description') || attrSignal.includes('responsibilities')) {
        return 'WORK_DESCRIPTION';
      }
    }

    // 4. ANTICIPATED GRADUATION YEAR (High Priority before generic date parser)
    if (labelSignal.includes('anticipate graduating') || labelSignal.includes('graduation year') || labelSignal.includes('graduating year') || labelSignal.includes('year you anticipate') || attrSignal.includes('graduation_year')) {
      return 'GRADUATION_YEAR';
    }

    // 4b. GLOBAL DATE DISAMBIGUATION (Month, Day, Year) in Employment or Education
    const isStart = labelSignal.includes('start') || attrSignal.includes('start') || labelSignal.includes('from') || attrSignal.includes('from');
    const isEnd = labelSignal.includes('end') || attrSignal.includes('end') || labelSignal.includes('to') || attrSignal.includes('to') || (labelSignal.includes('graduat') && !labelSignal.includes('anticipate'));
    if (isStart || isEnd) {
      if (attrSignal.includes('year') || (labelSignal.includes('year') && !labelSignal.includes('month'))) {
        return isEnd ? 'END_YEAR' : 'START_YEAR';
      }
      if (attrSignal.includes('day') || (labelSignal.includes('day') && !labelSignal.includes('month') && !labelSignal.includes('year'))) {
        return isEnd ? 'END_DAY' : 'START_DAY';
      }
      if (attrSignal.includes('month') || (labelSignal.includes('month') && !labelSignal.includes('year'))) {
        return isEnd ? 'END_MONTH' : 'START_MONTH';
      }
      if (isStart) return (labelSignal.includes('month') || isSelect) ? 'START_MONTH' : 'START_YEAR';
      if (isEnd) return (labelSignal.includes('month') || isSelect) ? 'END_MONTH' : 'END_YEAR';
    }

    if (labelSignal.includes('which language') || labelSignal.includes('business fluent') || (labelSignal.includes('language') && labelSignal.includes('fluent')) || attrSignal.includes('language')) {
      return 'LANGUAGES';
    }

    // 5. GLOBAL EDUCATION HEURISTICS (School, Degree, Discipline)
    if (labelSignal.includes('school') || labelSignal.includes('university') || labelSignal.includes('college') || labelSignal.includes('institution') || attrSignal.includes('school')) return 'SCHOOL';
    if (labelSignal.includes('degree') || attrSignal.includes('degree')) return 'DEGREE';
    if (labelSignal.includes('discipline') || labelSignal.includes('major') || labelSignal.includes('field of study') || attrSignal.includes('discipline') || attrSignal.includes('major')) return 'DISCIPLINE';

    // 5. SPECIFIC QUESTIONS & COMPLIANCE HEURISTICS
    if (labelSignal.includes('text consent') || labelSignal.includes('text message') || labelSignal.includes('sms') || attrSignal.includes('text_consent') || attrSignal.includes('sms')) return 'TEXT_CONSENT';
    if (labelSignal.includes('18 years') || labelSignal.includes('at least 18') || attrSignal.includes('18_years') || attrSignal.includes('age_18')) return 'AGE_18';
    if (labelSignal.includes('previously been employed') || labelSignal.includes('previously employed') || labelSignal.includes('employed by coinbase') || labelSignal.includes('prior employment')) return 'PREVIOUS_EMPLOYED';
    if (labelSignal.includes('privacy notice') || labelSignal.includes('arbitration agreement') || labelSignal.includes('global data privacy') || labelSignal.includes('receipt of the above linked')) return 'PRIVACY_CONSENT';
    if (labelSignal.includes('may use ai tools') || labelSignal.includes('use ai tools to assist')) return 'AI_CONSENT';
    if (labelSignal.includes('how you use ai') || labelSignal.includes('use ai tools today') || labelSignal.includes('describes how you use ai')) return 'AI_USAGE';
    if (labelSignal.includes('close relative') && (labelSignal.includes('government') || labelSignal.includes('official'))) return 'GOVT_RELATIVE';
    if ((labelSignal.includes('government official') || labelSignal.includes('civil service') || labelSignal.includes('holder of public office')) && !labelSignal.includes('relative')) return 'GOVT_OFFICIAL';
    if (labelSignal.includes('conflict of interest') || labelSignal.includes('perceived conflict') || labelSignal.includes('actual or perceived conflict')) return 'CONFLICT_INTEREST';
    if (labelSignal.includes('referred to this position by a senior') || labelSignal.includes('senior leader or decision-maker') || labelSignal.includes('institutional client, business partner, or vendor')) return 'REFERRED_BY_LEADER';
    if (labelSignal.includes('hispanic') || labelSignal.includes('latino')) return 'HISPANIC_LATINO';
    if (labelSignal.includes('veteran') || labelSignal.includes('vevraa')) return 'VETERAN';
    if (labelSignal.includes('disability') || labelSignal.includes('impairment')) return 'DISABILITY';
    if ((labelSignal.includes('race') || labelSignal.includes('ethnicity')) && !labelSignal.includes('hispanic')) return 'RACE_ETHNICITY';

    if (
      labelSignal.includes('preferred office') ||
      labelSignal.includes('office location') ||
      labelSignal.includes('preferred location') ||
      labelSignal.includes('location preference') ||
      labelSignal.includes('office preference') ||
      labelSignal.includes('workplace preference') ||
      labelSignal.includes('work arrangement') ||
      labelSignal.includes('desired office') ||
      labelSignal.includes('desired location') ||
      labelSignal.includes('which office') ||
      labelSignal.includes('where would you like to work') ||
      attrSignal.includes('preferred_office') ||
      attrSignal.includes('preferred_location') ||
      attrSignal.includes('office_location') ||
      attrSignal.includes('workplace')
    ) {
      return 'PREFERRED_LOCATION';
    }

    let best = { type: null, score: 0 };
    FIELD_PATTERNS.forEach(p => {
      if (isSelect && p.type === 'PHONE') return;
      let score = 0;
      p.kw.forEach(k => {
        if (kwMatch(attrSignal, k)) score += 10;
        if (kwMatch(labelSignal, k)) score += 3;
        if (kwMatch(contextSignal, k)) score += 1;
      });
      if (score > best.score) best = { type: p.type, score };
    });

    if (!best.type || best.score < 3) {
      if (input.tagName === 'TEXTAREA') return 'SCREENING';
      if (isSelect) {
        if (labelSignal.includes('?') || labelSignal.includes('*') || input.getAttribute('aria-required') === 'true' || attrSignal.includes('question') || Boolean(input.closest && input.closest('.field, .question, [class*="question"], [class*="field"], .field-wrapper'))) {
          return 'SCREENING_SELECT';
        }
      }
      if (input.tagName === 'INPUT' && (labelSignal.includes('?') || labelSignal.includes('*') || labelSignal.includes('please list') || labelSignal.includes('please describe') || labelSignal.includes('type n/a') || labelSignal.includes('names of') || input.required || input.getAttribute('aria-required') === 'true' || attrSignal.includes('question_'))) {
        return 'SCREENING';
      }
      return null;
    }
    return best.type;
  }

  /* =========================================================================
     ATS SPECIALIZED DRIVER ENGINE (MODULAR ARCHITECTURE)
     ========================================================================= */

  function isIcimsEnvironment(targetDocs = [document]) {
    try {
      const host = (window.location.hostname || '').toLowerCase();
      const href = (window.location.href || '').toLowerCase();
      if (host.includes('icims.com') || href.includes('icims.com') || href.includes('icims_content_iframe')) return true;
      for (const doc of targetDocs) {
        if (!doc) continue;
        if (doc.querySelector('#icims_content_iframe, [id*="PersonProfileFields"], [id*="PortalProfileFields"], [name*="PersonProfileFields"], [name*="PortalProfileFields"], table.iCIMS_Table, .iCIMS_MainWrapper, .iCIMS_JobHeader')) {
          return true;
        }
      }
    } catch (e) {}
    return false;
  }

  function scanIcimsFields(targetDoc) {
    if (!targetDoc) return { fields: [], seenElements: new Set() };
    const fields = [];
    const seenElements = new Set();

    // Deterministic Selector Mapping Table for iCIMS / Cotiviti Enterprise Portals
    const ICIMS_EXACT_MAP = [
      // 1. Resume File Upload
      {
        type: 'RESUME',
        selectors: [
          'input#PortalProfileFields\\.Resume_File',
          'input[name="PortalProfileFields.Resume_File"]',
          'input[id*="Resume_File"]',
          'input[type="file"][name*="Resume"]',
          'input[type="file"]'
        ]
      },
      // 2. Login Credentials
      {
        type: 'LOGIN_ID',
        selectors: [
          'input#PersonProfileFields\\.Login',
          'input[name="PersonProfileFields.Login"]',
          'input[id$="Login"]'
        ]
      },
      {
        type: 'PASSWORD',
        selectors: [
          'input#PersonProfileFields\\.Password',
          'input[name="PersonProfileFields.Password"]',
          'input[type="password"]:not([id*="Confirm"]):not([name*="Confirm"]):not([id*="_Confirm"])'
        ]
      },
      {
        type: 'CONFIRM_PASSWORD',
        selectors: [
          'input#PersonProfileFields\\.Password_Confirm',
          'input[name="PersonProfileFields.Password_Confirm"]',
          'input[type="password"][id*="Confirm"]',
          'input[type="password"][name*="Confirm"]'
        ]
      },
      // 3. Candidate Identity
      {
        type: 'FIRST_NAME',
        selectors: [
          'input#PersonProfileFields\\.FirstName',
          'input[name="PersonProfileFields.FirstName"]',
          'input[id$="FirstName"]'
        ]
      },
      {
        type: 'LAST_NAME',
        selectors: [
          'input#PersonProfileFields\\.LastName',
          'input[name="PersonProfileFields.LastName"]',
          'input[id$="LastName"]'
        ]
      },
      {
        type: 'EMAIL',
        selectors: [
          'input#PersonProfileFields\\.Email',
          'input[name="PersonProfileFields.Email"]',
          'input[id$="Email"]'
        ]
      },
      {
        type: 'PREFERRED_NAME',
        selectors: [
          'input#rcf2039',
          'input[name="rcf2039"]',
          'input[id$="rcf2039"]'
        ]
      },
      // 4. Phone
      {
        type: 'PHONE_TYPE',
        selectors: [
          'select#-1_PersonProfileFields\\.PhoneType',
          'select[name$="PhoneType"]',
          'select[id$="PhoneType"]'
        ]
      },
      {
        type: 'PHONE',
        selectors: [
          'input#-1_PersonProfileFields\\.PhoneNumber',
          'input[name$="PhoneNumber"]',
          'input[id$="PhoneNumber"]'
        ]
      },
      // 5. SMS / Text Consent
      {
        type: 'TEXT_CONSENT',
        selectors: [
          'select#rcf3553',
          'select[name="rcf3553"]',
          'select[id$="rcf3553"]',
          'select[name*="rcf3553"]'
        ]
      },
      // 6. Address Block
      {
        type: 'ADDRESS_TYPE',
        selectors: [
          'select#-1_PersonProfileFields\\.AddressType',
          'select[name$="AddressType"]',
          'select[id$="AddressType"]'
        ]
      },
      {
        type: 'ADDRESS',
        selectors: [
          'input#-1_PersonProfileFields\\.AddressStreet1',
          'input[name$="AddressStreet1"]',
          'input[id$="AddressStreet1"]'
        ]
      },
      {
        type: 'APT',
        selectors: [
          'input#-1_PersonProfileFields\\.AddressStreet2',
          'input[name$="AddressStreet2"]',
          'input[id$="AddressStreet2"]'
        ]
      },
      {
        type: 'CITY',
        selectors: [
          'input#-1_PersonProfileFields\\.AddressCity',
          'input[name$="AddressCity"]',
          'input[id$="AddressCity"]'
        ]
      },
      {
        type: 'ZIP',
        selectors: [
          'input#-1_PersonProfileFields\\.AddressZip',
          'input[name$="AddressZip"]',
          'input[id$="AddressZip"]'
        ]
      },
      {
        type: 'COUNTRY',
        selectors: [
          'select#-1_PersonProfileFields\\.AddressCountry',
          'select[name$="AddressCountry"]',
          'select[id$="AddressCountry"]'
        ]
      },
      {
        type: 'STATE',
        selectors: [
          'select#-1_PersonProfileFields\\.AddressState',
          'select[name$="AddressState"]',
          'select[id$="AddressState"]'
        ]
      },
      // 7. Referral Sources
      {
        type: 'HEAR_ABOUT',
        selectors: [
          'select#rcf3048',
          'select[name="rcf3048"]',
          'select[id$="rcf3048"]',
          'select[name*="rcf3048"]'
        ]
      },
      {
        type: 'HEAR_ABOUT_DETAIL',
        selectors: [
          'select#rcf3049',
          'select[name="rcf3049"]',
          'select[id$="rcf3049"]',
          'input#rcf3049_Text',
          'input[name="rcf3049_Text"]',
          'input[id$="rcf3049_Text"]'
        ]
      },
      // 8. Work Experience / Employment Block (All custom Cotiviti/iCIMS IDs)
      {
        type: 'COMPANY',
        selectors: [
          'input#-1_PersonProfileFields\\.rcf3212',
          'input[name$="rcf3212"]',
          'input[id$="rcf3212"]',
          'input[name*="rcf3212"]'
        ]
      },
      {
        type: 'EXP_STATE',
        selectors: [
          'select#-1_PersonProfileFields\\.rcf3217',
          'select[name$="rcf3217"]',
          'select[id$="rcf3217"]',
          'select[name*="rcf3217"]'
        ]
      },
      {
        type: 'EMPLOYMENT_TITLE',
        selectors: [
          'input#-1_PersonProfileFields\\.rcf3213',
          'input[name$="rcf3213"]',
          'input[id$="rcf3213"]',
          'input[name*="rcf3213"]'
        ]
      },
      {
        type: 'START_MONTH',
        selectors: [
          'select#-1_PersonProfileFields\\.rcf3214_Month',
          'select[name$="rcf3214_Month"]',
          'select[id$="rcf3214_Month"]'
        ]
      },
      {
        type: 'START_DAY',
        selectors: [
          'select#-1_PersonProfileFields\\.rcf3214_Date',
          'select[name$="rcf3214_Date"]',
          'select[id$="rcf3214_Date"]'
        ]
      },
      {
        type: 'START_YEAR',
        selectors: [
          'input#-1_PersonProfileFields\\.rcf3214_Year',
          'input[name$="rcf3214_Year"]',
          'input[id$="rcf3214_Year"]'
        ]
      },
      {
        type: 'END_MONTH',
        selectors: [
          'select#-1_PersonProfileFields\\.rcf3215_Month',
          'select[name$="rcf3215_Month"]',
          'select[id$="rcf3215_Month"]'
        ]
      },
      {
        type: 'END_DAY',
        selectors: [
          'select#-1_PersonProfileFields\\.rcf3215_Date',
          'select[name$="rcf3215_Date"]',
          'select[id$="rcf3215_Date"]'
        ]
      },
      {
        type: 'END_YEAR',
        selectors: [
          'input#-1_PersonProfileFields\\.rcf3215_Year',
          'input[name$="rcf3215_Year"]',
          'input[id$="rcf3215_Year"]'
        ]
      },
      {
        type: 'WORK_DESCRIPTION',
        selectors: [
          'textarea#-1_PersonProfileFields\\.rcf3219',
          'textarea[name$="rcf3219"]',
          'textarea[id$="rcf3219"]'
        ]
      },
      {
        type: 'REASON_FOR_LEAVING',
        selectors: [
          'textarea#-1_PersonProfileFields\\.rcf3268',
          'textarea[name$="rcf3268"]',
          'textarea[id$="rcf3268"]'
        ]
      }
    ];

    ICIMS_EXACT_MAP.forEach(item => {
      let el = null;
      for (const sel of item.selectors) {
        try {
          const match = targetDoc.querySelector(sel);
          if (match && !seenElements.has(match)) {
            el = match;
            break;
          }
        } catch (e) {}
      }
      if (el) {
        seenElements.add(el);
        const origVal = (el.tagName === 'INPUT' && (el.type === 'radio' || el.type === 'checkbox'))
          ? el.checked
          : (el.value !== undefined ? el.value : (el.innerText || el.textContent || ''));
        const elId = el.id || el.name || '';
        const safeId = elId ? elId.replace(/[^a-zA-Z0-9_-]/g, '_') : ('icims_' + fields.length);
        fields.push({
          element: el,
          type: item.type,
          id: item.type.toLowerCase() + '_' + safeId,
          originalValue: origVal,
          atsDriver: 'iCIMS'
        });
      }
    });

    return { fields, seenElements };
  }

  function isGreenhouseEnvironment(targetDocs = [document]) {
    try {
      const host = (window.location.hostname || '').toLowerCase();
      const href = (window.location.href || '').toLowerCase();
      if (host.includes('greenhouse.io') || href.includes('greenhouse.io') || href.includes('job_app')) return true;
      for (const doc of targetDocs) {
        if (!doc) continue;
        if (doc.querySelector('form#application-form, .job-boards-greenhouse, .select-shell, [id^="school--0"]')) {
          return true;
        }
      }
    } catch (e) {}
    return false;
  }

  function scanGreenhouseFields(targetDoc) {
    if (!targetDoc) return { fields: [], seenElements: new Set() };
    const fields = [];
    const seenElements = new Set();

    const GREENHOUSE_EXACT_MAP = [
      { type: 'FIRST_NAME', selectors: ['input#first_name', 'input[name="first_name"]', '#first_name'] },
      { type: 'LAST_NAME', selectors: ['input#last_name', 'input[name="last_name"]', '#last_name'] },
      { type: 'PREFERRED_NAME', selectors: ['input#preferred_name', 'input[name="preferred_name"]', '#preferred_name'] },
      { type: 'EMAIL', selectors: ['input#email', 'input[name="email"]', '#email'] },
      { type: 'PHONE', selectors: ['input#phone', 'input[name="phone"]', '#phone'] },
      { type: 'COUNTRY', selectors: ['input#country', '#country', 'select#country', '[name*="country" i]'] },
      { type: 'CITY', selectors: ['input#candidate-location', 'input[name="candidate_location"]', '#candidate-location', '[name*="location"]', '[id*="candidate_location"]'] },
      { type: 'ADDRESS', selectors: ['#question_69351126', 'input[name*="address" i]', '#address', '[id*="full_address" i]', '[id*="street_address" i]'] },
      { type: 'RESUME', selectors: ['input#resume[type="file"]', 'input[type="file"][name*="resume"]', 'input[type="file"]'] },
      { type: 'SCHOOL', selectors: ['input#school--0', '#school--0', '[id^="school--"]', '[id*="school"]'] },
      { type: 'DEGREE', selectors: ['input#degree--0', '#degree--0', '[id^="degree--"]', '[id*="degree"]'] },
      { type: 'DISCIPLINE', selectors: ['input#discipline--0', '#discipline--0', '[id^="discipline--"]', '[id*="discipline"]'] },
      { type: 'START_MONTH', selectors: ['#start-month--0', '[id^="start-month--"]', 'select[name*="start_month"]', 'input[name*="start_month"]', '[id*="start_date_month"]', '[name*="start_date_month"]', '[aria-label*="start date month" i]'] },
      { type: 'START_YEAR', selectors: ['#start-year--0', '[id^="start-year--"]', 'input[name*="start_year"]', '[id*="start_date_year"]', '[name*="start_date_year"]', '[aria-label*="start date year" i]'] },
      { type: 'END_MONTH', selectors: ['#end-month--0', '[id^="end-month--"]', 'select[name*="end_month"]', 'input[name*="end_month"]', '[id*="end_date_month"]', '[name*="end_date_month"]', '[aria-label*="end date month" i]'] },
      { type: 'END_YEAR', selectors: ['#end-year--0', '[id^="end-year--"]', 'input[name*="end_year"]', '[id*="end_date_year"]', '[name*="end_date_year"]', '[aria-label*="end date year" i]'] },
      { type: 'GRADUATION_YEAR', selectors: ['#question_69351114', '[id*="graduation_date" i]', '[id*="grad_date" i]', '[aria-label*="graduation date" i]'] },
      { type: 'LINKEDIN', selectors: ['#question_69351116', 'input[name*="linkedin" i]', '#linkedin', '[aria-label*="linkedin" i]'] },
      { type: 'GITHUB', selectors: ['#question_69351117', 'input[name*="github" i]', '#github', '[aria-label*="github" i]'] },
      { type: 'PORTFOLIO', selectors: ['#question_69351119', 'input[name*="website" i]', '#website', '#portfolio', '[aria-label*="website" i]'] },
      { type: 'VISA', selectors: ['#question_69351122', '[id*="sponsorship" i]', '[aria-label*="visa sponsorship" i]'] },
      { type: 'WORK_AUTH', selectors: ['#question_69351123', '[id*="work_auth" i]', '[aria-label*="legally authorized" i]'] },
      { type: 'RELOCATE', selectors: ['#question_69351124', '[id*="relocate" i]', '[aria-label*="relocate" i]'] },
      { type: 'AGE_18', selectors: ['#question_69351127', '[id*="age_18" i]', '[id*="18_years" i]', '[aria-label*="18 years" i]'] },
      { type: 'LANGUAGES', selectors: ['[id*="question_69351128"]', '[id*="language" i]', '[aria-label*="language" i]'] },
      { type: 'PRIVACY_CONSENT', selectors: ['#question_69351131', '#question_69351134', '[id*="privacy_notice" i]', '[aria-label*="privacy notice" i]'] },
      { type: 'PREVIOUS_EMPLOYED', selectors: ['#question_69351132', '#question_69351133', '#question_69351135'] },
      { type: 'GENDER', selectors: ['#question_69351130', '[id*="question_"][aria-label*="gender" i]'] },
      { type: 'GENDER', selectors: ['#gender', 'input#gender', 'select#gender', '[name="gender"]', '[id="gender"]'] },
      { type: 'HISPANIC_LATINO', selectors: ['#hispanic_ethnicity', 'input#hispanic_ethnicity', 'select#hispanic_ethnicity', '[name*="hispanic"]'] },
      { type: 'RACE_ETHNICITY', selectors: ['#race', 'input#race', 'select#race', 'input[name*="race" i]', 'select[name*="race" i]', '[id="race"]', '[name="race"]', '[aria-label*="race" i]'] },
      { type: 'VETERAN', selectors: ['#veteran_status', 'input#veteran_status', 'select#veteran_status', '[name*="veteran"]'] },
      { type: 'DISABILITY', selectors: ['#disability_status', 'input#disability_status', 'select#disability_status', '[name*="disability"]'] },
      { type: 'SCREENING_SELECT', selectors: ['#question_69351112'] },
      { type: 'SCREENING', selectors: ['#question_69351113'] },
      { type: 'SCREENING_SELECT', selectors: ['#question_69351115'] },
      { type: 'SCREENING', selectors: ['#question_69351125'] }
    ];

    GREENHOUSE_EXACT_MAP.forEach(item => {
      let el = null;
      for (const sel of item.selectors) {
        try {
          const found = targetDoc.querySelector(sel);
          if (found) { el = found; break; }
        } catch (e) {}
      }
      if (el) {
        let interactive = el;
        if (el.tagName !== 'INPUT' && el.tagName !== 'SELECT' && el.tagName !== 'TEXTAREA') {
          const inner = el.querySelector('input, select, textarea, [role="combobox"]');
          if (inner) interactive = inner;
        }
        if (!interactive || interactive.tagName === 'LABEL' || (interactive.tagName === 'INPUT' && interactive.type === 'hidden')) {
          return;
        }
        seenElements.add(interactive);
        seenElements.add(el);
        const origVal = (interactive.tagName === 'INPUT' && (interactive.type === 'radio' || interactive.type === 'checkbox'))
          ? interactive.checked
          : (interactive.value !== undefined ? interactive.value : (interactive.innerText || interactive.textContent || ''));
        const elId = interactive.id || interactive.name || el.id || el.name || '';
        const safeId = elId ? elId.replace(/[^a-zA-Z0-9_-]/g, '_') : ('gh_' + fields.length);
        fields.push({
          element: interactive,
          type: item.type,
          id: item.type.toLowerCase() + '_' + safeId,
          originalValue: origVal,
          atsDriver: 'Greenhouse'
        });
      }
    });

    // Dynamic Discovery: Scan all custom questions on Greenhouse (e.g. question_862292xxxx on Astranis)
    try {
      const dynamicQuestions = targetDoc.querySelectorAll('[id^="question_"], [name*="question_"], [name*="answers_attributes"]');
      dynamicQuestions.forEach(el => {
        if (!el || seenElements.has(el)) return;
        if (el.tagName === 'LABEL' || (el.tagName === 'INPUT' && el.type === 'hidden')) return;

        let interactive = el;
        if (el.tagName !== 'INPUT' && el.tagName !== 'SELECT' && el.tagName !== 'TEXTAREA') {
          const inner = el.querySelector('input, select, textarea, [role="combobox"]');
          if (inner) interactive = inner;
        }
        if (seenElements.has(interactive)) return;

        seenElements.add(interactive);
        seenElements.add(el);

        const aria = (interactive.getAttribute('aria-label') || el.getAttribute('aria-label') || '').toLowerCase();
        const container = interactive.closest('div[class*="field"], div[class*="select"], label, fieldset') || interactive.parentElement;
        const labelText = ((container && container.textContent) || aria || '').toLowerCase();

        let fieldType = 'SCREENING';
        if (interactive.classList.contains('select__input') || interactive.tagName === 'SELECT' || isComboboxOrSelect(interactive)) {
          fieldType = 'SCREENING_SELECT';
        } else if (labelText.includes('linkedin')) {
          fieldType = 'LINKEDIN';
        } else if (labelText.includes('github')) {
          fieldType = 'GITHUB';
        } else if (labelText.includes('website') || labelText.includes('portfolio')) {
          fieldType = 'PORTFOLIO';
        } else if (labelText.includes('hear about') || labelText.includes('referral')) {
          fieldType = 'HEAR_ABOUT';
        } else if (labelText.includes('sponsor') || labelText.includes('visa')) {
          fieldType = 'VISA';
        } else if (labelText.includes('authorized') || labelText.includes('work auth')) {
          fieldType = 'WORK_AUTH';
        }

        const origVal = (interactive.tagName === 'INPUT' && (interactive.type === 'radio' || interactive.type === 'checkbox'))
          ? interactive.checked
          : (interactive.value !== undefined ? interactive.value : (interactive.innerText || interactive.textContent || ''));
        const elId = interactive.id || interactive.name || el.id || el.name || '';
        const safeId = elId ? elId.replace(/[^a-zA-Z0-9_-]/g, '_') : ('gh_q_' + fields.length);

        fields.push({
          element: interactive,
          type: fieldType,
          id: fieldType.toLowerCase() + '_' + safeId,
          originalValue: origVal,
          atsDriver: 'Greenhouse'
        });
      });
    } catch (dynErr) {
      console.warn('[AstrePilot] Dynamic Greenhouse questions scan error:', dynErr);
    }

    return { fields, seenElements };
  }

  function isBreezyEnvironment(targetDocs = [document]) {
    try {
      const host = (window.location.hostname || '').toLowerCase();
      const href = (window.location.href || '').toLowerCase();
      if (host.includes('breezy.hr') || href.includes('breezy.hr')) return true;
      for (const doc of targetDocs) {
        if (!doc) continue;
        if (doc.querySelector('input[name="cResume"], input[name="cName"], input[name="cEmail"], input#main-attachment, .bzyButtonColor')) {
          return true;
        }
      }
    } catch (e) {}
    return false;
  }

  function scanBreezyFields(targetDoc) {
    if (!targetDoc) return { fields: [], seenElements: new Set() };
    const fields = [];
    const seenElements = new Set();

    // Breezy HR Deterministic Map
    const BREEZY_EXACT_MAP = [
      { type: 'RESUME', selectors: ['input#main-attachment', 'input[name="cResume"]', 'input[type="file"]'] },
      { type: 'FULL_NAME', selectors: ['input[name="cName"]', 'input[placeholder*="Full Name" i]'] },
      { type: 'EMAIL', selectors: ['input[name="cEmail"]', 'input[type="email"]'] },
      { type: 'PHONE', selectors: ['input[name="cPhoneNumber"]', 'input[placeholder*="Phone Number" i]'] },
      { type: 'TEXT_CONSENT', selectors: ['input[name="smsConsent"]', 'input[type="checkbox"][name*="sms" i]'] },
      { type: 'ADDRESS', selectors: ['#fullAddress', 'input[name="cAddress"]', 'input[placeholder*="Address" i]'] },
      { type: 'SUMMARY', selectors: ['textarea[name="cSummary"]'] },
      { type: 'COVER_LETTER', selectors: ['textarea[name="cCoverLetter"]'] }
    ];

    // Explicitly blacklist Breezy HR honeypots to prevent bot traps
    const honeypots = targetDoc.querySelectorAll('input[name*="hp_"], input[id*="hp_"], .apply-field-extra input');
    honeypots.forEach(hp => seenElements.add(hp));

    BREEZY_EXACT_MAP.forEach(item => {
      let el = null;
      for (const sel of item.selectors) {
        try {
          const found = targetDoc.querySelector(sel);
          if (found) { el = found; break; }
        } catch (e) {}
      }
      if (el && !seenElements.has(el)) {
        seenElements.add(el);
        const origVal = (el.tagName === 'INPUT' && (el.type === 'radio' || el.type === 'checkbox'))
          ? el.checked
          : (el.value !== undefined ? el.value : (el.innerText || el.textContent || ''));
        const elId = el.id || el.name || '';
        const safeId = elId ? elId.replace(/[^a-zA-Z0-9_-]/g, '_') : ('bzy_' + fields.length);
        fields.push({
          element: el,
          type: item.type,
          id: item.type.toLowerCase() + '_' + safeId,
          originalValue: origVal,
          atsDriver: 'BreezyHR'
        });
      }
    });

    return { fields, seenElements };
  }

  /* -- DEEP SHADOW DOM WALKER (PILLAR 1) -- */
  function deepQuerySelectorAll(root, selector) {
    if (!root) return [];
    let results = [];
    try {
      results = Array.from(root.querySelectorAll(selector));
    } catch (e) {}

    try {
      const doc = root.ownerDocument || (root.nodeType === 9 ? root : document);
      const walker = doc.createTreeWalker(root, NodeFilter.SHOW_ELEMENT, null, false);
      let currentNode = walker.nextNode();
      while (currentNode) {
        if (currentNode.shadowRoot) {
          try {
            const shadowMatches = deepQuerySelectorAll(currentNode.shadowRoot, selector);
            results = results.concat(shadowMatches);
          } catch (err) {}
        }
        currentNode = walker.nextNode();
      }
    } catch (e) {}

    return results;
  }

  /* -- WORKDAY DETERMINISTIC DRIVER (PILLAR 2) -- */
  function isWorkdayEnvironment(targetDocs = [document]) {
    try {
      const host = (window.location.hostname || '').toLowerCase();
      const href = (window.location.href || '').toLowerCase();
      if (host.includes('myworkdayjobs.com') || host.includes('.myworkday.com') || href.includes('myworkdayjobs.com')) return true;
      for (const doc of targetDocs) {
        if (!doc) continue;
        if (doc.querySelector('[data-automation-id="workdayApplication"], [data-automation-id="legalNameSection_firstName"], [data-automation-id="bottom-navigation-next-button"]')) {
          return true;
        }
      }
    } catch (e) {}
    return false;
  }

  function scanWorkdayFields(targetDoc) {
    if (!targetDoc) return { fields: [], seenElements: new Set() };
    const fields = [];
    const seenElements = new Set();

    const WORKDAY_MAP = [
      { type: 'FIRST_NAME', selectors: ['input[data-automation-id="legalNameSection_firstName"]', 'input[id*="legalNameSection_firstName"]'] },
      { type: 'LAST_NAME', selectors: ['input[data-automation-id="legalNameSection_lastName"]', 'input[id*="legalNameSection_lastName"]'] },
      { type: 'PREFERRED_NAME', selectors: ['input[data-automation-id="preferredNameSection_firstName"]'] },
      { type: 'EMAIL', selectors: ['input[data-automation-id="email"]', 'input[type="email"]'] },
      { type: 'PHONE', selectors: ['input[data-automation-id="phone-number"]', 'input[data-automation-id="phoneNumber"]'] },
      { type: 'PHONE_TYPE', selectors: ['button[data-automation-id="phone-device-type"]', '[data-automation-id="phone-device-type"]'] },
      { type: 'ADDRESS', selectors: ['input[data-automation-id="addressSection_addressLine1"]'] },
      { type: 'APT', selectors: ['input[data-automation-id="addressSection_addressLine2"]'] },
      { type: 'CITY', selectors: ['input[data-automation-id="addressSection_city"]'] },
      { type: 'ZIP', selectors: ['input[data-automation-id="addressSection_postalCode"]'] },
      { type: 'STATE', selectors: ['button[data-automation-id="addressSection_countryRegion"]', '[data-automation-id="addressSection_countryRegion"]'] },
      { type: 'COUNTRY', selectors: ['button[data-automation-id="addressSection_country"]', '[data-automation-id="addressSection_country"]'] },
      { type: 'RESUME', selectors: ['input[data-automation-id="file-upload-input-ref"]', '[data-automation-id="file-upload-drop-zone"] input[type="file"]', 'input[type="file"]'] },
      { type: 'LINKEDIN', selectors: ['input[data-automation-id*="linkedin"]', 'input[data-automation-id="linkedinQuestion"]'] },
      { type: 'PORTFOLIO', selectors: ['input[data-automation-id*="website"]', 'input[data-automation-id*="portfolio"]'] },
      { type: 'HEAR_ABOUT', selectors: ['button[data-automation-id="sourcePrompt"]', '[data-automation-id="sourcePrompt"]'] },
      { type: 'COMPANY', selectors: ['input[data-automation-id="company"]'] },
      { type: 'EMPLOYMENT_TITLE', selectors: ['input[data-automation-id="jobTitle"]'] },
      { type: 'WORK_DESCRIPTION', selectors: ['textarea[data-automation-id="description"]'] },
      { type: 'SCHOOL', selectors: ['input[data-automation-id="school"]', 'button[data-automation-id="school"]'] },
      { type: 'DEGREE', selectors: ['button[data-automation-id="degree"]', '[data-automation-id="degree"]'] },
      { type: 'DISCIPLINE', selectors: ['button[data-automation-id="field-of-study"]', '[data-automation-id="field-of-study"]'] },
      { type: 'GENDER', selectors: ['button[data-automation-id="gender"]', 'button[data-automation-id="genderPrompt"]'] },
      { type: 'HISPANIC_LATINO', selectors: ['button[data-automation-id="hispanicOrLatino"]'] },
      { type: 'VETERAN', selectors: ['button[data-automation-id="veteranStatus"]'] },
      { type: 'DISABILITY', selectors: ['input[data-automation-id*="disability"]', 'button[data-automation-id*="disability"]'] }
    ];

    WORKDAY_MAP.forEach(item => {
      let el = null;
      for (const sel of item.selectors) {
        try {
          const found = targetDoc.querySelector(sel);
          if (found) { el = found; break; }
        } catch (e) {}
      }
      if (el && !seenElements.has(el)) {
        seenElements.add(el);
        const origVal = (el.tagName === 'INPUT' && (el.type === 'radio' || el.type === 'checkbox'))
          ? el.checked
          : (el.value !== undefined ? el.value : (el.innerText || el.textContent || ''));
        const elId = el.id || el.getAttribute('data-automation-id') || el.name || '';
        const safeId = elId ? elId.replace(/[^a-zA-Z0-9_-]/g, '_') : ('wd_' + fields.length);
        fields.push({
          element: el,
          type: item.type,
          id: item.type.toLowerCase() + '_' + safeId,
          originalValue: origVal,
          atsDriver: 'Workday'
        });
      }
    });

    return { fields, seenElements };
  }

  /* -- ASHBY DETERMINISTIC DRIVER (PILLAR 2) -- */
  function isAshbyEnvironment(targetDocs = [document]) {
    try {
      const host = (window.location.hostname || '').toLowerCase();
      const href = (window.location.href || '').toLowerCase();
      if (host.includes('ashbyhq.com') || href.includes('ashbyhq.com')) return true;
      for (const doc of targetDocs) {
        if (!doc) continue;
        if (doc.querySelector('[data-testid="application-form"], .ashby-application-form, [data-testid="submit-application"]')) {
          return true;
        }
      }
    } catch (e) {}
    return false;
  }

  function scanAshbyFields(targetDoc) {
    if (!targetDoc) return { fields: [], seenElements: new Set() };
    const fields = [];
    const seenElements = new Set();

    const ASHBY_MAP = [
      { type: 'FULL_NAME', selectors: ['input[data-testid="name"]', 'input[name="name"]', 'input[autocomplete="name"]'] },
      { type: 'EMAIL', selectors: ['input[data-testid="email"]', 'input[name="email"]', 'input[autocomplete="email"]'] },
      { type: 'PHONE', selectors: ['input[data-testid="phone"]', 'input[name="phone"]', 'input[autocomplete="tel"]'] },
      { type: 'RESUME', selectors: ['[data-testid="resume-upload-dropzone"] input[type="file"]', 'input[type="file"][accept*="pdf"]', 'input[type="file"]'] },
      { type: 'LINKEDIN', selectors: ['input[name*="linkedin" i]', 'input[data-testid*="linkedin" i]'] },
      { type: 'GITHUB', selectors: ['input[name*="github" i]', 'input[data-testid*="github" i]'] },
      { type: 'PORTFOLIO', selectors: ['input[name*="portfolio" i]', 'input[data-testid*="portfolio" i]', 'input[name*="website" i]'] },
      { type: 'CITY', selectors: ['input[name*="location" i]', 'input[data-testid*="location" i]'] }
    ];

    ASHBY_MAP.forEach(item => {
      let el = null;
      for (const sel of item.selectors) {
        try {
          const found = targetDoc.querySelector(sel);
          if (found) { el = found; break; }
        } catch (e) {}
      }
      if (el && !seenElements.has(el)) {
        seenElements.add(el);
        const origVal = (el.tagName === 'INPUT' && (el.type === 'radio' || el.type === 'checkbox'))
          ? el.checked
          : (el.value !== undefined ? el.value : (el.innerText || el.textContent || ''));
        const elId = el.id || el.getAttribute('data-testid') || el.name || '';
        const safeId = elId ? elId.replace(/[^a-zA-Z0-9_-]/g, '_') : ('ashby_' + fields.length);
        fields.push({
          element: el,
          type: item.type,
          id: item.type.toLowerCase() + '_' + safeId,
          originalValue: origVal,
          atsDriver: 'Ashby'
        });
      }
    });

    return { fields, seenElements };
  }

  /* -- LEVER DETERMINISTIC DRIVER (PILLAR 2) -- */
  function isLeverEnvironment(targetDocs = [document]) {
    try {
      const host = (window.location.hostname || '').toLowerCase();
      const href = (window.location.href || '').toLowerCase();
      if (host.includes('lever.co') || href.includes('lever.co')) return true;
      for (const doc of targetDocs) {
        if (!doc) continue;
        if (doc.querySelector('.application-form, #btn-submit, input[name="urls[LinkedIn]"]')) {
          return true;
        }
      }
    } catch (e) {}
    return false;
  }

  function scanLeverFields(targetDoc) {
    if (!targetDoc) return { fields: [], seenElements: new Set() };
    const fields = [];
    const seenElements = new Set();

    const LEVER_MAP = [
      { type: 'FULL_NAME', selectors: ['input[name="name"]', '#name'] },
      { type: 'EMAIL', selectors: ['input[name="email"]', '#email'] },
      { type: 'PHONE', selectors: ['input[name="phone"]', '#phone'] },
      { type: 'COMPANY', selectors: ['input[name="org"]', '#org'] },
      { type: 'LINKEDIN', selectors: ['input[name="urls[LinkedIn]"]'] },
      { type: 'GITHUB', selectors: ['input[name="urls[GitHub]"]'] },
      { type: 'PORTFOLIO', selectors: ['input[name="urls[Portfolio]"]'] },
      { type: 'RESUME', selectors: ['input[name="resume"]', 'input#resume-upload-input', 'input[type="file"]'] },
      { type: 'SUMMARY', selectors: ['textarea[name="comments"]', 'textarea[name="additional-information"]'] }
    ];

    LEVER_MAP.forEach(item => {
      let el = null;
      for (const sel of item.selectors) {
        try {
          const found = targetDoc.querySelector(sel);
          if (found) { el = found; break; }
        } catch (e) {}
      }
      if (el && !seenElements.has(el)) {
        seenElements.add(el);
        const origVal = (el.tagName === 'INPUT' && (el.type === 'radio' || el.type === 'checkbox'))
          ? el.checked
          : (el.value !== undefined ? el.value : (el.innerText || el.textContent || ''));
        const elId = el.id || el.name || '';
        const safeId = elId ? elId.replace(/[^a-zA-Z0-9_-]/g, '_') : ('lever_' + fields.length);
        fields.push({
          element: el,
          type: item.type,
          id: item.type.toLowerCase() + '_' + safeId,
          originalValue: origVal,
          atsDriver: 'Lever'
        });
      }
    });

    return { fields, seenElements };
  }

  /* -- WELLFOUND DETERMINISTIC DRIVER (ANGELLIST TALENT) -- */
  function isWellfoundEnvironment(targetDocs = [document]) {
    try {
      const host = (window.location.hostname || '').toLowerCase();
      const href = (window.location.href || '').toLowerCase();
      if (!host.includes('wellfound.com') && !href.includes('wellfound.com')) return false;
      for (const doc of targetDocs) {
        if (!doc) continue;
        if (doc.querySelector('textarea[name="userNote"], textarea#userNote, [data-test*="ApplicationModal"], [data-test="JobApplicationModalSubmitButton"], form[action*="apply"], textarea[placeholder*="note" i], textarea[placeholder*="pitch" i]')) {
          return true;
        }
      }
    } catch (e) {}
    return false;
  }

  function scanWellfoundFields(targetDoc) {
    if (!targetDoc) return { fields: [], seenElements: new Set() };
    const fields = [];
    const seenElements = new Set();

    const WELLFOUND_MAP = [
      { type: 'COVER_LETTER', selectors: ['textarea[name="userNote"]', 'textarea#userNote', 'textarea[placeholder*="note" i]', 'textarea[placeholder*="pitch" i]', 'textarea[placeholder*="why" i]', 'textarea[data-test*="note" i]', 'textarea'] },
      { type: 'RESUME', selectors: ['input[type="file"][name*="resume" i]', 'input[type="file"]'] },
      { type: 'PHONE', selectors: ['input[name="phone" i]', 'input[type="tel"]'] },
      { type: 'CITY', selectors: ['input[name="location" i]', 'input[placeholder*="location" i]'] },
      { type: 'LINKEDIN', selectors: ['input[name*="linkedin" i]', 'input[placeholder*="linkedin" i]'] },
      { type: 'GITHUB', selectors: ['input[name*="github" i]', 'input[placeholder*="github" i]'] },
      { type: 'PORTFOLIO', selectors: ['input[name*="portfolio" i]', 'input[placeholder*="portfolio" i]', 'input[name*="website" i]'] }
    ];

    WELLFOUND_MAP.forEach(item => {
      let el = null;
      for (const sel of item.selectors) {
        try {
          const found = targetDoc.querySelector(sel);
          if (found) { el = found; break; }
        } catch (e) {}
      }
      if (el && !seenElements.has(el)) {
        seenElements.add(el);
        const origVal = (el.tagName === 'INPUT' && (el.type === 'radio' || el.type === 'checkbox'))
          ? el.checked
          : (el.value !== undefined ? el.value : (el.innerText || el.textContent || ''));
        const elId = el.id || el.getAttribute('data-test') || el.name || '';
        const safeId = elId ? elId.replace(/[^a-zA-Z0-9_-]/g, '_') : ('wellfound_' + fields.length);
        fields.push({
          element: el,
          type: item.type,
          id: item.type.toLowerCase() + '_' + safeId,
          originalValue: origVal,
          atsDriver: 'Wellfound'
        });
      }
    });

    return { fields, seenElements };
  }

  /* -- CAPTCHA SENTINEL (PILLAR 5: ACTIVE CHALLENGE ONLY) -- */
  function detectCaptchaChallenge(targetDocs = [document]) {
    try {
      for (const doc of targetDocs) {
        if (!doc) continue;

        // 1. Google reCAPTCHA: Detect active visual challenge modal (bframe / challenge iframe)
        // Strictly ignore passive invisible background tokens (e.g. anchor?size=invisible or .grecaptcha-badge)
        const recaptchaChallenge = doc.querySelector(
          'iframe[src*="recaptcha/enterprise/bframe"], iframe[src*="recaptcha/api2/bframe"], iframe[title*="recaptcha challenge" i]'
        );
        if (recaptchaChallenge) {
          const rect = recaptchaChallenge.getBoundingClientRect();
          if (rect.width > 100 && rect.height > 100) return true;
        }

        // 2. hCaptcha: Detect active interactive challenge frame
        const hcaptchaChallenge = doc.querySelector(
          'iframe[src*="hcaptcha.com/challenge"], iframe[title*="hcaptcha challenge" i], iframe[title*="checkbox for hcaptcha" i]'
        );
        if (hcaptchaChallenge) {
          const rect = hcaptchaChallenge.getBoundingClientRect();
          if (rect.width > 50 && rect.height > 50) return true;
        }

        // 3. Cloudflare Turnstile: Detect interactive manual verification widget
        const turnstileFrame = doc.querySelector(
          'iframe[src*="challenges.cloudflare.com/cdn-cgi/challenge-platform"]'
        );
        if (turnstileFrame) {
          const rect = turnstileFrame.getBoundingClientRect();
          // Turnstile interactive prompt is typically ~300x65px
          if (rect.width > 120 && rect.height > 40) return true;
        }
      }
    } catch (e) {}
    return false;
  }

  function scanFields() {
    let frameDocs = [];
    try {
      const iframes = document.querySelectorAll('iframe');
      for (let i = 0; i < iframes.length; i++) {
        try {
          const doc = iframes[i].contentDocument || (iframes[i].contentWindow && iframes[i].contentWindow.document);
          if (doc && doc.body) {
            const count = doc.querySelectorAll('input:not([type="hidden"]), select, textarea').length;
            if (count >= 2) {
              frameDocs.push(doc);
            }
          }
        } catch (e) {}
      }
    } catch (e) {}

    // When an embedded ATS portal is detected inside an iframe (like iCIMS #icims_content_iframe),
    // prioritize frameDocs exclusively so that the host company's outer header/footer search inputs never hijack singleton fields.
    const targetDocs = frameDocs.length > 0 ? frameDocs : [document];

    const results = [];
    const seenTypes = {};
    const SINGLETON_TYPES = new Set([
      'RESUME', 'COVER_LETTER',
      'FIRST_NAME', 'LAST_NAME', 'FULL_NAME', 'EMAIL', 'PHONE', 'PHONE_TYPE',
      'ADDRESS_TYPE', 'ADDRESS', 'APT', 'CITY', 'STATE', 'COUNTRY', 'ZIP',
      'EXP_STATE', 'EXP_CITY', 'EXP_COUNTRY',
      'LINKEDIN', 'GITHUB', 'PORTFOLIO', 'SUMMARY', 'NOTICE_PERIOD',
      'PRONOUNS', 'RELOCATE', 'WORK_AUTH', 'VISA',
      'AGE_18', 'PREVIOUS_EMPLOYED', 'PRIVACY_CONSENT', 'AI_CONSENT', 'AI_USAGE',
      'GOVT_OFFICIAL', 'GOVT_RELATIVE', 'CONFLICT_INTEREST', 'REFERRED_BY_LEADER',
      'HISPANIC_LATINO', 'VETERAN', 'DISABILITY', 'RACE_ETHNICITY',
      'COMPANY', 'EMPLOYMENT_TITLE', 'WORK_DESCRIPTION',
      'START_MONTH', 'START_DAY', 'START_YEAR', 'END_MONTH', 'END_DAY', 'END_YEAR', 'CURRENT_ROLE',
      'GRADUATION_YEAR', 'LANGUAGES',
      'REASON_FOR_LEAVING', 'TEXT_CONSENT',
      'SCHOOL', 'DEGREE', 'DISCIPLINE',
      'PREFERRED_NAME', 'HEAR_ABOUT', 'HEAR_ABOUT_DETAIL',
      'PREFERRED_LOCATION', 'WORKPLACE_TYPE'
    ]);

    const COMBOBOX_QUERY = [
      'input[type="text"]', 'input[type="email"]', 'input[type="tel"]', 'input[type="url"]',
      'input[type="number"]', 'input[type="password"]', 'input[type="radio"]', 'input[type="checkbox"]', 'input[type="search"]',
      'input[type="file"]',
      'input:not([type])', 'textarea', 'select',
      'button[role="combobox"]', 'div[role="combobox"]', '[aria-haspopup="listbox"]',
      '[data-automation-id="select-box"]', '.select-shell', '[class*="select__control"]',
      '[data-automation-id*="upload"]', '[class*="dropzone"]', '[class*="resume-upload"]'
    ].join(', ');

    const isIcims = isIcimsEnvironment(targetDocs);
    const isGreenhouse = isGreenhouseEnvironment(targetDocs);
    const isBreezy = isBreezyEnvironment(targetDocs);
    const isWorkday = isWorkdayEnvironment(targetDocs);
    const isAshby = isAshbyEnvironment(targetDocs);
    const isLever = isLeverEnvironment(targetDocs);
    const isWellfound = isWellfoundEnvironment(targetDocs);

    targetDocs.forEach(targetDoc => {
      const seenElements = new Set();

      // If on an iCIMS portal, execute the deterministic iCIMS driver first
      if (isIcims) {
        const { fields: icimsFields, seenElements: icimsSeen } = scanIcimsFields(targetDoc);
        icimsFields.forEach(f => {
          results.push(f);
          seenTypes[f.type] = true;
          seenElements.add(f.element);
        });
        icimsSeen.forEach(el => seenElements.add(el));
      }

      // If on a Greenhouse portal, execute the deterministic Greenhouse driver first
      if (isGreenhouse) {
        const { fields: ghFields, seenElements: ghSeen } = scanGreenhouseFields(targetDoc);
        ghFields.forEach(f => {
          results.push(f);
          seenTypes[f.type] = true;
          seenElements.add(f.element);
        });
        ghSeen.forEach(el => seenElements.add(el));
      }

      // If on a Breezy HR portal, execute the deterministic Breezy driver
      if (isBreezy) {
        const { fields: bzyFields, seenElements: bzySeen } = scanBreezyFields(targetDoc);
        bzyFields.forEach(f => {
          results.push(f);
          seenTypes[f.type] = true;
          seenElements.add(f.element);
        });
        bzySeen.forEach(el => seenElements.add(el));
      }

      // If on a Workday portal, execute the deterministic Workday driver
      if (isWorkday) {
        const { fields: wdFields, seenElements: wdSeen } = scanWorkdayFields(targetDoc);
        wdFields.forEach(f => {
          results.push(f);
          seenTypes[f.type] = true;
          seenElements.add(f.element);
        });
        wdSeen.forEach(el => seenElements.add(el));
      }

      // If on an Ashby portal, execute the deterministic Ashby driver
      if (isAshby) {
        const { fields: ashFields, seenElements: ashSeen } = scanAshbyFields(targetDoc);
        ashFields.forEach(f => {
          results.push(f);
          seenTypes[f.type] = true;
          seenElements.add(f.element);
        });
        ashSeen.forEach(el => seenElements.add(el));
      }

      // If on a Lever portal, execute the deterministic Lever driver
      if (isLever) {
        const { fields: levFields, seenElements: levSeen } = scanLeverFields(targetDoc);
        levFields.forEach(f => {
          results.push(f);
          seenTypes[f.type] = true;
          seenElements.add(f.element);
        });
        levSeen.forEach(el => seenElements.add(el));
      }

      // If on a Wellfound portal, execute the deterministic Wellfound driver
      if (isWellfound) {
        const { fields: wfFields, seenElements: wfSeen } = scanWellfoundFields(targetDoc);
        wfFields.forEach(f => {
          results.push(f);
          seenTypes[f.type] = true;
          seenElements.add(f.element);
        });
        wfSeen.forEach(el => seenElements.add(el));
      }

      // Google Careers Resume Section Fast-Path (Accent-Aware: handles "Upload résumé ▾")
      const host = (window.location.hostname || '').toLowerCase();
      const href = (window.location.href || '').toLowerCase();
      if (host.includes('google.com') && href.includes('/about/careers')) {
        const normalizeStr = (s) => (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();

        // 1. Check for explicit input[type="file"]
        const fileInp = targetDoc.querySelector('input[type="file"]');
        if (fileInp && !seenElements.has(fileInp)) {
          seenElements.add(fileInp);
          seenTypes['RESUME'] = true;
          results.push({
            element: fileInp,
            type: 'RESUME',
            id: 'resume_google_careers',
            originalValue: '',
            confidence: 0.99,
            reasoning: 'Google Careers Resume File Upload'
          });
        } else {
          // 2. Button with "Upload résumé" / "Upload resume" / "From computer" (handles accent marks: résumé vs resume)
          const allButtons = Array.from(targetDoc.querySelectorAll('button, div[role="button"], [class*="VfPpkd-LgbsSe"], [class*="button"], a[role="button"]'));
          const resumeBtn = allButtons.find(b => {
            const normText = normalizeStr(b.textContent || b.innerText);
            const normAria = normalizeStr(b.getAttribute('aria-label') || '');
            return (
              (normText.includes('upload') && normText.includes('resume')) ||
              normText.includes('upload resume') ||
              normText.startsWith('resume') ||
              normText.includes('from computer') ||
              (normAria.includes('upload') && normAria.includes('resume')) ||
              normAria.includes('resume')
            );
          });

          if (resumeBtn && !seenElements.has(resumeBtn)) {
            seenElements.add(resumeBtn);
            seenTypes['RESUME'] = true;
            results.push({
              element: resumeBtn,
              type: 'RESUME',
              id: 'resume_google_careers_btn',
              originalValue: '',
              confidence: 0.98,
              reasoning: 'Google Careers Resume Upload Action'
            });
          } else {
            // 3. Container-based fallback: look for the "Résumé" card container
            const headings = Array.from(targetDoc.querySelectorAll('h1, h2, h3, h4, h5, h6, legend, [class*="title"], [class*="header"], strong, b'));
            const resumeHeading = headings.find(h => {
              const norm = normalizeStr(h.textContent);
              return norm === 'resume' || norm.startsWith('resume') || norm.includes('resume');
            });
            if (resumeHeading) {
              const card = (resumeHeading.closest && resumeHeading.closest('section, form, div[class*="card"], div[class*="section"], div[class*="container"]')) || resumeHeading.parentElement;
              if (card) {
                const btnInside = card.querySelector('button, div[role="button"], [class*="VfPpkd-LgbsSe"]') || card;
                if (btnInside && !seenElements.has(btnInside)) {
                  seenElements.add(btnInside);
                  seenTypes['RESUME'] = true;
                  results.push({
                    element: btnInside,
                    type: 'RESUME',
                    id: 'resume_google_careers_card',
                    originalValue: '',
                    confidence: 0.95,
                    reasoning: 'Google Careers Résumé Card Dropzone'
                  });
                }
              }
            }
          }
        }
      }

      // Deep Shadow DOM query: finds all standard & Web Component inputs across open shadow roots
      const inputs = deepQuerySelectorAll(targetDoc, COMBOBOX_QUERY);
      lastFormFingerprint = generateBrowserFormFingerprint(inputs);
      if (lastFormFingerprint && !cachedSchemaMappings) {
        checkFormSchemaCache(lastFormFingerprint).catch(() => {});
      }

      inputs.forEach(inp => {
        // Canonicalize container vs inner interactive element to prevent duplicate registrations
        let canonicalEl = inp;
        if (inp.tagName !== 'INPUT' && inp.tagName !== 'SELECT' && inp.tagName !== 'BUTTON' && inp.tagName !== 'TEXTAREA') {
          const innerInteractive = inp.querySelector('input:not([type="hidden"]), button[role="combobox"], [aria-haspopup="listbox"]');
          if (innerInteractive) canonicalEl = innerInteractive;
        }
        if (seenElements.has(canonicalEl)) return;
        seenElements.add(canonicalEl);

        const rect = canonicalEl.getBoundingClientRect();
        const isCheckOrRadio = canonicalEl.tagName === 'INPUT' && (canonicalEl.type === 'radio' || canonicalEl.type === 'checkbox');
        const isCB = isComboboxOrSelect(canonicalEl);
        const isFileInput = canonicalEl.tagName === 'INPUT' && canonicalEl.type === 'file';
        const isDropzone = (canonicalEl.getAttribute && (canonicalEl.getAttribute('data-automation-id') || '').includes('upload')) ||
          (canonicalEl.className && String(canonicalEl.className).includes('dropzone'));

        // Standard visibility check - file inputs & dropzones often use opacity: 0 / 0-height styling
        if (rect.width === 0 && rect.height === 0 && !isCheckOrRadio && !isCB && !isFileInput && !isDropzone) return;
        const computed = (targetDoc.defaultView || window).getComputedStyle(canonicalEl);
        if ((computed.display === 'none' || computed.visibility === 'hidden') && !isCheckOrRadio && !isCB && !isFileInput && !isDropzone) return;

        const idAttr = (canonicalEl.getAttribute('id') || '').toLowerCase();
        const nameAttr = (canonicalEl.getAttribute('name') || '').toLowerCase();

        // Filter out Honeypot bot traps (Breezy HR hp_*, .apply-field-extra, offscreen traps)
        if (idAttr.startsWith('hp_') || nameAttr.startsWith('hp_') || idAttr.includes('honeypot') || nameAttr.includes('honeypot') || (canonicalEl.closest && canonicalEl.closest('.apply-field-extra, [aria-hidden="true"]'))) {
          return;
        }

        // Filter out OneTrust / Cookie consent banners & widgets
        if (idAttr.startsWith('ot-') || idAttr.includes('onetrust') || idAttr.includes('vendor-search') || idAttr.includes('cookie') || (canonicalEl.closest && canonicalEl.closest('#onetrust-banner-sdk, [id*="onetrust"], .ot-sdk-container, [id*="cookie"]'))) {
          return;
        }

        // Filter out site-wide career search filters & navigation inputs (e.g. iCIMS footer search)
        if (canonicalEl.type === 'search') return;
        const idAttrClean = idAttr;
        if (canonicalEl.closest) {
          const isSearchContainer = canonicalEl.closest('form[role="search"], [role="search"], .search-box, .search-form, .job-search, header, footer, .iCIMS_JobSearch, #job-search, .search-wrapper');
          if (isSearchContainer) {
            const isAppForm = Boolean(canonicalEl.closest('form[id*="apply"], form[class*="apply"], #icims_content_iframe, [data-automation-id*="form"], .application-form, .jobs-apply-form'));
            if (!isAppForm) return;
          }
        }
        if ((nameAttr.includes('search') || idAttr.includes('search')) && !nameAttr.includes('research') && !idAttr.includes('research')) {
          if (!canonicalEl.closest('form[id*="apply"], form[class*="apply"], #icims_content_iframe, [data-automation-id*="form"], .application-form')) {
            return;
          }
        }

        const type = classifyField(canonicalEl);
        if (!type) return;

        if (SINGLETON_TYPES.has(type)) {
          if (seenTypes[type]) return;
          seenTypes[type] = true;
        }

        const origVal = (canonicalEl.tagName === 'INPUT' && (canonicalEl.type === 'radio' || canonicalEl.type === 'checkbox'))
          ? canonicalEl.checked
          : (canonicalEl.value !== undefined ? canonicalEl.value : (canonicalEl.innerText || canonicalEl.textContent || ''));

        const elId = canonicalEl.id || canonicalEl.name || (canonicalEl.getAttribute && canonicalEl.getAttribute('data-automation-id')) || '';
        const safeId = elId ? elId.replace(/[^a-zA-Z0-9_-]/g, '_') : ('idx_' + results.length);
        const fieldId = type.toLowerCase() + '_' + safeId;

        results.push({
          element: canonicalEl,
          type,
          id: fieldId,
          originalValue: origVal,
          confidence: canonicalEl.__sfdConfidence || 0.90,
          reasoning: canonicalEl.__sfdReasoning || 'SFD Heuristic'
        });
      });
    });

    // Ensure COUNTRY is processed before STATE so dependent options load,
    // and HEAR_ABOUT is processed before HEAR_ABOUT_DETAIL
    results.sort((a, b) => {
      if (a.type === 'COUNTRY' && b.type === 'STATE') return -1;
      if (a.type === 'STATE' && b.type === 'COUNTRY') return 1;
      if (a.type === 'HEAR_ABOUT' && b.type === 'HEAR_ABOUT_DETAIL') return -1;
      if (a.type === 'HEAR_ABOUT_DETAIL' && b.type === 'HEAR_ABOUT') return 1;
      return 0;
    });

    return results;
  }


  /* -- UNIVERSAL COMBOBOX & DROPDOWN ENGINE (UCDE) -- */
  const SYNONYM_DICTIONARY = {
    'male': ['man', 'm', 'he/him', 'he/him/his'],
    'female': ['woman', 'f', 'she/her', 'she/her/hers'],
    'he/him': ['he / him', 'he/him/his', 'male', 'man'],
    'she/her': ['she / her', 'she/her/hers', 'female', 'woman'],
    'mobile': ['cell', 'cellular', 'personal', 'primary', 'mobile phone', 'direct'],
    'home': ['home', 'personal', 'primary', 'residence', 'main', 'permanent'],
    'india': ['india', '+91', '91', 'republic of india'],
    'united states': ['usa', 'us', 'u.s.', 'united states of america'],
    'linkedin': ['job board', 'online job board', 'social network', 'social media', 'internet', 'company website', 'other'],
    'yes': ['confirmed', 'confirm', 'agree', 'i agree', 'i confirm', 'true', '1', 'yes, i am', 'yes, i do', 'yes, i have', 'authorized', 'authorized to work', 'legally authorized', 'us citizen or permanent resident', 'authorized without restriction', 'consent', 'opt in', 'opt-in', 'i consent', 'i accept / i agree', 'i accept'],
    'no': ['false', '0', 'i disagree', 'no, i am not', 'no, i do not', 'no, i have not', "no, i don't", 'not required', 'no sponsorship required', 'will not require'],
    'immediate': ['immediately', 'now', '0 weeks', '1 week', '2 weeks', 'available immediately', 'immediate', '< 2 weeks', 'less than 2 weeks'],
    'bachelor of computer applications (bca)': ['bachelor of computer applications', 'bachelor', 'bachelors', "bachelor's", "bachelor's degree", 'undergraduate', 'bca', 'computer applications', 'b.c.a', 'b.c.a.'],
    'i am not a protected veteran': ['not a protected veteran', 'not a veteran', 'i am not a veteran', 'no', 'i identify as one or more of the classifications of protected veteran: no'],
    'no, i don\'t have a disability': ['no, i do not have a disability', "no, i don't have", 'i do not have a disability', 'no disability', 'no', 'i do not have a physical or mental impairment'],
    'asian': ['asian (not hispanic or latino)', 'asian / pacific islander', 'south asian', 'asian - non hispanic', 'asian (all)'],
    'amity university': ['amity university noida', 'amity university, noida', 'amity university uttar pradesh', 'amity'],
    'computer science / applications': ['computer science', 'computer applications', 'information technology', 'software engineering', 'computing'],
    'computer science': ['computer science', 'computer applications', 'computer science / applications', 'information technology', 'software engineering', 'computing', 'computer engineering', 'other'],
    'i accept / i agree': ['i accept / i agree', 'i accept', 'i agree', 'agree', 'yes', 'confirm', 'true', '1'],
    'league of legends': ['league of legends', 'lol', 'league', 'teamfight tactics', 'valorant', 'technology / platform / infrastructure'],
    'english': ['english', 'en', 'english (fluent)'],
    'hindi': ['hindi', 'hi', 'hindi (fluent)'],
    '2028': ['summer 2028', 'spring 2028', 'fall 2028', 'winter 2028', '2028', 'july 2028', 'may 2028', 'june 2028', 'december 2028'],
    '2027': ['summer 2027', 'spring 2027', 'fall 2027', 'winter 2027', '2027', 'may 2027', 'june 2027'],
    '2026': ['summer 2026', 'spring 2026', 'fall 2026', 'winter 2026', '2026', 'may 2026', 'june 2026', 'december 2026', 'may 2026 (or earlier)'],
    '2025': ['summer 2025', 'spring 2025', 'fall 2025', 'winter 2025', '2025', 'july 2025'],
    'bs': ['bs', 'bs in computer science', 'bachelor of science', 'bachelors', 'yes', 'undergraduate', 'bca'],
    'n/a': ['n/a', 'na', 'not applicable', 'none', 'n / a'],
    'january': ['jan', '01', '1'],
    'february': ['feb', '02', '2'],
    'march': ['mar', '03', '3'],
    'april': ['apr', '04', '4'],
    'may': ['05', '5'],
    'june': ['jun', '06', '6'],
    'july': ['jul', '07', '7'],
    'august': ['aug', '08', '8'],
    'september': ['sep', 'sept', '09', '9'],
    'october': ['oct', '10'],
    'november': ['nov', '11'],
    'december': ['dec', '12'],
    'present': ['current', 'currently', 'present', 'now', 'till date', 'till now', 'june'],
    '1': ['01', '1st', 'day 1', '1'],
    'bihar': ['br', 'bihar, india'],
    'uttar pradesh': ['up', 'u.p.'],
    'delhi': ['nct of delhi', 'new delhi', 'dl'],
    'maharashtra': ['mh'],
    'karnataka': ['ka', 'bangalore', 'bengaluru'],
    'remote': ['remote', 'remote (us)', 'remote - us', 'remote - united states', 'remote / virtual', 'remote eligible', 'work from home', 'wfh', 'virtual', 'home-based', 'home based', 'anywhere', 'telecommute', 'flexible / remote']
  };

  const PLACEHOLDER_REGEX = /^(\s*(--|—|select\b|choose\b|placeholder\b|please select\b|select an option\b))/i;
  const OTHER_FALLBACK_REGEX = /^(0\s*-\s*other|other\b|not listed\b|unlisted\b|not applicable\b|other institution\b|other school\b)/i;

  function resolveSemanticOptionMatch(options, targetVal, fieldType = '') {
    if (!options || options.length === 0 || !targetVal) return null;
    const targetLower = String(targetVal).trim().toLowerCase();
    if (!targetLower) return null;

    const validOptions = options.filter(o => !o.disabled);
    const pool = validOptions.length > 0 ? validOptions : options;

    // Stage 1: Exact text / value match
    for (const opt of pool) {
      const text = (opt.textContent || opt.text || '').replace(/\u00a0/g, ' ').trim().toLowerCase();
      const val = (opt.value || (opt.getAttribute && opt.getAttribute('data-value')) || '').trim().toLowerCase();
      if (text === targetLower || val === targetLower) return opt;
    }

    // Stage 2: Candidate invariants & compliance rules
    // Stage 2a: Preferred Office / Workplace / Remote Smart Priority
    // For remote job seekers, when an application presents office or workplace choices, prioritize 'Remote'
    const hasWorkplaceOrLocationIntent = 
      fieldType === 'PREFERRED_LOCATION' ||
      fieldType === 'WORKPLACE_TYPE' ||
      targetLower === 'remote' ||
      targetLower.includes('remote') ||
      (fieldType === 'LOCATION' && pool.some(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        return t === 'remote' || t.startsWith('remote -') || t.startsWith('remote (') || t.includes('remote');
      }));

    if (hasWorkplaceOrLocationIntent) {
      // 1. Highest priority: Exact or prefixed 'Remote' match
      const remoteOpt = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        const v = (o.value || (o.getAttribute && o.getAttribute('data-value')) || '').trim().toLowerCase();
        return (
          t === 'remote' ||
          v === 'remote' ||
          t.startsWith('remote -') ||
          t.startsWith('remote (') ||
          t.startsWith('remote,') ||
          t.includes('remote /') ||
          t.includes('remote eligible') ||
          t.includes('work from home') ||
          t.includes('virtual') ||
          t.includes('home-based') ||
          t.includes('anywhere')
        );
      }) || pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        return t.includes('remote');
      });

      if (remoteOpt) return remoteOpt;

      // 2. Second priority: If no 'Remote', check candidate's home city or country (e.g. India / Bangalore)
      if (typeof userProfile !== 'undefined' && userProfile) {
        const cCity = (userProfile.city || '').toLowerCase();
        const cCountry = (userProfile.country || '').toLowerCase();
        if (cCity || cCountry) {
          const geoMatch = pool.find(o => {
            const t = (o.textContent || o.text || '').trim().toLowerCase();
            return (cCity && t.includes(cCity)) || (cCountry && t.includes(cCountry) && !t.includes('indiana'));
          });
          if (geoMatch) return geoMatch;
        }
      }

      // 3. Third priority: "Flexible" / "Any Location" / "No Preference" / "Hybrid"
      const flexOpt = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        return t.includes('flexible') || t.includes('any location') || t.includes('no preference') || t.includes('hybrid');
      });
      if (flexOpt) return flexOpt;

      // 4. Fourth priority: First valid non-placeholder office option (e.g. primary headquarters)
      const firstOffice = pool.find(o => {
        const t = (o.textContent || o.text || '').trim();
        return t.length > 0 && !PLACEHOLDER_REGEX.test(t);
      });
      if (firstOffice) return firstOffice;
    }

    if (fieldType === 'COUNTRY' || fieldType === 'EXP_COUNTRY' || targetLower === 'india' || targetLower === '+91' || targetLower === '91') {
      const indiaMatch = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        const v = (o.value || '').trim().toLowerCase();
        return (t.includes('india') && !t.includes('indian ocean') && !t.includes('indiana')) || t.includes('+91') || v === 'in' || v === 'ind';
      });
      if (indiaMatch) return indiaMatch;
    }

    if (targetLower === 'asian' || targetLower === 'indian' || fieldType === 'RACE_ETHNICITY') {
      // Inviolable US EEOC Law: Candidates from the Indian subcontinent (India, Patna, Bihar, etc.)
      // are categorized as ASIAN, NEVER "American Indian or Alaskan Native" (indigenous Americans)!
      const asianMatch = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        if (t.includes('american indian') || t.includes('alaska native') || t.includes('native american')) return false;
        return t === 'asian' || t.startsWith('asian') || t.includes('asian') || t.includes('south asian');
      });
      if (asianMatch) return asianMatch;
    }

    if (fieldType === 'GRADUATION_YEAR' || targetLower.includes('graduat')) {
      const targetYearNum = parseInt(targetLower.replace(/\D/g, ''), 10);
      const exactYear = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        return t.includes(String(targetYearNum));
      });
      if (exactYear) return exactYear;

      const yearOpts = pool.map(o => {
        const t = (o.textContent || o.text || '').trim();
        const y = parseInt(t.replace(/\D/g, ''), 10);
        return { opt: o, year: y, text: t.toLowerCase() };
      }).filter(item => !isNaN(item.year) && item.year >= 2000 && item.year <= 2100);

      if (yearOpts.length > 0) {
        yearOpts.sort((a, b) => a.year - b.year);
        const nextFuture = yearOpts.find(item => item.year >= targetYearNum) || yearOpts[0];
        if (nextFuture) return nextFuture.opt;
      }

      const gradMatch = pool.find(o => (o.textContent || o.text || '').toLowerCase().includes('already graduated'));
      if (gradMatch) return gradMatch;
    }

    if (fieldType === 'LANGUAGES') {
      const langMatch = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        return t === targetLower || t.startsWith(targetLower);
      });
      if (langMatch) return langMatch;
    }

    if (targetLower === 'n/a' || targetLower === 'na') {
      const naMatch = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        return t === 'n/a' || t === 'na' || t.includes('not applicable') || t.includes('none');
      });
      if (naMatch) return naMatch;
    }

    if (targetLower.includes('none of the above') || targetLower === 'none') {
      const noneOpt = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        return t === 'none of the above.' || t === 'none of the above' || t.startsWith('none of the above') || t === 'none';
      });
      if (noneOpt) return noneOpt;
    }

    if (fieldType === 'DEGREE' || fieldType === 'EDUCATION' || targetLower.includes('bca') || targetLower.includes('computer applications')) {
      const bcaSyns = SYNONYM_DICTIONARY['bachelor of computer applications (bca)'] || [];
      for (const syn of bcaSyns) {
        const match = pool.find(o => {
          const t = (o.textContent || o.text || '').trim().toLowerCase();
          return t === syn || t.includes(syn);
        });
        if (match) return match;
      }
    }

    if (fieldType === 'DISCIPLINE' || targetLower.includes('computer') || targetLower.includes('software') || targetLower.includes('applications')) {
      const disciplinePriorities = [
        'computer science',
        'software engineering',
        'computer engineering',
        'computer applications',
        'information technology',
        'information systems',
        'computing',
        'computer and information',
        'applied computer',
        'other'
      ];
      for (const prio of disciplinePriorities) {
        const match = pool.find(o => {
          const t = (o.textContent || o.text || '').trim().toLowerCase();
          return t === prio || t.includes(prio);
        });
        if (match) return match;
      }
    }

    // Invariant: Month Resolution (e.g. July, August, 07, 7, May)
    if (fieldType === 'START_MONTH' || fieldType === 'END_MONTH' || /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i.test(targetLower)) {
      const monthMap = {
        'january': 1, 'february': 2, 'march': 3, 'april': 4, 'may': 5, 'june': 6,
        'july': 7, 'august': 8, 'september': 9, 'october': 10, 'november': 11, 'december': 12,
        'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'jun': 6, 'jul': 7, 'aug': 8, 'sep': 9, 'sept': 9, 'oct': 10, 'nov': 11, 'dec': 12
      };
      const monthNum = monthMap[targetLower] || parseInt(targetLower, 10);
      if (monthNum && monthNum >= 1 && monthNum <= 12) {
        const monthNames = ['', 'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
        const mName = monthNames[monthNum];
        const mShort = mName.slice(0, 3);
        const mPad = String(monthNum).padStart(2, '0');
        const mStr = String(monthNum);

        const monthMatch = pool.find(o => {
          const t = (o.textContent || o.text || '').trim().toLowerCase();
          const v = (o.value || '').trim().toLowerCase();
          return t === mName || t.includes(mName) || t.includes(mShort) || v === mStr || v === mPad || t === mStr || t === mPad;
        });
        if (monthMatch) return monthMatch;
      }
    }

    // Invariant: Internship Season Resolution (e.g. Summer 2027, Fall 2027)
    if (targetLower.includes('summer') || targetLower.includes('fall') || targetLower.includes('spring') || targetLower.includes('winter')) {
      const cleanTarget = targetLower.replace(/[^a-z0-9]/g, '');
      const seasonMatch = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        const cleanOpt = t.replace(/[^a-z0-9]/g, '');
        return t === targetLower || cleanOpt === cleanTarget || cleanOpt.includes(cleanTarget) || cleanTarget.includes(cleanOpt);
      });
      if (seasonMatch) return seasonMatch;
    }

    if (fieldType === 'DEGREE' || fieldType === 'EDUCATION') {
      const degMatch = pool.find(o => {
        const t = (o.textContent || o.text || '').toLowerCase();
        return t.includes("bachelor's") || t.includes('bachelor') || t.includes('undergraduate') || t.includes('other');
      });
      if (degMatch) return degMatch;
    }

    if (fieldType === 'VETERAN' || targetLower.includes('veteran')) {
      const vetMatch = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        return t.includes('not a protected veteran') || t.includes('not a veteran') || t.includes('i am not a protected') || (t === 'no' && !t.includes('yes'));
      });
      if (vetMatch) return vetMatch;
    }

    if (fieldType === 'DISABILITY' || targetLower.includes('disability')) {
      const disMatch = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        return t.includes("no, i don't have") || t.includes('no, i do not have') || t.includes('no disability') || (t === 'no' && !t.includes('yes'));
      });
      if (disMatch) return disMatch;
    }

    // Invariant: Date Months & Days
    if ((fieldType === 'END_MONTH' || fieldType === 'START_MONTH') && (targetLower === 'present' || targetLower === 'current' || targetLower === 'now')) {
      const monthNames = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
      const currentMonthName = monthNames[new Date().getMonth()];
      const presentOpt = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        return t.includes('present') || t.includes('current') || t.includes('june');
      });
      if (presentOpt) return presentOpt;

      const curMonthOpt = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        const v = (o.value || '').trim().toLowerCase();
        return t.includes(currentMonthName) || v === String(new Date().getMonth() + 1) || v === String(new Date().getMonth() + 1).padStart(2, '0');
      });
      if (curMonthOpt) return curMonthOpt;
    }

    if (fieldType === 'START_DAY' || fieldType === 'END_DAY' || targetLower === '1') {
      const dayOpt = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        const v = (o.value || '').trim().toLowerCase();
        return t === '1' || t === '01' || v === '1' || v === '01' || t.includes('1st') || t === 'day 1';
      });
      if (dayOpt) return dayOpt;
    }

    // Stage 3: Rich semantic synonyms dictionary
    const synList = SYNONYM_DICTIONARY[targetLower] || [];
    for (const syn of synList) {
      for (const opt of pool) {
        const t = (opt.textContent || opt.text || '').trim().toLowerCase();
        const v = (opt.value || (opt.getAttribute && opt.getAttribute('data-value')) || '').trim().toLowerCase();
        if (t === syn || v === syn || t.includes(syn) || v.includes(syn)) {
          if ((targetLower === 'asian' || fieldType === 'RACE_ETHNICITY') && (t.includes('american indian') || t.includes('alaska native') || t.includes('native american'))) continue;
          return opt;
        }
      }
    }

    // Stage 4: Fuzzy substring & word boundary match
    for (const opt of pool) {
      const t = (opt.textContent || opt.text || '').trim().toLowerCase();
      const v = (opt.value || (opt.getAttribute && opt.getAttribute('data-value')) || '').trim().toLowerCase();
      if (PLACEHOLDER_REGEX.test(t)) continue;
      if (t.includes(targetLower) || targetLower.includes(t) || v.includes(targetLower)) {
        if ((targetLower === 'asian' || fieldType === 'RACE_ETHNICITY') && (t.includes('american indian') || t.includes('alaska native') || t.includes('native american'))) continue;
        return opt;
      }
    }

    // Stage 5: "Other / Not Listed" fallbacks for School, Degree, etc.
    if (fieldType === 'SCHOOL' || fieldType === 'DEGREE' || fieldType === 'DISCIPLINE' || fieldType === 'HEAR_ABOUT' || targetLower.includes('university') || targetLower.includes('college')) {
      const otherOpt = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        return OTHER_FALLBACK_REGEX.test(t);
      });
      if (otherOpt) return otherOpt;
    }

    // Stage 5b: Smart heuristics for HEAR_ABOUT and boolean consent/authorization fields
    if (fieldType === 'HEAR_ABOUT' || fieldType === 'HEAR_ABOUT_DETAIL') {
      const hearMatch = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        return t.includes('linkedin') || t.includes('job board') || t.includes('online') || t.includes('internet') || t.includes('website') || t.includes('other');
      });
      if (hearMatch) return hearMatch;
    }

    if (['WORK_AUTH', 'AGE_18', 'PRIVACY_CONSENT', 'AI_CONSENT', 'TEXT_CONSENT'].includes(fieldType) || targetLower === 'yes' || targetLower === 'true' || targetLower.includes('agree')) {
      const yesMatch = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        return (t === 'yes' || t.startsWith('yes') || t.includes('authorized') || t.includes('agree') || t.includes('confirm') || t.includes('consent') || t.includes('opt in') || t.includes('opt-in') || t.includes('i accept') || t.includes('acknowledge') || t.includes('i acknowledge')) && !t.includes('no');
      });
      if (yesMatch) return yesMatch;
    }

    if (['VISA', 'PREVIOUS_EMPLOYED', 'GOVT_OFFICIAL', 'GOVT_RELATIVE', 'CONFLICT_INTEREST'].includes(fieldType) || targetLower === 'no' || targetLower === 'false') {
      const noMatch = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        return (t === 'no' || t.startsWith('no') || t.includes('do not') || t.includes('none')) && !t.includes('yes');
      });
      if (noMatch) return noMatch;
    }

    // Stage 6: First non-placeholder fallback for mandatory fields
    if (fieldType === 'SCHOOL' || fieldType === 'COUNTRY' || fieldType === 'EXP_COUNTRY') {
      const otherFallback = pool.find(o => {
        const t = (o.textContent || o.text || '').trim().toLowerCase();
        return OTHER_FALLBACK_REGEX.test(t);
      });
      return otherFallback || null;
    }

    // Strict compliance guard: if target explicitly requested "None of the above" or negative option, NEVER fallback to pool[0]
    if (targetLower.includes('none') || targetLower === 'no' || targetLower === 'false') {
      return null;
    }

    const firstValid = pool.find(o => {
      const t = (o.textContent || o.text || '').trim().toLowerCase();
      const v = o.value !== undefined ? o.value : (o.getAttribute && o.getAttribute('data-value'));
      return t && !PLACEHOLDER_REGEX.test(t) && v !== '' && v !== '0';
    });

    return firstValid || pool[0] || null;
  }

  function cleanupLingeringPopovers() {
    try {
      const popovers = document.querySelectorAll('[role="listbox"]:not([aria-hidden="true"]), [data-radix-popper-content-wrapper], .select__menu, [data-headlessui-state="open"]');
      if (popovers && popovers.length > 0) {
        const active = document.activeElement || document.body;
        active.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
        document.body.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, clientX: 0, clientY: 0 }));
        document.body.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, clientX: 0, clientY: 0 }));
      }
    } catch (e) {}
  }

  async function fillNativeSelect(el, targetVal, fieldType = '') {
    if (!el || el.tagName !== 'SELECT') return false;
    const options = Array.from(el.options || []);
    if (!options.length) return false;

    const matched = resolveSemanticOptionMatch(options, targetVal, fieldType);
    if (matched) {
      el.value = matched.value;
      matched.selected = true;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new Event('blur', { bubbles: true }));
      try {
        const win = (el.ownerDocument && el.ownerDocument.defaultView) ? el.ownerDocument.defaultView : window;
        if (win.$ && win.$(el).trigger) {
          win.$(el).trigger('change');
        }
      } catch (e) {}
      return true;
    }
    return false;
  }

  function isTrueGeoAutocomplete(el, fieldType = '') {
    if (!el) return false;
    if (fieldType === 'PREFERRED_LOCATION' || fieldType === 'WORKPLACE_TYPE') return false;

    const label = getLabelText(el).toLowerCase();
    const idAttr = (el.id || '').toLowerCase();
    const nameAttr = (el.name || '').toLowerCase();

    // If label or id asks for office/workplace preference, it is NOT a geo autocomplete
    if (
      label.includes('preferred') ||
      label.includes('office') ||
      label.includes('workplace') ||
      label.includes('arrangement') ||
      label.includes('desired') ||
      label.includes('which office') ||
      label.includes('preference') ||
      idAttr.includes('preferred') ||
      idAttr.includes('office') ||
      nameAttr.includes('preferred') ||
      nameAttr.includes('office')
    ) {
      return false;
    }

    // True geo autocomplete markers (e.g. Greenhouse Candidate Location):
    if (idAttr.includes('candidate-location') || idAttr.includes('candidate_location') || nameAttr.includes('candidate_location')) {
      return true;
    }
    if ((fieldType === 'LOCATION_AUTOCOMPLETE' || fieldType === 'CITY' || fieldType === 'LOCATION') && (label.includes('candidate location') || label.includes('current location') || label.includes('where do you live') || label.includes('current city') || idAttr.includes('geo') || idAttr.includes('places'))) {
      return true;
    }

    return false;
  }

  async function fillGeoAutocomplete(inputEl, targetVal) {
    if (!inputEl) return false;
    try {
      const container = (inputEl.closest && inputEl.closest('.select-shell, .select__container, [class*="react-select"], [class*="Select-control"], .select')) || inputEl.parentElement;
      const doc = (container && container.ownerDocument) || inputEl.ownerDocument || document;
      const win = doc.defaultView || window;
      const valStr = String(targetVal || 'Patna, Bihar, India').trim();
      const searchCity = valStr.split(',')[0].trim() || 'Patna';

      // 1. Open dropdown by clicking the control
      if (container) {
        const control = container.querySelector('.select__control') || container;
        control.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: win }));
        control.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: win }));
        control.click();
        await new Promise(r => setTimeout(r, 350));
      }

      // 2. Focus input and type the city name using execCommand with fallback
      inputEl.focus();
      if (inputEl.select) inputEl.select();
      let typed = false;
      try {
        typed = doc.execCommand && doc.execCommand('insertText', false, searchCity);
      } catch (e) {}
      if (!typed) {
        const proto = win.HTMLInputElement ? win.HTMLInputElement.prototype : Object.getPrototypeOf(inputEl);
        const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
        if (setter) setter.call(inputEl, searchCity); else inputEl.value = searchCity;
        if (inputEl._valueTracker) inputEl._valueTracker.setValue('');
        inputEl.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: searchCity }));
        inputEl.dispatchEvent(new Event('input', { bubbles: true }));
        inputEl.dispatchEvent(new Event('change', { bubbles: true }));
      }
      await new Promise(r => setTimeout(r, 500));

      // 3. Wait for options inside container's menu (or id-linked listbox), ensuring Loading... has resolved
      const listboxId = inputEl.getAttribute && (inputEl.getAttribute('aria-controls') || (inputEl.id ? `react-select-${inputEl.id}-listbox` : null));
      let matchedOption = null;
      const startTime = Date.now();
      while (Date.now() - startTime < 4500) {
        let menuEl = container ? container.querySelector('.select__menu, .select__menu-list') : null;
        if (!menuEl && listboxId) {
          menuEl = doc.getElementById(listboxId);
        }
        if (!menuEl) {
          menuEl = doc.querySelector('.select__menu');
        }

        if (menuEl) {
          const isLoading = menuEl.querySelector('.select__menu-notice--loading');
          const opts = Array.from(menuEl.querySelectorAll('.select__option, div[id*="-option-"], [role="option"]')).filter(o => {
            if (o.classList && o.classList.contains('iti__country')) return false;
            const txt = (o.textContent || '').trim();
            return txt.length > 0 && !PLACEHOLDER_REGEX.test(txt);
          });

          if (opts.length > 0 && !isLoading) {
            // Priority: matches searchCity and DOES NOT contain 'rural' (Patna, Bihar, India)
            matchedOption = opts.find(o => {
              const txt = (o.textContent || '').toLowerCase();
              return txt.includes(searchCity.toLowerCase()) && !txt.includes('rural');
            }) || opts.find(o => (o.textContent || '').toLowerCase().includes(searchCity.toLowerCase())) || opts[0];
            break;
          }
        }
        await new Promise(r => setTimeout(r, 100));
      }

      if (matchedOption) {
        const optWin = matchedOption.ownerDocument?.defaultView || win;
        matchedOption.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: optWin }));
        matchedOption.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: optWin }));
        matchedOption.click();
        await new Promise(r => setTimeout(r, 200));
        cleanupLingeringPopovers();
        return true;
      } else {
        // Fallback: commit typed city with Enter
        inputEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
        inputEl.dispatchEvent(new Event('change', { bubbles: true }));
        inputEl.dispatchEvent(new Event('blur', { bubbles: true }));
        await new Promise(r => setTimeout(r, 60));
        cleanupLingeringPopovers();
        return (inputEl.value || '').trim().length > 0;
      }
    } catch (e) {
      return false;
    }
  }

  async function fillReactSelectV2(inputEl, targetVal, fieldType = '') {
    if (!inputEl || !targetVal) return false;

    // Handle Geo-autocomplete for candidate current residence/city
    if (isTrueGeoAutocomplete(inputEl, fieldType)) {
      return await fillGeoAutocomplete(inputEl, targetVal);
    }

    const container = (inputEl.closest && inputEl.closest('.select-shell, .select__container, [class*="react-select"], [class*="Select-control"], .select')) || (inputEl.classList && inputEl.classList.contains('select-shell') ? inputEl : inputEl.parentElement);
    if (!container) return false;

    const actualInput = (inputEl.tagName === 'INPUT' ? inputEl : container.querySelector('input:not([type="hidden"])')) || container.querySelector('input') || inputEl;
    const control = container.querySelector('.select__control') || container;
    const doc = container.ownerDocument || document;
    const win = doc.defaultView || window;

    // Helper: query currently visible options from local container OR matching portal
    const getVisibleOptions = () => {
      // 1. Check matching listbox via input's aria-controls FIRST (strict target isolation)
      const ariaControls = actualInput && actualInput.getAttribute ? actualInput.getAttribute('aria-controls') : null;
      if (ariaControls) {
        const ariaMenu = doc.getElementById(ariaControls);
        if (ariaMenu) {
          const ariaOpts = Array.from(ariaMenu.querySelectorAll('.select__option, [role="option"], div[id*="-option-"]')).filter(o => {
            const txt = (o.textContent || o.text || '').trim();
            return txt.length > 0 && !PLACEHOLDER_REGEX.test(txt);
          });
          if (ariaOpts.length > 0) return ariaOpts;
        }
      }

      // 2. Check local container menu (strictly .select__menu, avoiding control class with --menu-is-open!)
      const localMenu = container.querySelector('.select__menu .select__menu-list, .select__menu');
      if (localMenu) {
        const localOpts = Array.from(localMenu.querySelectorAll('.select__option, [role="option"], div[id*="-option-"]')).filter(o => {
          const txt = (o.textContent || o.text || '').trim();
          return txt.length > 0 && !PLACEHOLDER_REGEX.test(txt);
        });
        if (localOpts.length > 0) return localOpts;
      }

      // 3. Check portal options strictly matching this input's id (strip '-input' suffix for React-Select v5)
      const inputId = (actualInput && actualInput.id) || (inputEl && inputEl.id) || '';
      const baseInputId = inputId.replace(/-input$/, '');
      if (baseInputId) {
        const portalOpts = Array.from(doc.querySelectorAll(`div[id*="${baseInputId}-option-"]`)).filter(o => {
          const txt = (o.textContent || o.text || '').trim();
          return txt.length > 0 && !PLACEHOLDER_REGEX.test(txt);
        });
        if (portalOpts.length > 0) return portalOpts;
      }

      // 4. Global fallback ONLY for select__menu-list (NEVER generic [role="listbox"] which catches telephone country picker!)
      const globalMenuOpts = Array.from(doc.querySelectorAll('.select__menu .select__option, .select__menu-list .select__option')).filter(o => {
        const txt = (o.textContent || o.text || '').trim();
        return txt.length > 0 && !PLACEHOLDER_REGEX.test(txt);
      });
      if (globalMenuOpts.length > 0) return globalMenuOpts;

      return [];
    };

    // Helper: check if a valid selection has already been rendered in this container
    // MANDATORY LAW: Never verify by checking inputEl.value!
    const isContainerPopulated = () => {
      const single = container.querySelector('.select__single-value, [class*="singleValue"], .select__multi-value__label, [class*="multiValue"]');
      if (single && single.textContent.trim().length > 0 && !PLACEHOLDER_REGEX.test(single.textContent.trim())) return true;
      if (single && single.getAttribute('data-astrework-display')) return true;
      const req = container.querySelector('input[class*="requiredInput"]');
      if (req && req.value && req.value.trim().length > 0 && !PLACEHOLDER_REGEX.test(req.value.trim())) return true;
      return false;
    };

    // Helper: simulate typing to trigger search/filter in React-Select
    const typeSearchString = async (searchStr) => {
      if (!actualInput || actualInput.tagName !== 'INPUT' || actualInput.readOnly) return;
      try {
        actualInput.focus();
        const proto = win.HTMLInputElement ? win.HTMLInputElement.prototype : Object.getPrototypeOf(actualInput);
        const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
        if (setter) {
          setter.call(actualInput, '');
        } else {
          actualInput.value = '';
        }
        if (actualInput._valueTracker) actualInput._valueTracker.setValue('__clear__');
        actualInput.dispatchEvent(new Event('input', { bubbles: true }));

        if (searchStr) {
          // Attempt hardware CDP typing first for native React event fidelity
          const cdpRes = await cdpInput('TYPE', { text: searchStr, delay: 30 });
          if (!cdpRes || !cdpRes.success) {
            let typed = false;
            try {
              typed = doc.execCommand && doc.execCommand('insertText', false, searchStr);
            } catch (e) {}
            if (!typed) {
              if (setter) {
                setter.call(actualInput, searchStr);
              } else {
                actualInput.value = searchStr;
              }
              if (actualInput._valueTracker) actualInput._valueTracker.setValue('');
              actualInput.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: searchStr }));
              actualInput.dispatchEvent(new Event('input', { bubbles: true }));
              actualInput.dispatchEvent(new Event('change', { bubbles: true }));
            }
          }
        }
      } catch (e) {}
    };

    // Helper: open the dropdown menu cleanly with Keyboard ArrowDown as PRIMARY actuator
    const openMenu = async () => {
      cleanupLingeringPopovers();
      let opts = getVisibleOptions();
      if (opts.length > 0) return opts;

      // 1. Primary Actuation: ArrowDown keydown + keyup on actualInput (Verified 100% reliable on Greenhouse React-Select)
      try {
        actualInput.scrollIntoView({ behavior: 'instant', block: 'center' });
        actualInput.focus();
        actualInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', code: 'ArrowDown', keyCode: 40, which: 40, bubbles: true }));
        actualInput.dispatchEvent(new KeyboardEvent('keyup', { key: 'ArrowDown', code: 'ArrowDown', keyCode: 40, which: 40, bubbles: true }));
      } catch (e) {}

      // 2. Secondary Actuation: Click the flyout indicator button if present
      const flyoutBtn = container.querySelector('button[aria-label*="flyout"], button[aria-label*="Toggle"], .select__dropdown-indicator');
      if (flyoutBtn) {
        try { flyoutBtn.click(); } catch (e) {}
      }

      // Wait up to 350ms for options to mount and stabilize
      const start = Date.now();
      let lastCount = 0;
      while (Date.now() - start < 350) {
        opts = getVisibleOptions();
        if (opts.length > 0) {
          if (opts.length === lastCount) break;
          lastCount = opts.length;
        }
        await new Promise(r => setTimeout(r, 40));
      }

      // 3. Tertiary Escalation: Hardware CDP Click on control center if still closed
      if (opts.length === 0) {
        try {
          const rect = control.getBoundingClientRect();
          if (rect.width > 0 && rect.height > 0) {
            await cdpInput('CLICK', {
              x: rect.left + rect.width / 2,
              y: rect.top + rect.height / 2
            });
            const start3 = Date.now();
            while (Date.now() - start3 < 350) {
              opts = getVisibleOptions();
              if (opts.length > 0) break;
              await new Promise(r => setTimeout(r, 50));
            }
          }
        } catch (e) {}
      }

      // Scrollable menu list bottom visibility
      const menuList = container.querySelector('.select__menu-list') || doc.querySelector('.select__menu-list');
      if (menuList && menuList.scrollHeight > menuList.clientHeight) {
        try {
          menuList.scrollTop = menuList.scrollHeight;
          const scrolledOpts = getVisibleOptions();
          if (scrolledOpts.length > opts.length) opts = scrolledOpts;
        } catch (e) {}
      }

      return opts;
    };

    // Handle Multi-Select (e.g. LANGUAGES)
    const targets = Array.isArray(targetVal) ? targetVal : (fieldType === 'LANGUAGES' ? String(targetVal).split(',').map(s => s.trim()) : [targetVal]);
    let anySuccess = false;

    for (const singleVal of targets) {
      if (!singleVal) continue;

      // Open the dropdown
      let options = await openMenu();

      // 1. First, attempt semantic matching on the FULL open option pool
      let matchedOption = resolveSemanticOptionMatch(options, singleVal, fieldType);

      // 2. School fallback: if searching for university (Amity) and not in initial pool, type to search
      if (!matchedOption && (fieldType === 'SCHOOL' || singleVal.toLowerCase().includes('amity') || singleVal.toLowerCase().includes('university'))) {
        let schoolOpt = options.find(o => (o.textContent || '').trim().toLowerCase().includes('amity'));
        if (!schoolOpt) {
          await typeSearchString('Other');
          const startOther = Date.now();
          while (Date.now() - startOther < 2500) {
            const curOpts = getVisibleOptions();
            const menuEl = container.querySelector('.select__menu, .select__menu-list') || doc.querySelector('.select__menu, .select__menu-list');
            const isLoading = menuEl && menuEl.querySelector('.select__menu-notice--loading');
            if (!isLoading) {
              schoolOpt = curOpts.find(o => (o.textContent || o.text || '').trim().toLowerCase() === 'other') ||
                curOpts.find(o => (o.textContent || o.text || '').trim().toLowerCase().startsWith('other')) ||
                curOpts.find(o => OTHER_FALLBACK_REGEX.test((o.textContent || o.text || '').trim()));
              if (schoolOpt) break;
            }
            await new Promise(r => setTimeout(r, 80));
          }
        }
        if (schoolOpt) {
          matchedOption = schoolOpt;
        } else {
          await typeSearchString('');
        }
      }

      // 3. Non-destructive typeSearch only if STILL not matched
      if (!matchedOption && actualInput.tagName === 'INPUT' && !actualInput.readOnly) {
        const searchStr = String(singleVal).replace(/[.,]/g, '').trim();
        await typeSearchString(searchStr);
        const searchStart = Date.now();
        while (Date.now() - searchStart < 500) {
          const curOpts = getVisibleOptions();
          matchedOption = resolveSemanticOptionMatch(curOpts, singleVal, fieldType);
          if (matchedOption) {
            options = curOpts;
            break;
          }
          await new Promise(r => setTimeout(r, 50));
        }

        // If typing destroyed options with 0 matches, reset search input to restore full pool!
        if (!matchedOption) {
          await typeSearchString('');
          await new Promise(r => setTimeout(r, 100));
          options = getVisibleOptions();
          matchedOption = resolveSemanticOptionMatch(options, singleVal, fieldType);
        }
      }

      // 4. Click the matched option with Synthetic Sequence + CDP Escalation
      if (matchedOption) {
        matchedOption.scrollIntoView({ behavior: 'instant', block: 'nearest' });
        await new Promise(r => setTimeout(r, 40));
        const optWin = matchedOption.ownerDocument?.defaultView || win;
        const optRect = matchedOption.getBoundingClientRect();
        const eventInit = {
          bubbles: true,
          cancelable: true,
          view: optWin,
          clientX: optRect.left + optRect.width / 2,
          clientY: optRect.top + optRect.height / 2,
          button: 0,
          buttons: 1,
        };
        try {
          if (typeof optWin.PointerEvent === 'function') {
            matchedOption.dispatchEvent(new PointerEvent('pointerdown', eventInit));
          }
          matchedOption.dispatchEvent(new MouseEvent('mousedown', eventInit));
          if (typeof optWin.PointerEvent === 'function') {
            matchedOption.dispatchEvent(new PointerEvent('pointerup', eventInit));
          }
          matchedOption.dispatchEvent(new MouseEvent('mouseup', eventInit));
          matchedOption.dispatchEvent(new MouseEvent('click', eventInit));
        } catch (e) {}

        await new Promise(r => setTimeout(r, 150));

        // If synthetic click failed to mount single-value, escalate to CDP Hardware Click!
        if (!isContainerPopulated()) {
          try {
            if (optRect.width > 0 && optRect.height > 0) {
              await cdpInput('CLICK', {
                x: optRect.left + optRect.width / 2,
                y: optRect.top + optRect.height / 2
              });
              await new Promise(r => setTimeout(r, 150));
            }
          } catch (e) {}
        }

        if (isContainerPopulated()) {
          anySuccess = true;
        }

        // Visual perfection for custom / unlisted schools (e.g. Amity University)
        if (fieldType === 'SCHOOL' && (singleVal.toLowerCase().includes('amity') || singleVal.toLowerCase().includes('university'))) {
          try {
            const singleEl = container.querySelector('.select__single-value, [class*="singleValue"]');
            if (singleEl) {
              singleEl.textContent = 'Amity University';
              singleEl.setAttribute('data-astrework-display', 'Amity University');
            }
          } catch (e) {}
        }
      }
    }

    cleanupLingeringPopovers();
    return anySuccess || isContainerPopulated();
  }

  async function fillRadixOrHeadless(triggerEl, targetVal, fieldType = '') {
    if (!triggerEl) return false;
    try {
      if (document.activeElement !== triggerEl) triggerEl.focus();
    } catch (e) {}

    triggerEl.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, view: window }));
    triggerEl.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
    triggerEl.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, view: window }));
    triggerEl.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
    triggerEl.click();

    let options = [];
    const startTime = Date.now();
    while (Date.now() - startTime < 700) {
      // Check for search input in popover or container
      const searchInput = document.querySelector('.select2-input, [role="listbox"] input, [data-radix-popper-content-wrapper] input, input[type="search"], input[aria-autocomplete="list"]') ||
                          (triggerEl.parentElement && triggerEl.parentElement.querySelector('input:not([type="hidden"])'));
      if (searchInput && searchInput !== triggerEl && !searchInput.disabled) {
        try {
          searchInput.focus();
          const proto = window.HTMLInputElement.prototype;
          const setter = Object.getOwnPropertyDescriptor(proto, 'value');
          if (setter && setter.set) { setter.set.call(searchInput, targetVal); } else { searchInput.value = targetVal; }
          searchInput.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: String(targetVal) }));
          searchInput.dispatchEvent(new Event('change', { bubbles: true }));
          await new Promise(r => setTimeout(r, 120));
        } catch (e) {}
      }

      const popovers = Array.from(document.querySelectorAll(
        '[data-radix-popper-content-wrapper], [data-radix-select-viewport], [role="listbox"], [data-headlessui-state="open"], .select__menu, .select2-drop, .select2-results, [class*="menu"], [class*="dropdown-menu"], [class*="popover"], div[id*="listbox"], ul[id*="listbox"]'
      ));
      for (const p of popovers) {
        const opts = Array.from(p.querySelectorAll('[role="option"], [data-radix-collection-item], [data-headlessui-state], li, div[id*="option"], div[class*="option"], .select2-results li'));
        if (opts.length > 0) {
          options = opts.filter(o => o.offsetHeight > 0 || o.getBoundingClientRect().height > 0 || o.offsetParent !== null);
          if (options.length > 0) break;
        }
      }
      if (options.length > 0) break;
      await new Promise(r => setTimeout(r, 50));
    }

    if (options.length === 0) {
      return await fillWaiAriaKeyboard(triggerEl, targetVal, fieldType);
    }

    const matchedOption = resolveSemanticOptionMatch(options, targetVal, fieldType);
    if (matchedOption) {
      matchedOption.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, view: window }));
      matchedOption.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
      matchedOption.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, view: window }));
      matchedOption.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
      matchedOption.click();
      await new Promise(r => setTimeout(r, 80));
      cleanupLingeringPopovers();
      return true;
    }

    // Fallback: If School/Degree/Discipline doesn't match exact target, pick 'Other' / 'Not Listed'
    if (fieldType === 'SCHOOL' || fieldType === 'DEGREE' || fieldType === 'DISCIPLINE') {
      const otherOpt = options.find(o => OTHER_FALLBACK_REGEX.test((o.textContent || o.text || '').trim()));
      if (otherOpt) {
        otherOpt.click();
        await new Promise(r => setTimeout(r, 80));
        cleanupLingeringPopovers();
        return true;
      }
    }

    return await fillWaiAriaKeyboard(triggerEl, targetVal, fieldType);
  }

  async function fillWorkdaySelect(triggerEl, targetVal, fieldType = '') {
    if (!triggerEl) return false;
    const container = triggerEl.closest('[data-automation-id="select-box"], [data-automation-id="formLabel"], div[id*="wd-"]') || triggerEl.parentElement;
    const searchInput = (container && container.querySelector('input[data-automation-id*="searchBox"], input:not([type="hidden"])')) || triggerEl;

    try {
      if (document.activeElement !== searchInput) searchInput.focus();
      const proto = window.HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value');
      if (setter && setter.set) { setter.set.call(searchInput, targetVal); } else { searchInput.value = targetVal; }
      searchInput.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: String(targetVal) }));
      searchInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
    } catch (e) {}

    let options = [];
    const startTime = Date.now();
    while (Date.now() - startTime < 600) {
      const popups = Array.from(document.querySelectorAll('ul[role="listbox"], div[data-automation-id="promptOption"], [data-automation-id="menu"]'));
      for (const p of popups) {
        const opts = Array.from(p.querySelectorAll('li, div[data-automation-id="promptOption"], [role="option"]'));
        if (opts.length > 0) {
          options = opts;
          break;
        }
      }
      if (options.length > 0) break;
      await new Promise(r => setTimeout(r, 50));
    }

    if (options.length > 0) {
      const matched = resolveSemanticOptionMatch(options, targetVal, fieldType);
      if (matched) {
        matched.click();
        await new Promise(r => setTimeout(r, 80));
        cleanupLingeringPopovers();
        return true;
      }
    }

    return await fillWaiAriaKeyboard(triggerEl, targetVal, fieldType);
  }

  async function fillWaiAriaKeyboard(triggerEl, targetVal, fieldType = '') {
    if (!triggerEl) return false;
    try {
      if (document.activeElement !== triggerEl) triggerEl.focus();

      if (fieldType === 'RACE_ETHNICITY') {
        // Strict guard: Never send blind ArrowDown on race field to avoid selecting American Indian
        if (targetVal) {
          const chars = String(targetVal);
          for (const char of chars) {
            triggerEl.dispatchEvent(new KeyboardEvent('keypress', { key: char, bubbles: true }));
          }
          await new Promise(r => setTimeout(r, 100));
        }
        triggerEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
        await new Promise(r => setTimeout(r, 60));
        cleanupLingeringPopovers();
        return await verifyFieldWritten({ element: triggerEl, type: fieldType }, targetVal);
      }

      triggerEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', code: 'ArrowDown', keyCode: 40, bubbles: true }));
      triggerEl.dispatchEvent(new KeyboardEvent('keydown', { key: ' ', code: 'Space', keyCode: 32, bubbles: true }));
      await new Promise(r => setTimeout(r, 120));

      if (targetVal) {
        const chars = String(targetVal).slice(0, 5);
        for (const char of chars) {
          triggerEl.dispatchEvent(new KeyboardEvent('keypress', { key: char, bubbles: true }));
        }
        await new Promise(r => setTimeout(r, 100));
      }

      triggerEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
      await new Promise(r => setTimeout(r, 60));
      cleanupLingeringPopovers();
      return await verifyFieldWritten({ element: triggerEl, type: fieldType }, targetVal);
    } catch (e) {
      return false;
    }
  }

  async function fillUniversalCombobox(triggerEl, targetVal, fieldType = '') {
    if (!triggerEl || !targetVal) return false;

    // Check for City / Location autocomplete combobox first
    if (isTrueGeoAutocomplete(triggerEl, fieldType)) {
      return await fillGeoAutocomplete(triggerEl, targetVal);
    }

    const type = detectComboboxType(triggerEl);
    switch (type) {
      case 'NATIVE':
        return await fillNativeSelect(triggerEl, targetVal, fieldType);
      case 'RADIX':
      case 'HEADLESS_UI':
      case 'WAI_ARIA':
        return await fillRadixOrHeadless(triggerEl, targetVal, fieldType);
      case 'WORKDAY':
        return await fillWorkdaySelect(triggerEl, targetVal, fieldType);
      case 'REACT_SELECT':
        return await fillReactSelectV2(triggerEl, targetVal, fieldType);
      default:
        return await fillRadixOrHeadless(triggerEl, targetVal, fieldType);
    }
  }

  /* -- SYNTHETIC RESUME BINARY INJECTION (PILLAR B) -- */
  function getResumeBinaryFromBackground() {
    return new Promise((resolve) => {
      try {
        const activeCtx = userProfile ? (userProfile.slug || 'roushan') : 'roushan';
        if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
          return resolve({ success: false, error: 'Extension runtime unavailable' });
        }
        chrome.runtime.sendMessage({ type: 'GET_RESUME_BINARY', activeContext: activeCtx }, (res) => {
          if (chrome.runtime.lastError) {
            resolve({ success: false, error: chrome.runtime.lastError.message });
            return;
          }
          resolve(res || { success: false, error: 'Empty response from background streamer' });
        });
      } catch (e) {
        resolve({ success: false, error: e.message });
      }
    });
  }

  function base64ToBlob(base64, mimeType = 'application/pdf') {
    const cleanBase64 = base64.replace(/^data:[^;]+;base64,/, '').trim();
    const binary = atob(cleanBase64);
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return new Blob([bytes], { type: mimeType });
  }

  async function injectResumeFile(targetEl) {
    if (!targetEl) return { success: false, error: 'No target element provided' };

    const data = await getResumeBinaryFromBackground();
    if (!data || !data.success || !data.base64) {
      return { success: false, error: (data && data.error) || 'Failed to stream resume binary from background' };
    }

    try {
      const fallbackName = (userProfile && (userProfile.slug === 'ayushi' || (userProfile.name && userProfile.name.toLowerCase().includes('ayushi'))))
        ? 'Ayushi_Raj_resume.pdf'
        : 'Roushan_Kumar_resume.pdf';
      const filename = data.filename || fallbackName;
      const mimeType = data.mimeType || 'application/pdf';
      const blob = base64ToBlob(data.base64, mimeType);
      const file = new File([blob], filename, {
        type: mimeType,
        lastModified: Date.now()
      });

      const dt = new DataTransfer();
      dt.items.add(file);

      // Locate actual input[type="file"]
      let fileInput = null;
      if (targetEl.tagName === 'INPUT' && targetEl.type === 'file') {
        fileInput = targetEl;
      } else {
        fileInput = targetEl.querySelector('input[type="file"]') ||
          (targetEl.closest && targetEl.closest('form, [class*="application"], body, section, div[class*="card"]') && targetEl.closest('form, [class*="application"], body, section, div[class*="card"]').querySelector('input[type="file"]')) ||
          document.querySelector('input[type="file"]');
      }

      // If file input not immediately found and target is a button (e.g. Google Careers "Upload résumé ▾"),
      // click it to trigger dropdown menu or lazy-mount the hidden file input
      if (!fileInput && (targetEl.tagName === 'BUTTON' || (targetEl.getAttribute && targetEl.getAttribute('role') === 'button') || (targetEl.className && String(targetEl.className).includes('VfPpkd-LgbsSe')))) {
        try {
          targetEl.click();
          await new Promise(r => setTimeout(r, 180));

          // Check if Google Careers dropdown menu opened with "Upload from computer"
          const menuItems = Array.from(document.querySelectorAll('[role="menuitem"], .VfPpkd-StrnGf-rymPhb, [class*="menu-item"], [class*="item"]'));
          const computerOption = menuItems.find(mi => {
            const txt = (mi.textContent || '').toLowerCase();
            return txt.includes('computer') || txt.includes('upload') || txt.includes('device');
          });
          if (computerOption) {
            computerOption.click();
            await new Promise(r => setTimeout(r, 180));
          }

          fileInput = document.querySelector('input[type="file"]') ||
            (targetEl.closest && targetEl.closest('section, form, div') && targetEl.closest('section, form, div').querySelector('input[type="file"]'));
        } catch (menuErr) {}
      }

      if (fileInput) {
        try {
          const proto = window.HTMLInputElement.prototype;
          const descriptor = Object.getOwnPropertyDescriptor(proto, 'files');
          if (descriptor && descriptor.set) {
            descriptor.set.call(fileInput, dt.files);
          } else {
            fileInput.files = dt.files;
          }
        } catch (filesErr) {
          try { fileInput.files = dt.files; } catch (e) {}
        }
        fileInput.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
        fileInput.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
      }

      // Dispatch Drag & Drop events on dropzone wrapper and card if present
      const dropzone = targetEl.tagName === 'INPUT'
        ? (targetEl.closest('[class*="dropzone"], [data-automation-id*="upload"], [class*="resume-upload"], .file-upload, [id*="dropzone"]') || targetEl.parentElement)
        : targetEl;

      const dropTargets = [dropzone, targetEl];
      if (targetEl.closest) {
        const card = targetEl.closest('section, div[class*="card"], div[class*="section"]');
        if (card && !dropTargets.includes(card)) dropTargets.push(card);
      }

      for (const dEl of dropTargets) {
        if (!dEl || dEl === fileInput) continue;
        try {
          dEl.dispatchEvent(new DragEvent('dragenter', { bubbles: true, cancelable: true, dataTransfer: dt }));
          dEl.dispatchEvent(new DragEvent('dragover', { bubbles: true, cancelable: true, dataTransfer: dt }));
          dEl.dispatchEvent(new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: dt }));
        } catch (dragErr) {
          try {
            const dropEvt = new CustomEvent('drop', { bubbles: true, cancelable: true });
            dropEvt.dataTransfer = dt;
            dEl.dispatchEvent(dropEvt);
          } catch (e) {}
        }
      }

      return { success: true, filename: filename, size: data.size };
    } catch (err) {
      return { success: false, error: err.message || 'Synthetic injection failed' };
    }
  }

  /* -- SYNTHETIC COVER LETTER BINARY INJECTION -- */
  function getCoverLetterBinaryFromBackground() {
    return new Promise((resolve) => {
      try {
        const activeCtx = userProfile ? (userProfile.slug || 'roushan') : 'roushan';
        const company = (activeSession && activeSession.company) ? activeSession.company : document.title.replace(/ \|.*/, '').trim().slice(0, 60);
        const jobTitle = (activeSession && activeSession.jobTitle) ? activeSession.jobTitle : '';
        const jdText = (activeSession && activeSession.jdText) || extractPageContent();

        if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
          return resolve({ success: false, error: 'Extension runtime unavailable' });
        }
        chrome.runtime.sendMessage({
          type: 'GET_COVER_LETTER_BINARY',
          activeContext: activeCtx,
          company,
          jobTitle,
          jobDescription: jdText
        }, (res) => {
          if (chrome.runtime.lastError) {
            resolve({ success: false, error: chrome.runtime.lastError.message });
            return;
          }
          resolve(res || { success: false, error: 'Empty response from background streamer' });
        });
      } catch (e) {
        resolve({ success: false, error: e.message });
      }
    });
  }

  async function injectCoverLetterFile(targetEl) {
    if (!targetEl) return { success: false, error: 'No target element provided' };

    const data = await getCoverLetterBinaryFromBackground();
    if (!data || !data.success || !data.base64) {
      return { success: false, error: (data && data.error) || 'Failed to stream cover letter binary from background' };
    }

    try {
      const filename = data.filename || 'Candidate_Cover_Letter.pdf';
      const mimeType = data.mimeType || 'application/pdf';
      const blob = base64ToBlob(data.base64, mimeType);
      const file = new File([blob], filename, {
        type: mimeType,
        lastModified: Date.now()
      });

      const dt = new DataTransfer();
      dt.items.add(file);

      let fileInput = null;
      if (targetEl.tagName === 'INPUT' && targetEl.type === 'file') {
        fileInput = targetEl;
      } else {
        fileInput = targetEl.querySelector('input[type="file"]') ||
          (targetEl.closest('form, [class*="application"], body') && targetEl.closest('form, [class*="application"], body').querySelector('input[type="file"]'));
      }

      if (fileInput) {
        try {
          fileInput.files = dt.files;
        } catch (filesErr) {}
        fileInput.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
        fileInput.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
      }

      return { success: true, filename: filename };
    } catch (err) {
      return { success: false, error: err.message || 'Synthetic cover letter injection failed' };
    }
  }

  /* -- REACT / VUE NATIVE INPUT DISPATCHER -- */
  function setNativeValue(el, value, isFinal = true, fieldType = '') {
    if (!el) return;
    if (isComboboxOrSelect(el)) {
      fillUniversalCombobox(el, value, fieldType).catch(() => {});
      return;
    }

    const doc = el.ownerDocument || document;
    const win = (el.ownerDocument && el.ownerDocument.defaultView) ? el.ownerDocument.defaultView : window;

    if (el.tagName === 'INPUT' && el.type === 'radio') {
      const radios = el.name
        ? doc.querySelectorAll('input[type="radio"][name="' + CSS.escape(el.name) + '"]')
        : [el];
      let target = null;
      const valLower = String(value).toLowerCase();
      for (let i = 0; i < radios.length; i++) {
        const rVal = String(radios[i].value).toLowerCase();
        const labelText = getLabelText(radios[i]).toLowerCase();
        if (rVal === valLower || labelText.includes(valLower) ||
           (valLower === 'yes' && (rVal === 'true' || rVal === '1')) ||
           (valLower === 'no' && (rVal === 'false' || rVal === '0'))) {
          target = radios[i]; break;
        }
      }
      if (target) {
        target.checked = true;
        target.dispatchEvent(new Event('input', { bubbles: true }));
        target.dispatchEvent(new Event('change', { bubbles: true }));
      }
      return;
    }

    if (el.tagName === 'INPUT' && el.type === 'checkbox') {
      const valLower = String(value).toLowerCase();
      const shouldCheck = valLower === 'yes' || valLower === 'true' || valLower === '1' || valLower === 'checked';
      if (el.checked !== shouldCheck) {
        try { el.click(); } catch(e) {}
      }
      let setter = null;
      try {
        const proto = (win.HTMLInputElement && win.HTMLInputElement.prototype) || Object.getPrototypeOf(el);
        setter = Object.getOwnPropertyDescriptor(proto, 'checked');
      } catch (e) {}
      if (setter && setter.set) {
        try { setter.set.call(el, shouldCheck); } catch (e) { el.checked = shouldCheck; }
      } else {
        el.checked = shouldCheck;
      }
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return;
    }

    try {
      if (doc.activeElement !== el) {
        el.focus();
      }
    } catch (e) {}

    let proto = null;
    try {
      if (el.tagName === 'TEXTAREA') {
        proto = (win.HTMLTextAreaElement && win.HTMLTextAreaElement.prototype) || Object.getPrototypeOf(el);
      } else {
        proto = (win.HTMLInputElement && win.HTMLInputElement.prototype) || Object.getPrototypeOf(el);
      }
    } catch (e) {
      proto = Object.getPrototypeOf(el);
    }

    let setter = null;
    try {
      setter = Object.getOwnPropertyDescriptor(proto, 'value');
    } catch (e) {}

    if (setter && setter.set) {
      try {
        setter.set.call(el, value);
      } catch (e) {
        el.value = value;
      }
    } else {
      el.value = value;
    }

    if (el._valueTracker) {
      try { el._valueTracker.setValue(''); } catch(e) {}
    }
    try {
      el.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: String(value) }));
    } catch (e) {
      el.dispatchEvent(new Event('input', { bubbles: true }));
    }
    if (isFinal) {
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new Event('blur', { bubbles: true }));
      try {
        if (win.$ && win.$(el).trigger) {
          win.$(el).trigger('change');
        }
      } catch (e) {}
      try {
        if (win.angular) {
          const ngEl = win.angular.element(el);
          if (ngEl) {
            ngEl.triggerHandler('input');
            ngEl.triggerHandler('change');
            const scope = (ngEl.scope && ngEl.scope()) || (ngEl.isolateScope && ngEl.isolateScope());
            if (scope && !scope.$$phase && scope.$apply) {
              scope.$apply();
            }
          }
        }
      } catch (ngErr) {}
    }
  }

  /* -- TYPE LABELS -- */
  const TYPE_LABELS = {
    RESUME: 'Resume / CV',
    FIRST_NAME: 'First Name', LAST_NAME: 'Last Name', FULL_NAME: 'Full Name',
    EMAIL: 'Email Address', PHONE_TYPE: 'Phone Type', PHONE: 'Phone Number',
    LOCATION: 'Location', CITY: 'City', STATE: 'State / Province', COUNTRY: 'Country',
    LINKEDIN: 'LinkedIn URL', GITHUB: 'GitHub URL', PORTFOLIO: 'Portfolio URL',
    TITLE: 'Job Title', COVER_LETTER: 'Cover Letter', SUMMARY: 'Summary',
    WORK_AUTH: 'Work Authorization', VISA: 'Visa Sponsorship', SALARY: 'Salary', SCREENING: 'Screening Q',
    NOTICE_PERIOD: 'Notice Period', RELOCATE: 'Relocate', EDUCATION: 'Highest Education',
    GENDER: 'Gender', PRONOUNS: 'Pronouns',
    ADDRESS_TYPE: 'Address Type', ADDRESS: 'Street Address', APT: 'Apartment/Suite', ZIP: 'ZIP Code',
    EXP_STATE: 'Work State', EXP_CITY: 'Work City', EXP_COUNTRY: 'Work Country',
    START_DAY: 'Start Day', END_DAY: 'End Day', REASON_FOR_LEAVING: 'Reason for Leaving',
    TEXT_CONSENT: 'Text / SMS Consent',
    HEAR_ABOUT: 'Referral Source', HEAR_ABOUT_DETAIL: 'Source Detail',
    AGE_18: 'Legal Age (18+)', PREVIOUS_EMPLOYED: 'Prior Employment', PRIVACY_CONSENT: 'Privacy Agreement',
    AI_CONSENT: 'AI Processing Consent', AI_USAGE: 'AI Tools Usage', GOVT_OFFICIAL: 'Government Official',
    GOVT_RELATIVE: 'Government Relative', CONFLICT_INTEREST: 'Conflict of Interest',
    REFERRED_BY_LEADER: 'Senior Referral', HISPANIC_LATINO: 'Hispanic / Latino',
    VETERAN: 'Veteran Status', DISABILITY: 'Disability Status', RACE_ETHNICITY: 'Race / Ethnicity',
    COMPANY: 'Company Name', EMPLOYMENT_TITLE: 'Job Title', START_MONTH: 'Start Month', START_YEAR: 'Start Year',
    END_MONTH: 'End Month', END_YEAR: 'End Year', CURRENT_ROLE: 'Current Role',
    SCHOOL: 'School / University', DEGREE: 'Degree', DISCIPLINE: 'Discipline / Major',
    GRADUATION_YEAR: 'Graduation Year', LANGUAGES: 'Languages',
    SCREENING_SELECT: 'Screening Question',
    WORK_DESCRIPTION: 'Work Description', PASSWORD: 'Password', CONFIRM_PASSWORD: 'Confirm Password', LOGIN_ID: 'Login ID / Username',
    PREFERRED_NAME: 'Preferred Name',
    PREFERRED_LOCATION: 'Preferred Location',
    WORKPLACE_TYPE: 'Workplace Preference'
  };

  /* -- RESOLVE SCREENING SELECT (DETERMINISTIC ASYMMETRIC SAFETY FIREWALL) -- */
  function resolveScreeningSelect(element, profile = null) {
    const prof = profile || userProfile || STANDALONE_PROFILES.roushan;
    const q = getLabelText(element).toLowerCase();

    // Export regulations / Space tech compliance (e.g. Astranis, SpaceX, Rocket Lab)
    if (q.includes('export regulation') || q.includes('space technology') || q.includes('state which of the following applies to you')) {
      const isUSCitizen = prof && !prof.requiresVisa && (prof.country === 'United States' || prof.country === 'USA');
      return isUSCitizen ? 'I am a U.S. Citizen.' : 'None of the above.';
    }

    // Internship season confirmation
    if (q.includes('confirm the season') || q.includes('season you are applying for') || q.includes('applying for season')) {
      return 'Summer 2027';
    }

    // Onsite / In-person commitment
    if (q.includes('onsite') || q.includes('san francisco hq') || q.includes('5 days a week')) {
      return 'Yes';
    }

    // SMS / Text communication consent
    if (q.includes('sms') || q.includes('text message') || q.includes('recruiting sms')) {
      return 'Yes';
    }

    // 0. SPECIALIZED CASE QUESTIONS (Non-Yes/No Options)
    // Preferred Office / Workplace / Remote Decision Logic
    if (
      q.includes('preferred office') ||
      q.includes('office location') ||
      q.includes('preferred location') ||
      q.includes('location preference') ||
      q.includes('workplace') ||
      q.includes('work arrangement') ||
      q.includes('remote or hybrid') ||
      q.includes('remote, hybrid') ||
      q.includes('which office') ||
      q.includes('where would you like to work')
    ) {
      return (userProfile && userProfile.preferredLocation) || 'Remote';
    }

    if (q.includes('last month') || (q.includes('tencent') && (q.includes('month') || q.includes('when')))) {
      return 'n/a';
    }
    if (q.includes('language') && !q.includes('programming')) {
      return 'English';
    }
    if (q.includes('gender') || q.includes('sex')) {
      return (userProfile && userProfile.gender) || 'Male';
    }
    if (q.includes('bs, ms, or phd') || q.includes('degree program') || q.includes('pursuing a bs')) {
      return 'BS';
    }
    if (q.includes('remaining in your degree') || q.includes('at least one term') || q.includes('semester remaining')) {
      return 'Yes';
    }

    // 1. KNOCKOUT & DISQUALIFY QUESTIONS -> ABSOLUTELY "NO"
    if (
      q.includes('previously worked') ||
      q.includes('worked for') ||
      q.includes('worked at') ||
      q.includes('prior employee') ||
      q.includes('former employee') ||
      q.includes('previously been employed') ||
      q.includes('previously employed') ||
      q.includes('contractor or full-time') ||
      q.includes('contractor') ||
      q.includes('rioter') ||
      q.includes('tencent') ||
      q.includes('affiliate') ||
      q.includes('subsidiary') ||
      q.includes('previously applied') ||
      q.includes('applied to') ||
      q.includes('applied before') ||
      q.includes('sponsor') ||
      q.includes('sponsorship') ||
      q.includes('require visa') ||
      q.includes('felony') ||
      q.includes('criminal') ||
      q.includes('misdemeanor') ||
      q.includes('convicted') ||
      q.includes('disciplinary') ||
      q.includes('discharged') ||
      q.includes('terminated for cause') ||
      q.includes('fired') ||
      q.includes('relative') ||
      q.includes('family member') ||
      q.includes('conflict of interest') ||
      q.includes('conflict') ||
      q.includes('non-compete') ||
      q.includes('restrictive covenant') ||
      q.includes('government official') ||
      q.includes('public office') ||
      q.includes('civil service') ||
      q.includes('suspended') ||
      q.includes('debarred')
    ) {
      return 'No';
    }

    // 2. COMPLIANCE, CONSENT, POLICIES & WORK AUTH -> ABSOLUTELY "YES"
    if (
      q.includes('authorized to work') ||
      q.includes('legally authorized') ||
      q.includes('18 years') ||
      q.includes('at least 18') ||
      q.includes('consent') ||
      q.includes('acknowledge') ||
      q.includes('agree') ||
      q.includes('privacy notice') ||
      q.includes('privacy policy') ||
      q.includes('candidate privacy') ||
      q.includes('e-verify') ||
      q.includes('truthful') ||
      q.includes('certify') ||
      q.includes('terms and conditions') ||
      q.includes('terms') ||
      q.includes('background check') ||
      q.includes('drug screen') ||
      q.includes('reference check') ||
      q.includes('reliable internet') ||
      q.includes('comfortable with remote') ||
      q.includes('relocate') ||
      q.includes('40 hour') ||
      q.includes('remote internship')
    ) {
      return 'Yes';
    }

    // 3. PRODUCT / GAME / TEAM PREFERENCE -> League of Legends / Technology
    if (q.includes('product') || q.includes('interested in working on') || q.includes('project') || q.includes('team')) {
      return 'League of Legends';
    }

    // Safety-first default against risk knockout: return 'No'
    return 'No';
  }

  /* -- RESOLVE PREVIEW -- */
  function resolvePreview(field, profile, session) {
    const loc = parseLocation(profile.location);
    switch (field.type) {
      case 'RESUME':       return session ? (session.jobTitle ? 'Tailored PDF (' + session.jobTitle + ')' : 'Master Resume.pdf') : 'Master Resume.pdf';
      case 'FIRST_NAME':   return profile.firstName || null;
      case 'LAST_NAME':    return profile.lastName || null;
      case 'FULL_NAME':    return profile.fullName || null;
      case 'PREFERRED_NAME': return profile.firstName || null;
      case 'EMAIL':        return profile.email || null;
      case 'PHONE_TYPE':   return profile.phoneType || 'Mobile';
      case 'PHONE':        return profile.phone || null;
      case 'LOCATION':     return profile.location || null;
      case 'PREFERRED_LOCATION':
      case 'WORKPLACE_TYPE': return profile.preferredLocation || 'Remote';
      case 'CITY':         return profile.city || loc.city || null;
      case 'STATE':        return profile.state || loc.state || null;
      case 'COUNTRY':      return profile.country || loc.country || null;
      case 'ADDRESS_TYPE': return profile.addressType || 'Home';
      case 'ADDRESS':      return profile.streetAddress || profile.city || loc.city || null;
      case 'APT':          return profile.apartment || null;
      case 'ZIP': {
        const rawZip = String(profile.zipCode || '800024').trim();
        const el = field.element;
        if (el && el.maxLength === 5) return rawZip.slice(0, 5);
        return rawZip;
      }
      case 'EXP_STATE':    return profile.state || loc.state || 'Bihar';
      case 'EXP_CITY':     return profile.city || loc.city || 'Patna';
      case 'EXP_COUNTRY':  return profile.country || loc.country || 'India';
      case 'START_DAY':    return '1';
      case 'END_DAY':      return '1';
      case 'REASON_FOR_LEAVING': return 'Seeking career growth and developer opportunities';
      case 'TEXT_CONSENT': return 'Yes';
      case 'WORK_DESCRIPTION': return profile.workDescription || (profile.virtualExps && profile.virtualExps[0] ? profile.virtualExps[0].outcome : profile.professionalSummary);
      case 'PASSWORD':
      case 'CONFIRM_PASSWORD': return '••••••••••••';
      case 'LOGIN_ID': return profile.email || 'roushan@gmail.com';
      case 'HEAR_ABOUT':   return profile.referralSource || 'LinkedIn';
      case 'HEAR_ABOUT_DETAIL': return 'Job Posting';
      case 'LINKEDIN':     return profile.linkedinUrl || null;
      case 'GITHUB':       return profile.githubUrl || null;
      case 'PORTFOLIO':    return profile.portfolioUrl || null;
      case 'TITLE': {
        let t = session ? session.jobTitle : (profile.title || null);
        if (t) t = t.replace(/\bEngineer\b/gi, 'Developer');
        return t;
      }
      case 'SUMMARY':      return session ? (session.tailoredSummary || null) : (profile.professionalSummary || null);
      case 'SALARY':       return session ? (session.salaryRange || null) : (profile.salaryRange || null);
      case 'NOTICE_PERIOD':return profile.noticePeriod || 'Immediate';
      case 'RELOCATE':     return profile.willingnessToRelocate ? 'Yes' : 'No';
      case 'EDUCATION':    return profile.highestEducation || 'Bachelor of Computer Applications (BCA)';
      case 'GENDER':       return profile.gender || 'Male';
      case 'PRONOUNS':     return profile.pronouns || 'He/Him';
      case 'WORK_AUTH':    return profile.workAuthorized ? 'Yes' : 'No';
      case 'VISA':         return profile.requiresVisa ? 'Yes' : 'No';
      case 'AGE_18':       return profile.is18OrOlder || 'Yes';
      case 'PREVIOUS_EMPLOYED': return profile.previouslyEmployed || 'No';
      case 'PRIVACY_CONSENT': return profile.privacyConsent || 'Yes';
      case 'AI_CONSENT':   return profile.aiConsent || 'Yes';
      case 'AI_USAGE':     return profile.aiUsage ? 'Daily AI Copilot' : 'Daily AI Copilot';
      case 'GOVT_OFFICIAL': return profile.governmentOfficial || 'No';
      case 'GOVT_RELATIVE': return profile.relativeGovernmentOfficial || 'No';
      case 'CONFLICT_INTEREST': return profile.conflictOfInterest || 'No';
      case 'REFERRED_BY_LEADER': return profile.referredByLeader || 'No';
      case 'HISPANIC_LATINO': return profile.hispanicLatino || 'No';
      case 'VETERAN':      return profile.veteranStatus || 'I am not a protected veteran';
      case 'DISABILITY':   return profile.disabilityStatus || "No, I don't have a disability";
      case 'RACE_ETHNICITY': {
        if (profile.race) return profile.race;
        const locStr = `${profile.country || ''} ${profile.location || ''} ${profile.city || ''} ${profile.state || ''}`.toLowerCase();
        if (locStr.includes('india') || locStr.includes('patna') || locStr.includes('bihar') || locStr.includes('noida') || locStr.includes('delhi')) {
          return 'Asian';
        }
        return 'Asian';
      }
      case 'COMPANY':      return profile.company || 'AstreWork';
      case 'EMPLOYMENT_TITLE': {
        let t = profile.employmentTitle || profile.title || 'Full-Stack Developer';
        t = t.replace(/\bEngineer\b/gi, 'Developer');
        return t;
      }
      case 'START_MONTH':  return profile.startMonth || 'July';
      case 'START_YEAR':   return profile.startYear || '2025';
      case 'END_MONTH':    return profile.endMonth || 'July';
      case 'END_YEAR': {
        const y = profile.endYear;
        if (!y || y.toLowerCase() === 'present' || y.toLowerCase() === 'current') {
          return '2028';
        }
        return y;
      }
      case 'CURRENT_ROLE': return profile.currentRole !== false ? 'Yes' : 'No';
      case 'SCHOOL':       return profile.school || 'Amity University';
      case 'DEGREE':       return profile.degree || profile.highestEducation || 'Bachelor of Computer Applications (BCA)';
      case 'DISCIPLINE':   return profile.discipline || 'Computer Science';
      case 'GRADUATION_YEAR': return profile.graduationYear || '2028';
      case 'LANGUAGES':    return profile.languages || 'English, Hindi';
      case 'SCREENING_SELECT': return resolveScreeningSelect(field.element, profile);
      case 'COVER_LETTER': return null;
      case 'SCREENING': {
        const labelText = getLabelText(field.element).toLowerCase();
        if (
          labelText.includes('relative') ||
          labelText.includes('family member') ||
          labelText.includes('conflict of interest') ||
          labelText.includes('non-compete') ||
          labelText.includes('criminal') ||
          /type\s*["']?na["']?/i.test(labelText) ||
          /if\s*["']?yes["']?,?\s*please/i.test(labelText)
        ) {
          return 'N/A';
        }
        return null;
      }
      default: return null;
    }
  }

  /* -- RESOLVE VALUE (async, calls AI for COVER_LETTER/SCREENING) -- */
  async function resolveValue(field, profile, session) {
    const loc = parseLocation(profile.location);
    switch (field.type) {
      case 'RESUME':
      case 'COVER_LETTER_FILE': return 'SYNTHETIC_RESUME_BINARY';
      case 'FIRST_NAME':  return profile.firstName;
      case 'LAST_NAME':   return profile.lastName;
      case 'FULL_NAME':   return profile.fullName;
      case 'PREFERRED_NAME': return profile.firstName || 'Candidate';
      case 'EMAIL':       return profile.email;
      case 'PHONE_TYPE':  return profile.phoneType || 'Mobile';
      case 'PHONE_COUNTRY_CODE': return profile.phoneCountryCode || '+91';
      case 'PHONE': {
        const rawPhone = profile.phone || '';
        if (!rawPhone) return '';
        const phoneDigits = rawPhone.replace(/\D/g, '');
        if (field.element && field.element.maxLength === 10) return phoneDigits.slice(-10);
        if (field.element && (field.element.type === 'number' || field.element.inputMode === 'numeric')) return phoneDigits;
        return rawPhone;
      }
      case 'LOCATION':
      case 'LOCATION_AUTOCOMPLETE': return profile.location || (loc.city ? `${loc.city}, ${loc.country || 'India'}` : 'Patna, Bihar, India');
      case 'PREFERRED_LOCATION':
      case 'WORKPLACE_TYPE': return profile.preferredLocation || 'Remote';
      case 'CITY':        return profile.city || loc.city || '';
      case 'STATE':       return profile.state || loc.state || '';
      case 'COUNTRY':     return profile.country || loc.country || '';
      case 'ADDRESS_TYPE': return profile.addressType || 'Home';
      case 'ADDRESS':     return profile.streetAddress || profile.city || loc.city || '';
      case 'APT':         return profile.apartment || '';
      case 'ZIP':
      case 'ZIP_CODE': {
        const rawZip = String(profile.zipCode || '800024').trim();
        const el = field.element;
        if (el) {
          if (el.maxLength === 5) return rawZip.slice(0, 5);
          const pattern = el.getAttribute('pattern') || '';
          if (pattern.includes('{5}') || pattern === '\\d{5}') return rawZip.slice(0, 5);
          const placeholder = (el.placeholder || '').trim();
          if (/^\d{5}$/.test(placeholder) || placeholder.toLowerCase() === '12345') return rawZip.slice(0, 5);
        }
        return rawZip;
      }
      case 'EXP_STATE':    return profile.state || loc.state || 'Bihar';
      case 'EXP_CITY':     return profile.city || loc.city || 'Patna';
      case 'EXP_COUNTRY':  return profile.country || loc.country || 'India';
      case 'START_DAY':    return '1';
      case 'END_DAY':      return '1';
      case 'REASON_FOR_LEAVING': return 'Seeking career growth and developer opportunities';
      case 'TEXT_CONSENT': return 'Yes';
      case 'WORK_DESCRIPTION': {
        if (profile.workDescription) return profile.workDescription;
        if (profile.virtualExps && profile.virtualExps.length > 0) {
          const exp = profile.virtualExps[0];
          return `${exp.actionTaken || ''}. ${exp.outcome || ''}`.trim() || profile.professionalSummary;
        }
        return profile.professionalSummary || 'Architected and developed high-performance cloud applications, API microservices, and distributed scraping pipelines.';
      }
      case 'LOGIN_ID': {
        try {
          const credRes = await apFetch('/credentials?siteUrl=' + encodeURIComponent(window.location.hostname));
          if (credRes.ok) {
            const cData = await credRes.json();
            if (cData && cData.credential && cData.credential.loginId) {
              return cData.credential.loginId;
            }
          }
        } catch (e) {}
        return profile.email || 'roushan@gmail.com';
      }
      case 'PASSWORD':
      case 'CONFIRM_PASSWORD': {
        if (window.__ap_staged_password) {
          return window.__ap_staged_password;
        }
        try {
          const credRes = await apFetch('/credentials?siteUrl=' + encodeURIComponent(window.location.hostname));
          if (credRes.ok) {
            const cData = await credRes.json();
            if (cData && cData.credential && cData.credential.password) {
              window.__ap_staged_password = cData.credential.password;
              return cData.credential.password;
            }
          }
        } catch (e) {}

        try {
          const genRes = await apFetch('/credentials?generate=true');
          if (genRes.ok) {
            const gData = await genRes.json();
            if (gData && gData.password) {
              window.__ap_staged_password = gData.password;
              window.__ap_needs_save = true;
              return gData.password;
            }
          }
        } catch (e) {}

        const fallbackPwd = 'Ast' + Math.random().toString(36).slice(2, 8).toUpperCase() + '@2026!';
        window.__ap_staged_password = fallbackPwd;
        window.__ap_needs_save = true;
        return fallbackPwd;
      }
      case 'HEAR_ABOUT':  return profile.referralSource || 'LinkedIn';
      case 'HEAR_ABOUT_DETAIL': return 'Job Posting';
      case 'REFERRAL':    return profile.referralSource || 'LinkedIn';
      case 'LINKEDIN':    return profile.linkedinUrl;
      case 'GITHUB':      return profile.githubUrl;
      case 'PORTFOLIO':
      case 'WEBSITE':     return profile.portfolioUrl || profile.website || 'https://astrework.app';
      case 'GPA':         return profile.gpa || '9.2';
      case 'WHY_US': {
        const company = session && session.company ? session.company : document.title.replace(/ \|.*/, '').trim().slice(0, 60);
        return `I am eager to contribute to ${company} because of your ambitious mission and technical excellence in building mission-critical software systems. As a Full-Stack Developer with deep experience in cloud architectures and real-time distributed systems, I thrive in fast-paced environments where reliability and performance matter.`;
      }
      case 'TITLE': {
        let t = session ? session.jobTitle : profile.title;
        if (t) t = t.replace(/\bEngineer\b/gi, 'Developer');
        return t;
      }
      case 'SUMMARY':     return session ? session.tailoredSummary : profile.professionalSummary;
      case 'WORK_AUTH':   return profile.workAuthorized ? 'Yes' : 'No';
      case 'SALARY': {
        const rawSal = session ? session.salaryRange : (profile.salaryRange || null);
        if (!rawSal) return null;
        if (field.element && (field.element.type === 'number' || field.element.inputMode === 'numeric')) {
          const nums = String(rawSal).replace(/[^0-9-]/g, '').split('-').map(Number).filter(Boolean);
          if (nums.length >= 2) return String(Math.round((nums[0] + nums[1]) / 2));
          if (nums.length === 1) return String(nums[0]);
        }
        return rawSal;
      }
      case 'NOTICE_PERIOD': return profile.noticePeriod || 'Immediate';
      case 'RELOCATE':    return profile.willingnessToRelocate ? 'Yes' : 'No';
      case 'EDUCATION':   return profile.highestEducation || 'Bachelor of Computer Applications (BCA)';
      case 'GENDER':      return profile.gender || 'Male';
      case 'PRONOUNS':    return profile.pronouns || 'He/Him';
      case 'VISA':        return profile.requiresVisa ? 'Yes' : 'No';
      case 'AGE_18':       return profile.is18OrOlder || 'Yes';
      case 'PREVIOUS_EMPLOYED': return profile.previouslyEmployed || 'No';
      case 'PRIVACY_CONSENT': return profile.privacyConsent || 'Confirmed';
      case 'AI_CONSENT':   return profile.aiConsent || 'Yes';
      case 'AI_USAGE':     return profile.aiUsage ? 'regularly use AI tools' : 'regularly use AI tools';
      case 'GOVT_OFFICIAL': return profile.governmentOfficial || 'No';
      case 'GOVT_RELATIVE': return profile.relativeGovernmentOfficial || 'No';
      case 'CONFLICT_INTEREST': return profile.conflictOfInterest || 'No';
      case 'REFERRED_BY_LEADER': return profile.referredByLeader || 'No';
      case 'HISPANIC_LATINO': return profile.hispanicLatino || 'No';
      case 'VETERAN':      return profile.veteranStatus || 'I am not a protected veteran';
      case 'DISABILITY':   return profile.disabilityStatus || "No, I don't have a disability";
      case 'RACE_ETHNICITY': {
        if (profile.race) return profile.race;
        const locStr = `${profile.country || ''} ${profile.location || ''} ${profile.city || ''} ${profile.state || ''}`.toLowerCase();
        if (locStr.includes('india') || locStr.includes('patna') || locStr.includes('bihar') || locStr.includes('noida') || locStr.includes('delhi')) {
          return 'Asian';
        }
        return 'Asian';
      }
      case 'COMPANY':      return profile.company || 'AstreWork';
      case 'EMPLOYMENT_TITLE': {
        let t = profile.employmentTitle || profile.title || 'Full-Stack Developer';
        t = t.replace(/\bEngineer\b/gi, 'Developer');
        return t;
      }
      case 'START_MONTH':  return profile.startMonth || 'July';
      case 'START_YEAR':   return profile.startYear || '2025';
      case 'END_MONTH':    return profile.endMonth || 'July';
      case 'END_YEAR': {
        const y = profile.endYear;
        if (!y || y.toLowerCase() === 'present' || y.toLowerCase() === 'current') {
          return '2028';
        }
        return y;
      }
      case 'CURRENT_ROLE': return profile.currentRole !== false ? 'Yes' : 'No';
      case 'SCHOOL':       return profile.school || 'Amity University';
      case 'DEGREE':       return profile.degree || profile.highestEducation || 'Bachelor of Computer Applications (BCA)';
      case 'DISCIPLINE':   return profile.discipline || 'Computer Science';
      case 'GRADUATION_YEAR': return profile.graduationYear || '2028';
      case 'LANGUAGES':    return profile.languages || 'English, Hindi';
      case 'SCREENING_SELECT': return resolveScreeningSelect(field.element, profile);
      case 'COVER_LETTER': {
        const company = session && session.company ? session.company : document.title.replace(/ \|.*/, '').trim().slice(0, 60);
        const jobTitle = session && session.jobTitle ? session.jobTitle : '';
        const jdText = (session && session.jdText) || extractPageContent();
        const isNoteOrPitch = field.element && (
          field.element.getAttribute('name') === 'userNote' ||
          field.element.id === 'userNote' ||
          (field.element.getAttribute('placeholder') || '').toLowerCase().includes('pitch') ||
          (field.element.getAttribute('placeholder') || '').toLowerCase().includes('note')
        );

        try {
          const res = await apFetch('/cover-letter', {
            method: 'POST',
            body: JSON.stringify({
              company,
              jobTitle,
              jobDescription: jdText,
              candidateId: userProfile?.slug || 'roushan',
              format: 'text'
            })
          });
          if (res.ok) {
            const data = await res.json();
            if (data.success) {
              const textToUse = (isNoteOrPitch && data.startupPitch) ? data.startupPitch : data.coverLetter;
              if (activeHud) {
                activeHud.setCoverLetter(data.coverLetter);
              }
              // Sync application kit in real time
              apFetch('/kit-sync', {
                method: 'POST',
                body: JSON.stringify({
                  company,
                  jobTitle,
                  jobDescription: jdText,
                  coverLetter: data.coverLetter,
                  startupPitch: data.startupPitch,
                  candidateId: userProfile?.slug || 'roushan'
                })
              }).catch(() => {});
              return textToUse;
            }
          }
        } catch (e) {
          console.warn('[AstrePilot] Cover letter generation error:', e);
        }

        // Offline / fallback pitch
        return (profile.professionalSummary && profile.professionalSummary.length > 30)
          ? profile.professionalSummary
          : ("I am a dedicated Full-Stack Developer excited about the opportunity to contribute high-impact systems at " + company + ".");
      }
      case 'SCREENING': {
        const labelText = getLabelText(field.element);
        const question = labelText.slice(0, 300) || 'Tell us about yourself';
        const qLower = question.toLowerCase();

        // Immediate procedural question interceptor (relatives, compliance, "Type NA")
        if (
          qLower.includes('relative') ||
          qLower.includes('family member') ||
          qLower.includes('family') ||
          qLower.includes('friends') ||
          qLower.includes('friend') ||
          qLower.includes('significant other') ||
          qLower.includes('conflict of interest') ||
          qLower.includes('non-compete') ||
          qLower.includes('criminal') ||
          /type\s*["']?na["']?/i.test(qLower) ||
          /if\s*["']?yes["']?,?\s*please/i.test(qLower)
        ) {
          return 'N/A';
        }

        // Candidate availability & earliest start date determination
        if (
          qLower.includes('when are you able to join') ||
          qLower.includes('able to join as an intern') ||
          qLower.includes('earliest start') ||
          qLower.includes('start date') ||
          qLower.includes('how soon can you start') ||
          qLower.includes('available to start')
        ) {
          const pref = (profile && (profile.availability || profile.noticePeriod)) || 'Immediate';
          if (pref.toLowerCase().includes('immediate') || pref.toLowerCase().includes('now') || pref.toLowerCase().includes('flexible')) {
            return 'Available immediately / Earliest available date (Flexible)';
          }
          return pref;
        }

        // Internship end date determination
        if (qLower.includes('ending your internship') || qLower.includes('plan on ending') || qLower.includes('end date')) {
          return 'Flexible based on program requirements (typically 12-16 weeks)';
        }

        const company = session && session.company ? session.company : document.title.replace(/ \|.*/, '').trim().slice(0, 60);
        const jobTitle = session && session.jobTitle ? session.jobTitle : '';

        // Domain screening motivation tailored for Riot Games
        if (
          qLower.includes('riot games') ||
          (company.toLowerCase().includes('riot') && (qLower.includes('why are you interested') || qLower.includes('software engineering intern'))) ||
          qLower.includes('interested in working at riot games')
        ) {
          return "I am deeply inspired by Riot Games' player-first engineering culture and dedication to high-performance systems in titles like League of Legends and VALORANT. As a systems developer passionate about distributed architectures, high-concurrency cloud systems, and real-time multiplayer performance, I want to contribute to building robust, low-latency backend infrastructure and game services that empower millions of players globally.";
        }

        // 1. Check Candidate Screening Q&A Vault first (sub-5ms, zero LLM latency)
        try {
          const vaultRes = await apFetch('/vault/match', {
            method: 'POST',
            body: JSON.stringify({ question, company, jobTitle }),
          });
          if (vaultRes.ok) {
            const vaultData = await vaultRes.json();
            if (vaultData && vaultData.matched && vaultData.answer) {
              field.source = 'vault';
              field.confidence = vaultData.confidence;
              field.vaultId = vaultData.vaultId;
              return vaultData.answer;
            }
          }
        } catch (e) {
          /* proceed to oracle/answer */
        }

        const liveJdText = (session && session.jdText) || getCachedLiveJD() || '';
        try {
          // Attempt high-reasoning Antigravity AI Oracle next with live JD context
          let res = await apFetch('/oracle', {
            method: 'POST',
            body: JSON.stringify({
              question,
              company,
              jobTitle,
              jobDescription: liveJdText || undefined,
            }),
          });
          // Fallback to standard answer endpoint if oracle is unavailable
          if (!res.ok) {
            res = await apFetch('/answer', {
              method: 'POST',
              body: JSON.stringify({
                question, company, jobTitle,
                context: liveJdText ? 'JOB DESCRIPTION:\n' + liveJdText + '\n\nTAILORED PROFILE:\n' + ((session && session.tailoredSummary) || profile.professionalSummary || '') : (profile._context || ''),
              }),
            });
          }
          if (res.ok) {
            const data = await res.json();
            if (data.answer) return data.answer;
          }
        } catch (e) {}

        // Autonomous Offline Grounded Multi-Story Resolver for Screening Questions
        const isAyushi = (profile && profile.slug === 'ayushi') || (profile && /ayushi/i.test(profile.fullName || ''));

        // Topic 1: Most Impressive Accomplishment / Greatest Achievement / Proudest Milestone
        if (
          qLower.includes('accomplish') ||
          qLower.includes('proudest') ||
          qLower.includes('achievement') ||
          qLower.includes('success') ||
          qLower.includes('biggest impact')
        ) {
          return isAyushi
            ? "Designing and shipping AstreWork's frontend architecture and responsive design system has been my proudest technical milestone. I built a 6-stage Shadow DOM interface and real-time ATS resume canvas, ensuring sub-frame render times, full keyboard accessibility, and a seamless candidate experience."
            : "Building AstreWork and running it live in production on an Oracle Cloud ARM64 server has been my proudest technical achievement. I engineered the system from scratch to aggregate and rank opportunities from over a dozen sources with sub-second vector search, maintaining database isolation and zero downtime. Taking a complex distributed system from an initial idea to a functioning platform that people actually rely on has been deeply rewarding.";
        }

        // Topic 2: Most Complex Project / Hardest Technical Challenge
        if (
          qLower.includes('complex project') ||
          qLower.includes('impressive project') ||
          qLower.includes('impressive and complex') ||
          qLower.includes('technical challenge') ||
          qLower.includes('project you have worked on') ||
          qLower.includes('past project') ||
          qLower.includes('school project')
        ) {
          return isAyushi
            ? "My most complex project was engineering Alyra Lock, a zero-knowledge credential vault running client-side using the WebCrypto API. The hardest challenge was ensuring zero plaintext data ever touches the network. I implemented client-side PBKDF2 key derivation with 600,000 iterations and AES-256-GCM encryption, guaranteeing security without relying on server trust."
            : "My most complex project was Astra Vision, a code analysis service built with Python and FastAPI. The core challenge was safely parsing code into abstract syntax trees (ASTs) using Tree-Sitter and constructing dependency graphs for untrusted user snippets. I designed an isolated subprocess sandbox with memory limits and syscall filtering, maintaining sub-200ms analysis times while preventing arbitrary execution.";
        }

        // Topic 3: Hardest Problem / Bug / Obstacle Overcome
        if (
          qLower.includes('challenge') ||
          qLower.includes('bug') ||
          qLower.includes('problem you solved') ||
          qLower.includes('difficult') ||
          qLower.includes('obstacle')
        ) {
          return isAyushi
            ? "While building our browser extension HUD, I solved host CSS bleeding by migrating our interface to a closed Shadow DOM container. By scoping custom CSS properties and bridging synthetic DOM events, I completely prevented third-party portal styles and event listeners from crashing the UI."
            : "While scaling AstreWork's background workers, I diagnosed an intermittent SQLite database lock caused by concurrent write transactions. I traced the timing contention, introduced an in-memory queue with exponential backoff and connection pooling, and verified zero locked queries across tens of thousands of automated cycles.";
        }

        // Topic 4: Role Motivation / Why This Company
        if (
          qLower.includes('why') ||
          qLower.includes('interest') ||
          qLower.includes('motivation') ||
          qLower.includes('excited')
        ) {
          return isAyushi
            ? `I want to contribute to ${company} because I admire your focus on high-quality, reliable software products. As a Full-Stack Developer passionate about responsive architectures, design systems, and frontend performance, I thrive in environments where engineering discipline and user empathy meet.`
            : `I am excited to apply to ${company} to contribute to mission-critical, high-reliability software systems. With hands-on experience in backend architectures, distributed data pipelines, and low-latency cloud infrastructure, I enjoy solving hard engineering challenges where correctness and performance truly matter.`;
        }

        // Topic 5: General Fallback
        return (profile.professionalSummary && profile.professionalSummary.length > 20)
          ? profile.professionalSummary
          : "I am a dedicated Software Developer with deep experience building scalable cloud applications, resilient API microservices, and high-performance data systems. I bring a strong work ethic, technical curiosity, and collaborative mindset to ship reliable software.";
      }
      default: return null;
    }
  }

  /* -- HUD ORCHESTRATOR (delegates to AstrePilotHUD Shadow DOM module) -- */
  async function toggleAstrePilotHUD() {
    // Only top-level window mounts and controls the HUD UI
    if (window !== window.top) return;

    // Guard: wait for hud-ui.js to initialize (loads before content.js per manifest order)
    if (typeof window.AstrePilotHUD === 'undefined') {
      await new Promise(r => setTimeout(r, 200));
      if (typeof window.AstrePilotHUD === 'undefined') {
        console.warn('[AstrePilot] hud-ui.js failed to load.');
        return;
      }
    }
    // A mount is in flight: ignore extra toggles (prevents duplicate HUDs)
    if (mountPromise) return mountPromise;

    // If HUD is already open -> toggle collapse
    if (activeHud) {
      if (activeHud.isCollapsed) { activeHud.expand(); } else { activeHud.collapse(); }
      return;
    }

    mountPromise = mountHud().finally(() => { mountPromise = null; });
    return mountPromise;
  }

  async function mountHud() {
    const config = await getStoredConfig();
    const activeCtx = config.activeContext || 'roushan';
    let isOffline = !config.token;

    // Mount HUD immediately in connecting state so user gets visual feedback
    activeHud = AstrePilotHUD.mount({
      onAutofill: runAutofill,
      onNextStep: runContinueNextStep,
      onUndo: runUndo,
      onExtract: runExtract,
      onExtractJD: runExtractJD,
      onDownloadResume: runDownloadResume,
      onSyncHarvester: runSyncHarvester,
      onRescan: rescanFields,
      onLogout: async () => {
        try {
          userProfile = null;
          activeSession = null;
          if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
            await chrome.storage.sync.remove(['astrepilot_token', 'astrepilot_active_context', 'astrepilot_candidate_slug']);
          }
          if (activeHud) {
            activeHud.setIdentity(null);
            rescanFields();
          }
        } catch (e) {
          console.warn('[AstrePilot] Logout error:', e);
        }
      },
      onLogin: async (token, profile) => {
        try {
          userProfile = profile;
          if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
            await chrome.storage.sync.set({
              astrepilot_token: token,
              astrepilot_active_context: profile.slug,
              astrepilot_candidate_slug: profile.slug
            });
          }
          if (activeHud) {
            activeHud.setIdentity({
              fullName: profile.fullName || ((profile.firstName || '') + ' ' + (profile.lastName || '')).trim() || 'Candidate',
              title: profile.title || 'Full-Stack Developer',
              primedCompany: activeSession ? activeSession.company : null
            });
            rescanFields();
          }
        } catch (e) {
          console.warn('[AstrePilot] Login handler error:', e);
        }
      },
      onSwitchOrigin: async (origin) => {
        try {
          if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
            await chrome.storage.sync.set({ astrepilot_origin: origin });
          }
          const sRes = await apFetch('/session');
          if (sRes.ok) {
            const sData = await sRes.json();
            activeSession = sData.session;
          }
          const pRes = await apFetch('/profile');
          if (pRes.ok) {
            const pData = await pRes.json();
            if (pData.success && pData.profile) {
              userProfile = pData.profile;
            }
          }
          rescanFields();
        } catch (e) {
          console.warn('[AstrePilot] Origin switch error:', e);
        }
      },
      onLoginAdvance: () => {
        const loginBtn = findNextStepButton(document) || document.querySelector('input[type="submit"], button[type="submit"], button');
        if (activeHud) {
          activeHud.setState('transitioning', { step: 'Signing in & loading application form...' });
          if (loginBtn) {
            try {
              loginBtn.focus();
              loginBtn.click();
            } catch (e) {
              try { loginBtn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true })); } catch (err) {}
            }
          }
          watchForStepTransition(() => {
            rescanFields();
          });
        }
      },
      onReapply: () => {
        if (activeHud) activeHud.duplicateAlert = null;
        rescanFields();
      },
      onForceLockTakeover: async () => {
        await acquireFillLock(true);
        if (activeHud) activeHud.clearRemoteLock();
        runAutofill();
      },
      onSaveToVault: async (fieldId, btnEl) => {
        const f = detectedFields && detectedFields.find(x => x.id === fieldId);
        if (!f || !f.element) return;
        const question = (getLabelText(f.element) || '').slice(0, 300) || 'Custom Screening Question';
        const answerText = f.element.value || f.preview || '';
        if (!answerText.trim() || answerText.length < 5) return;

        if (btnEl) {
          btnEl.textContent = 'Saving…';
          btnEl.disabled = true;
        }

        try {
          const res = await apFetch('/vault', {
            method: 'POST',
            body: JSON.stringify({
              questionPattern: question,
              answerText: answerText,
              companyContext: activeSession && activeSession.company ? activeSession.company : document.title.replace(/ \|.*/, '').trim(),
              roleContext: activeSession && activeSession.jobTitle ? activeSession.jobTitle : '',
              isFavorite: true,
            }),
          });
          if (res.ok) {
            if (btnEl) {
              btnEl.textContent = '✓ Saved!';
              btnEl.style.color = '#059669';
              btnEl.style.borderColor = 'rgba(5, 150, 105, 0.3)';
              btnEl.style.background = 'rgba(5, 150, 105, 0.1)';
            }
            f.source = 'vault';
            if (activeHud) activeHud.updateField(f);
            broadcastSync({
              type: 'VAULT_ENTRY_SAVED',
              timestamp: Date.now(),
              payload: { questionPattern: question }
            });
          } else {
            if (btnEl) {
              btnEl.textContent = 'Save Failed';
              btnEl.disabled = false;
            }
          }
        } catch (err) {
          if (btnEl) {
            btnEl.textContent = 'Save Failed';
            btnEl.disabled = false;
          }
        }
      },
      onConfirmSubmit: async (meta) => {
        try {
          await apFetch('/confirm', {
            method: 'POST',
            body: JSON.stringify({
              fillId: meta && meta.fillId,
              applicationId: meta && meta.applicationId,
              siteUrl: window.location.href,
            }),
          });
          if (activeHud) {
            activeHud.setState('done', { ...meta, isConfirmed: true });
            setTimeout(() => {
              if (activeHud && !activeHud.isCollapsed) activeHud.collapse();
            }, 3500);
          }
          broadcastSync({
            type: 'APPLICATION_CONFIRMED',
            timestamp: Date.now(),
            payload: {
              fillId: meta && meta.fillId,
              applicationId: meta && meta.applicationId,
              siteUrl: window.location.href,
              company: (activeSession && activeSession.company) || ''
            }
          });
        } catch (e) {
          console.error('[AstrePilot] Confirm failed', e);
        }
      },
      onClose: () => {
        if (detectedFields) {
          detectedFields.forEach(f => f.element.classList.remove('ap-field-active', 'ap-field-done'));
        }
        activeHud = null;
      }
    });
    activeHud.setState('connecting');

    if (!config.token) {
      isOffline = true;
      userProfile = (config.activeContext && STANDALONE_PROFILES[config.activeContext]) ? STANDALONE_PROFILES[config.activeContext] : STANDALONE_PROFILES.roushan;
    } else {
      try {
        const profileRes = await apFetch(`/profile${activeCtx ? `?slug=${encodeURIComponent(activeCtx)}` : ''}`);
        if (profileRes.ok) {
          const rawProfile = await profileRes.json();
          if (isValidProfile(rawProfile)) {
            userProfile = rawProfile;
          }
        }
        if (userProfile && activeCtx && userProfile.slug && userProfile.slug !== activeCtx) {
          userProfile = STANDALONE_PROFILES[activeCtx] || userProfile;
        }

        const sessionRes = await apFetch('/session');
        if (sessionRes.ok) {
          const sData = await sessionRes.json();
          activeSession = sData.session;
        }
      } catch (err) {
        // Fallback to standalone offline profile if cloud un-paired or server down
        isOffline = true;
      }
    }

    if (!isValidProfile(userProfile)) {
      isOffline = true;
      userProfile = (activeCtx && STANDALONE_PROFILES[activeCtx])
        ? STANDALONE_PROFILES[activeCtx]
        : ((config.activeContext && STANDALONE_PROFILES[config.activeContext]) ? STANDALONE_PROFILES[config.activeContext] : STANDALONE_PROFILES.roushan);
    }

    if (!activeHud) return; // user closed the HUD while loading

    if (userProfile) {
      activeHud.setIdentity({
        fullName: userProfile.fullName || ((userProfile.firstName || '') + ' ' + (userProfile.lastName || '')).trim() || 'Roushan Kumar',
        title: userProfile.title || 'Software Developer — Backend & Cloud',
        primedCompany: activeSession ? activeSession.company : null
      });
    } else {
      activeHud.setIdentity(null);
    }

    if (!isOffline) {
      // Pillar E: Duplicate Application Pre-Flight Status Check (Cloud Only)
      try {
        const checkRes = await apFetch('/check-status', {
          method: 'POST',
          body: JSON.stringify({
            siteUrl: window.location.href,
            company: (activeSession && activeSession.company) || document.title.replace(/ \|.*/, '').trim().slice(0, 80),
            jobTitle: (activeSession && activeSession.jobTitle) || ''
          })
        });
        if (checkRes.ok) {
          const checkData = await checkRes.json();
          if (checkData && checkData.exists && checkData.application) {
            if (activeHud) activeHud.setDuplicateAlert(checkData.application);
          }
        }
      } catch (checkErr) {
        /* silent */
      }
    }

    activeHud.setState('scanning');

    // Check for catalog jobs (Wellfound / Jobright)
    const catalogData = extractCatalogJobs();
    if (catalogData && activeHud.setHarvester) {
      activeHud.setHarvester({
        source: catalogData.source,
        count: catalogData.jobs.length,
        jobs: catalogData.jobs,
        synced: false
      });
    }

    applyDetectedFields(scanFields(), catalogData);
  }

  function applyDetectedFields(fields, catalogData) {
    if (!activeHud) return;
    detectedFields = fields || [];

    const CORE_APPLICATION_TYPES = new Set([
      'FIRST_NAME', 'LAST_NAME', 'FULL_NAME', 'EMAIL', 'PHONE', 'RESUME', 'COVER_LETTER',
      'WORK_AUTH', 'VISA', 'SCREENING', 'SCREENING_SELECT', 'WORK_DESCRIPTION',
      'COMPANY', 'SCHOOL', 'PASSWORD', 'CONFIRM_PASSWORD', 'LOGIN_ID',
      'PREFERRED_NAME', 'EMPLOYMENT_TITLE', 'EXP_STATE', 'NOTE', 'STARTUP_PITCH', 'WHY_US'
    ]);
    const hasCoreAppField = detectedFields.some(f => CORE_APPLICATION_TYPES.has(f.type));

    // If there are no core application fields and only 1-2 generic inputs (like location/zip from search widget),
    // this is a Job Description page, NOT an active application form.
    if (!hasCoreAppField && detectedFields.length <= 2) {
      detectedFields = [];
    }

    if (detectedFields.length === 0) {
      const cat = catalogData || extractCatalogJobs();
      if (cat && cat.jobs.length > 0) {
        activeHud.setState('catalog');
      } else {
        activeHud.setState('no-fields', { isJobOverview: true });
      }
      return;
    }

    const hudFields = detectedFields.map(f => {
      const isAI = f.type === 'COVER_LETTER' || f.type === 'SCREENING';
      const isSession = (f.type === 'TITLE' || f.type === 'SUMMARY' || f.type === 'SALARY') && !!activeSession;
      const preview = resolvePreview(f, userProfile, activeSession);
      return {
        id: f.id,
        type: f.type.toLowerCase().replace(/_/g, ''),
        label: TYPE_LABELS[f.type] || f.type,
        preview: preview || (isAI ? 'AI-generated on fill' : '-'),
        source: preview ? (isAI ? 'profile' : (isSession ? 'session' : 'profile')) : (isAI ? 'ai' : (isSession ? 'session' : 'profile')),
        status: ''
      };
    });

    activeHud.setFields(hudFields);
    activeHud.setProgress(0, detectedFields.length);
    activeHud.setState('ready');

    // Classify step and display step badge
    const curSession = getNavSession() || createDefaultNavSession(window.location.href, activeSession ? activeSession.company : '', activeSession ? activeSession.jobTitle : '');
    const stepIndicators = Array.from(document.querySelectorAll('[data-automation-id*="step"], ol.steps, ul.progress, [aria-current="step"], .progress-bar, h1, h2, legend'))
      .map(e => e.innerText || e.textContent || '').join(' ');
    const stepInfo = classifyCurrentStep(window.location.href, stepIndicators, detectedFields.map(f => f.type));
    curSession.stepCategory = stepInfo.category;
    curSession.stepName = stepInfo.label;
    saveNavSession(curSession);

    if (activeHud.setStepBadge) {
      activeHud.setStepBadge({
        stepIndex: curSession.currentStepIndex,
        stepName: curSession.stepName
      });
    }

    // Attach live input listeners to textareas to reflect edits in HUD
    detectedFields.forEach(f => {
      if ((f.type === 'SCREENING' || f.type === 'COVER_LETTER') && f.element) {
        if (f.element.value && (!f.preview || f.preview === '-')) {
          f.preview = f.element.value;
        }
        f.element.addEventListener('input', () => {
          f.preview = f.element.value;
          if (activeHud) {
            activeHud.updateField({
              id: f.id,
              type: f.type.toLowerCase().replace(/_/g, ''),
              label: TYPE_LABELS[f.type] || f.type,
              preview: f.element.value,
              source: f.source || 'profile',
            });
          }
        });
      }
    });
  }

  function rescanFields() {
    if (!activeHud || isFilling) return;
    const fields = scanFields();
    applyDetectedFields(fields);
    if (activeHud && typeof activeHud.showToast === 'function') {
      activeHud.showToast(`✓ ${fields.length} fields verified`);
    }
  }

  async function runAutofill() {
    if (!activeHud) {
      await toggleAstrePilotHUD();
    }
    const hud = activeHud;
    if (!hud || isFilling) return;

    if (!isValidProfile(userProfile)) {
      const config = await getStoredConfig();
      userProfile = (config.activeContext && STANDALONE_PROFILES[config.activeContext])
        ? STANDALONE_PROFILES[config.activeContext]
        : STANDALONE_PROFILES.roushan;
    }

    if (!detectedFields || !detectedFields.length) {
      const fields = scanFields();
      applyDetectedFields(fields);
      if (!detectedFields || !detectedFields.length) return;
    }

    // CAPTCHA Sentinel: if a bot verification challenge is active, pause gracefully
    if (detectCaptchaChallenge([document])) {
      hud.setState('review_ready', {
        warning: '🛡️ Human Verification Detected: Please solve the CAPTCHA challenge above. AstrePilot will resume automatically once solved.'
      });
      return;
    }

    // Cross-Origin Subframe Delegation: ONLY if top window has NO detectable fields of its own AND an active child frame was detected
    if (childFrameSource && (!detectedFields || detectedFields.length === 0)) {
      hud.setState('filling');
      childFrameSource.postMessage({
        type: 'ASTREPILOT_CHILD_TRIGGER_AUTOFILL',
        profile: userProfile,
        session: activeSession
      }, '*');
      return;
    }

    if (!detectedFields || !detectedFields.length) return;

    // Pillar E: Concurrency Lock Check
    const lockRes = await acquireFillLock(false);
    if (!lockRes.success && lockRes.lock) {
      hud.setRemoteLock(lockRes.lock);
      return;
    }

    isFilling = true;
    startFillHeartbeat();
    try {
      broadcastSync({
        type: 'FILL_LOCK_ACQUIRED',
        timestamp: Date.now(),
        payload: { url: window.location.href, company: activeSession ? activeSession.company : '' }
      });
      await fillAllFields(hud);
    } catch (fillErr) {
      console.error('[AstrePilot] Autofill fatal execution error:', fillErr);
      if (hud && typeof hud.setState === 'function') {
        hud.setState('error', { msg: 'Autofill error: ' + (fillErr.message || 'Execution interrupted') });
      }
    } finally {
      isFilling = false;
      releaseFillLock();
    }
  }

  async function runExtractJD() {
    const hud = activeHud;
    if (!hud) return;
    
    hud.setState('extracting', { step: 'Reading page content...' });
    try {
      const data = extractPageContent();
      const safeText = data.pageText.slice(0, 30000);
      
      hud.setState('extracting', { step: 'Analyzing job requirements...' });
      const res = await apFetch('/extract', {
        method: 'POST',
        body: JSON.stringify({ pageText: safeText, pageUrl: data.pageUrl, pageTitle: data.pageTitle, recruiter: data.recruiter })
      });
      
      if (res.ok) {
        const extracted = await res.json();
        if (extracted.success) {
           if (extracted.astraShield && hud.setAstraShield) {
             hud.setAstraShield(extracted.astraShield);
           }
           if (extracted.recruiter && hud.setRecruiter) {
             hud.setRecruiter(extracted.recruiter);
           }
           hud.setState('extracting', { step: 'Finalizing Extraction...' });
           setTimeout(async () => {
             if (activeHud === hud) {
               try {
                 const sessionRes = await apFetch('/session');
                 if (sessionRes.ok) {
                   const sData = await sessionRes.json();
                   activeSession = sData.session;
                   if (userProfile) {
                     activeHud.setIdentity({
                       fullName: userProfile.fullName || ((userProfile.firstName || '') + ' ' + (userProfile.lastName || '')).trim() || 'You',
                       title: userProfile.title || 'Candidate',
                       primedCompany: activeSession ? activeSession.company : null
                     });
                   }
                 }
               } catch (e) {}

               // Re-scan fields dynamically on the page with newly primed session
               const fields = scanFields();
               applyDetectedFields(fields);
               activeHud.expand();
             }
           }, 800);
           return;
        } else {
           hud.setState('error', { msg: extracted.error || 'Failed to extract data.' });
           return;
        }
      } else {
        const errData = await res.json().catch(() => ({}));
        hud.setState('error', { msg: errData.error || ('Server error: ' + res.status) });
        return;
      }
    } catch (e) {
      console.error('[AstrePilot] Extract JD failed:', e);
      hud.setState('error', { msg: e.message || 'Network error occurred.' });
    }
  }

  function triggerClientDownload(blob, filename) {
    const blobUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename;
    link.style.display = 'none';
    (document.body || document.documentElement).appendChild(link);
    link.click();
    setTimeout(() => {
      try { link.remove(); } catch (e) {}
      URL.revokeObjectURL(blobUrl);
    }, 5000);
  }

  async function runDownloadResume() {
    const hud = activeHud;
    if (hud) hud.setState('filling', { step: 'Downloading tailored resume PDF...' });

    const activeCtx = userProfile ? (userProfile.slug || 'roushan') : 'roushan';

    try {
      // 1. Fetch tailored PDF binary from background
      const data = await getResumeBinaryFromBackground();

      if (data && data.success && data.base64) {
        const fallbackName = (activeCtx === 'ayushi' || (userProfile && userProfile.slug === 'ayushi'))
          ? 'Ayushi_Raj_resume.pdf'
          : 'Roushan_Kumar_resume.pdf';
        const filename = data.filename || fallbackName;
        const mimeType = data.mimeType || 'application/pdf';
        const blob = base64ToBlob(data.base64, mimeType);

        // 2. Direct browser download to candidate's local Downloads folder
        triggerClientDownload(blob, filename);

        // 3. Secondary convenience: also attach to page upload target if present
        const resumeFields = (detectedFields || []).filter(f => f.type === 'RESUME');
        let targetEl = resumeFields.length > 0 ? resumeFields[0].element : null;
        if (!targetEl) {
          targetEl = document.querySelector('input[type="file"], [class*="dropzone"], [data-automation-id*="upload"], button[aria-label*="resume" i], [aria-label*="upload" i]');
        }

        if (targetEl) {
          try {
            const file = new File([blob], filename, { type: mimeType, lastModified: Date.now() });
            const dt = new DataTransfer();
            dt.items.add(file);
            let fileInput = targetEl.tagName === 'INPUT' && targetEl.type === 'file'
              ? targetEl
              : targetEl.querySelector('input[type="file"]') || document.querySelector('input[type="file"]');
            if (fileInput) {
              try {
                const proto = window.HTMLInputElement.prototype;
                const descriptor = Object.getOwnPropertyDescriptor(proto, 'files');
                if (descriptor && descriptor.set) {
                  descriptor.set.call(fileInput, dt.files);
                } else {
                  fileInput.files = dt.files;
                }
              } catch (filesErr) {
                try { fileInput.files = dt.files; } catch (e) {}
              }
              fileInput.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
              fileInput.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
            }
          } catch (attachErr) {}
          if (hud && resumeFields[0]) {
            hud.markRow(resumeFields[0].id, 'done', filename);
          }
        }

        if (hud) {
          hud.setState('ready');
        }
        return;
      }

      // Fallback: request background to trigger download via chrome.downloads or tab
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ type: 'DOWNLOAD_RESUME', activeContext: activeCtx });
      }
      if (hud) {
        hud.setState('ready');
      }
    } catch (err) {
      console.warn('[AstrePilot] Direct resume download error, falling back to background:', err);
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ type: 'DOWNLOAD_RESUME', activeContext: activeCtx });
      }
      if (hud) {
        hud.setState('ready');
      }
    }
  }

  async function runSyncHarvester() {
    const hud = activeHud;
    if (!hud) return;
    const data = extractCatalogJobs();
    const jobs = (data && data.jobs && data.jobs.length) ? data.jobs : (hud.harvester && hud.harvester.jobs);
    const source = (data && data.source) || (hud.harvester && hud.harvester.source) || 'WELLFOUND';
    if (!jobs || !jobs.length) {
      hud.setState('error', { msg: 'No roles found to sync.' });
      return;
    }

    hud.setState('extracting', { step: `Syncing ${jobs.length} ${source} roles...` });
    try {
      const res = await apFetch('/api/jobs/import', {
        method: 'POST',
        body: JSON.stringify({ source: source, jobs: jobs })
      });
      const result = await res.json().catch(() => null);
      if (result && result.success) {
        if (hud.setHarvester) {
          hud.setHarvester({
            source: source,
            count: jobs.length,
            jobs: jobs,
            synced: true,
            inserted: result.inserted || 0,
            updated: result.updated || 0,
          });
        }
        hud.setState('catalog');
      } else {
        hud.setState('error', { msg: (result && result.error) || 'Failed to sync roles.' });
      }
    } catch (e) {
      hud.setState('error', { msg: e.message || 'Sync failed.' });
    }
  }

  async function runExtract() {
    const hud = activeHud;
    if (!hud) return;
    
    hud.setState('extracting', { step: 'Reading page content...' });
    try {
      const data = extractPageContent();
      const safeText = data.pageText.slice(0, 30000);
      
      hud.setState('extracting', { step: 'Analyzing job requirements...' });
      const res = await apFetch('/extract', {
        method: 'POST',
        body: JSON.stringify({ pageText: safeText, pageUrl: data.pageUrl, pageTitle: data.pageTitle, recruiter: data.recruiter })
      });
      
      if (res.ok) {
        const extracted = await res.json();
        if (extracted.success) {
           if (extracted.astraShield && hud.setAstraShield) {
             hud.setAstraShield(extracted.astraShield);
           }
           if (extracted.recruiter && hud.setRecruiter) {
             hud.setRecruiter(extracted.recruiter);
           }

           try {
             const sessionRes = await apFetch('/session');
             if (sessionRes.ok) {
               const sData = await sessionRes.json();
               activeSession = sData.session;
               if (userProfile && activeHud) {
                 activeHud.setIdentity({
                   fullName: userProfile.fullName || ((userProfile.firstName || '') + ' ' + (userProfile.lastName || '')).trim() || 'You',
                   title: userProfile.title || 'Candidate',
                   primedCompany: activeSession ? activeSession.company : null
                 });
               }
             }
           } catch (e) {}

           hud.setState('extracting', { step: 'Locating Apply button...' });
           setTimeout(() => {
             const success = findAndClickApplyButton();
             if (activeHud === hud) {
               if (success) {
                 try { sessionStorage.setItem('ap_auto_open', 'true'); } catch (e) {}
                 hud.setState('transitioning', { step: 'Navigating to application form...' });
               } else {
                 // Already on application form or no apply button found; scan fields
                 const fields = scanFields();
                 applyDetectedFields(fields);
                 activeHud.expand();
               }
             }
           }, 1000);
           return;
        } else {
           hud.setState('error', { msg: extracted.error || 'Failed to extract data.' });
           return;
        }
      } else {
        const errData = await res.json().catch(() => ({}));
        hud.setState('error', { msg: errData.error || ('Server error: ' + res.status) });
        return;
      }
    } catch (e) {
      console.error('[AstrePilot] Extraction failed:', e);
      hud.setState('error', { msg: e.message || 'Network error occurred.' });
    }
  }

  /* -- PROOF-OF-WRITE AUDITOR -- */
  async function verifyFieldWritten(field, expectedVal) {
    if (!field || !field.element) return false;
    const el = field.element;
    const expStr = String(expectedVal).trim().toLowerCase();

    // Settle tick for React/Vue synthetic event commitments
    await new Promise(r => setTimeout(r, 60));

    // 1. Native Select
    if (el.tagName === 'SELECT') {
      if (el.selectedIndex < 0) return false;
      const opt = el.options[el.selectedIndex];
      if (!opt) return false;
      const optText = (opt.textContent || opt.text || '').trim().toLowerCase();
      const optVal = (opt.value || '').trim().toLowerCase();
      return !PLACEHOLDER_REGEX.test(optText) && (optVal !== '' && optVal !== '0');
    }

    // 2. Custom ARIA Combobox / React-Select (Strict Anti-False-Positive Firewall)
    if (isComboboxOrSelect(el)) {
      const container = (el.closest && el.closest('.select-shell, .select__container, [class*="react-select"], .select, .form-group')) || el.parentElement;
      if (container) {
        const single = container.querySelector('.select__single-value, [class*="singleValue"], .select__multi-value__label, [class*="multiValue"]');
        if (single && single.textContent.trim().length > 0 && !PLACEHOLDER_REGEX.test(single.textContent.trim())) return true;
        const req = container.querySelector('input[class*="requiredInput"], input[type="hidden"][name]');
        if (req && req.value && req.value.trim().length > 0 && !PLACEHOLDER_REGEX.test(req.value.trim()) && req.value.trim() !== '0') return true;
      }
      // For button/div-based comboboxes (Radix/Headless UI/Workday promptOption)
      if (el.tagName !== 'INPUT') {
        const text = (el.innerText || el.textContent || '').trim().toLowerCase();
        const ariaVal = (el.getAttribute('aria-valuenow') || el.getAttribute('aria-label') || '').toLowerCase();
        if (text && !PLACEHOLDER_REGEX.test(text) && text.length > 0) return true;
        if (ariaVal && ariaVal.length > 0 && !PLACEHOLDER_REGEX.test(ariaVal)) return true;
      }
      return false;
    }

    // 3. Radio / Checkbox
    if (el.tagName === 'INPUT' && (el.type === 'radio' || el.type === 'checkbox')) {
      if (el.type === 'radio') {
        const ownerDoc = el.ownerDocument || document;
        const radios = el.name
          ? ownerDoc.querySelectorAll('input[type="radio"][name="' + CSS.escape(el.name) + '"]')
          : [el];
        for (let r of radios) {
          if (r.checked) return true;
        }
        return false;
      }
      return el.checked === (expStr === 'yes' || expStr === 'true' || expStr === '1');
    }

    // 4. Text, Password, Textarea
    const currentVal = (el.value || '').trim();
    if (currentVal.length === 0) return false;

    if (field.type === 'PASSWORD' || field.type === 'CONFIRM_PASSWORD' || el.type === 'password') {
      return currentVal.length >= 6;
    }

    const curLower = currentVal.toLowerCase();
    if (curLower === expStr) return true;
    if (expStr.startsWith(curLower) || curLower.startsWith(expStr.slice(0, 5))) return true;

    const expDigits = expStr.replace(/\D/g, '');
    const curDigits = curLower.replace(/\D/g, '');
    if (expDigits.length > 0 && (curDigits.includes(expDigits) || expDigits.includes(curDigits))) {
      return true;
    }

    return currentVal.length > 0;
  }

  /* -- ASTREPILOT V3 SELF-HEALING UNIVERSAL WRITE ACTUATOR -- */
  async function universalWriteActuator(el, value, field = null) {
    if (!el || value === undefined || value === null) return { success: false, strategyUsed: 0 };
    const valStr = String(value);
    const fieldType = (field && field.type) || '';

    // Handle Radio & Checkbox
    if (el.tagName === 'INPUT' && (el.type === 'radio' || el.type === 'checkbox')) {
      setNativeValue(el, value, true, fieldType);
      const verified = await verifyFieldWritten(field || { element: el, type: fieldType }, value);
      return { success: verified, strategyUsed: 1 };
    }

    // Tier 1: Native Property Setter & React ValueTracker Reset (0ms)
    setNativeValue(el, valStr, true, fieldType);
    if (await verifyFieldWritten(field || { element: el, type: fieldType }, valStr)) {
      return { success: true, strategyUsed: 1 };
    }

    // Settle delay before Tier 2
    await new Promise(r => setTimeout(r, 40));

    // Tier 2: Focus + Selection + document.execCommand('insertText')
    try {
      if (typeof el.focus === 'function') el.focus();
      if (typeof el.select === 'function') {
        try { el.select(); } catch (e) {}
      } else if (typeof el.setSelectionRange === 'function') {
        try { el.setSelectionRange(0, el.value ? el.value.length : 0); } catch (e) {}
      }

      const doc = el.ownerDocument || document;
      let inserted = false;
      if (typeof doc.execCommand === 'function') {
        inserted = doc.execCommand('insertText', false, valStr);
      }

      if (inserted) {
        try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) {}
        try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {}
        if (await verifyFieldWritten(field || { element: el, type: fieldType }, valStr)) {
          return { success: true, strategyUsed: 2 };
        }
      }
    } catch (s2Err) {}

    // Settle delay before Tier 3
    await new Promise(r => setTimeout(r, 40));

    // Tier 3: Synthetic ClipboardEvent('paste')
    try {
      if (typeof el.focus === 'function') el.focus();
      if (typeof el.select === 'function') {
        try { el.select(); } catch (e) {}
      }

      let pasteDispatched = false;
      try {
        if (typeof ClipboardEvent !== 'undefined' && typeof DataTransfer !== 'undefined') {
          const dt = new DataTransfer();
          dt.setData('text/plain', valStr);
          const pasteEvent = new ClipboardEvent('paste', {
            bubbles: true,
            cancelable: true,
            clipboardData: dt,
          });
          el.dispatchEvent(pasteEvent);
          pasteDispatched = true;
        }
      } catch (e) {}

      if (!pasteDispatched && typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.writeText) {
        try {
          await navigator.clipboard.writeText(valStr);
          const doc = el.ownerDocument || document;
          if (doc && typeof doc.execCommand === 'function') {
            doc.execCommand('paste');
          }
        } catch (clipErr) {}
      }

      try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) {}
      try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {}
      if (await verifyFieldWritten(field || { element: el, type: fieldType }, valStr)) {
        return { success: true, strategyUsed: 3 };
      }
    } catch (s3Err) {}

    // Settle delay before Tier 4
    await new Promise(r => setTimeout(r, 40));

    // Tier 4: Granular Char-by-Char Synthetic KeyboardEvent Cascade
    try {
      if (typeof el.focus === 'function') el.focus();
      if (typeof el.select === 'function') {
        try { el.select(); } catch (e) {}
      }

      let accum = '';
      for (let i = 0; i < valStr.length; i++) {
        const char = valStr[i];
        accum += char;
        const keyCode = char.charCodeAt(0);

        try {
          el.dispatchEvent(new KeyboardEvent('keydown', { key: char, code: 'Key' + char.toUpperCase(), keyCode, which: keyCode, bubbles: true }));
          el.dispatchEvent(new KeyboardEvent('keypress', { key: char, code: 'Key' + char.toUpperCase(), keyCode, which: keyCode, bubbles: true }));
        } catch (e) {}

        try {
          el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: char }));
        } catch (e) {}

        try {
          const proto = Object.getPrototypeOf(el);
          const setter = Object.getOwnPropertyDescriptor(proto, 'value');
          if (setter && setter.set) {
            setter.set.call(el, accum);
          } else {
            el.value = accum;
          }
        } catch (e) {
          el.value = accum;
        }

        try {
          el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: char }));
          el.dispatchEvent(new KeyboardEvent('keyup', { key: char, code: 'Key' + char.toUpperCase(), keyCode, which: keyCode, bubbles: true }));
        } catch (e) {}
      }

      try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {}
      try { el.dispatchEvent(new Event('blur', { bubbles: true })); } catch (e) {}

      const verified = await verifyFieldWritten(field || { element: el, type: fieldType }, valStr);
      return { success: verified, strategyUsed: 4 };
    } catch (s4Err) {
      return { success: false, strategyUsed: 4 };
    }
  }

  async function fillAllFields(hud) {
    hud.setState('filling');
    let filled = 0;
    let hadAI = false;

    for (let i = 0; i < detectedFields.length; i++) {
      if (activeHud !== hud) return; // HUD was closed/replaced mid-run
      const f = detectedFields[i];
      try {
        hud.markRow(f.id, 'active');

        if (f.type === 'COVER_LETTER' || f.type === 'SCREENING') hadAI = true;

        // Allow dependent dropdowns (e.g. State depending on Country) time to populate options
        if (f.type === 'STATE') {
          let waited = 0;
          while (waited < 1200) {
            const isReady = f.element.tagName === 'SELECT'
              ? f.element.options.length > 1 && !f.element.disabled
              : !f.element.disabled && f.element.getAttribute('aria-disabled') !== 'true';
            if (isReady) break;
            await new Promise(r => setTimeout(r, 100));
            waited += 100;
          }
        }

        const val = await resolveValue(f, userProfile, activeSession);
        const skipped = !val || String(val).trim() === '';

        if (!skipped) {
          let writeSuccess = false;
          const confTier = (f.confidence != null && f.confidence < 0.85) ? 'review' : 'active';
          if (f.type === 'RESUME') {
            AstrePilotHUD.highlight(f.element, confTier);
            const uploadRes = await injectResumeFile(f.element);
            if (uploadRes && uploadRes.success) {
              filled++;
              hud.markRow(f.id, 'done', uploadRes.filename || 'Uploaded');
            } else {
              hud.markRow(f.id, 'skipped', 'Upload manually');
            }
          } else if (f.type === 'COVER_LETTER' && f.element.tagName === 'INPUT' && f.element.type === 'file') {
            AstrePilotHUD.highlight(f.element, confTier);
            const uploadRes = await injectCoverLetterFile(f.element);
            if (uploadRes && uploadRes.success) {
              filled++;
              hud.markRow(f.id, 'done', uploadRes.filename || 'Uploaded');
            } else {
              hud.markRow(f.id, 'skipped', 'Upload failed');
            }
          } else if (isComboboxOrSelect(f.element)) {
            AstrePilotHUD.highlight(f.element, confTier);
            const cbSuccess = await fillUniversalCombobox(f.element, val, f.type);
            writeSuccess = cbSuccess || await verifyFieldWritten(f, val);
            if (writeSuccess) {
              filled++;
              hud.markRow(f.id, 'done', String(val).slice(0, 30));
            } else {
              hud.markRow(f.id, 'retry', '⚠ Retry Verification');
            }
          } else if (f.type === 'ZIP' || f.type === 'ZIP_CODE' || (f.element.tagName === 'INPUT' && (f.element.type === 'radio' || f.element.type === 'checkbox'))) {
            const uRes = await universalWriteActuator(f.element, val, f);
            writeSuccess = uRes.success;
            if (writeSuccess) {
              filled++;
              hud.markRow(f.id, 'done', String(val).slice(0, 30));
            } else {
              hud.markRow(f.id, 'retry', '⚠ Retry Verification');
            }
          } else {
            AstrePilotHUD.highlight(f.element, confTier);
            await AstrePilotHUD.fillAnimated(f.element, String(val), (el, v, isFinal) => setNativeValue(el, v, isFinal));
            // 4-Strategy Self-Healing Actuator
            const uRes = await universalWriteActuator(f.element, val, f);
            writeSuccess = uRes.success;
            if (writeSuccess) {
              filled++;
              const displayVal = (f.type === 'PASSWORD' || f.type === 'CONFIRM_PASSWORD') ? '••••••••' : String(val).slice(0, 30);
              hud.markRow(f.id, 'done', displayVal);
            } else {
              hud.markRow(f.id, 'retry', '⚠ Retry Verification');
              if (lastFormFingerprint) {
                try {
                  apFetch('/schema-cache', {
                    method: 'POST',
                    body: JSON.stringify({
                      fingerprint: lastFormFingerprint,
                      feedback: { success: false, failedField: f.id, fieldType: f.type }
                    })
                  }).catch(() => {});
                } catch (e) {}
              }
            }
          }
        } else {
          hud.markRow(f.id, 'skipped', '-');
        }
      } catch (fieldErr) {
        console.warn('[AstrePilot] Field fill error on', f ? f.id : 'unknown', fieldErr);
        if (f && f.id) hud.markRow(f.id, 'retry', '⚠ Error');
      }
      hud.setProgress(filled, detectedFields.length);
      await new Promise(r => setTimeout(r, 80));
    }

    // Autonomous Pass 2: Dynamic Dependent Field Discovery (e.g. Race appearing after Hispanic/Latino is answered)
    await new Promise(r => setTimeout(r, 600));
    try {
      const freshFields = scanFields();
      const newlyAppearedFields = freshFields.filter(nf => {
        if (!nf || !nf.element) return false;
        return !detectedFields.some(df => df.element === nf.element || (df.id && nf.id && df.id === nf.id));
      });

      if (newlyAppearedFields.length > 0) {
        console.log(`[AstrePilot] Detected ${newlyAppearedFields.length} dynamically mounted dependent fields. Commencing Pass 2...`);
        for (const nf of newlyAppearedFields) {
          if (activeHud !== hud) return;
          detectedFields.push(nf);
          hud.markRow(nf.id, 'active');

          const val = await resolveValue(nf, userProfile, activeSession);
          if (val && String(val).trim().length > 0) {
            let pass2Success = false;
            const confTier = (nf.confidence != null && nf.confidence < 0.85) ? 'review' : 'active';
            if (isComboboxOrSelect(nf.element)) {
              AstrePilotHUD.highlight(nf.element, confTier);
              const cbSuccess = await fillUniversalCombobox(nf.element, val, nf.type);
              pass2Success = cbSuccess || await verifyFieldWritten(nf, val);
            } else {
              AstrePilotHUD.highlight(nf.element, confTier);
              await AstrePilotHUD.fillAnimated(nf.element, String(val), (el, v, isFinal) => setNativeValue(el, v, isFinal));
              const uRes = await universalWriteActuator(nf.element, val, nf);
              pass2Success = uRes.success;
            }

            if (pass2Success) {
              filled++;
              hud.markRow(nf.id, 'done', String(val).slice(0, 30));
            } else {
              hud.markRow(nf.id, 'retry', '⚠ Retry Verification');
            }
          } else {
            hud.markRow(nf.id, 'skipped', '-');
          }
          hud.setProgress(filled, detectedFields.length);
          await new Promise(r => setTimeout(r, 80));
        }
      }
    } catch (pass2Err) {
      console.warn('[AstrePilot] Dynamic dependent field scan warning:', pass2Err);
    }

    // Auto-secure staged credentials into Vault upon successful fill
    if (window.__ap_needs_save && window.__ap_staged_password) {
      try {
        const loginId = (userProfile && userProfile.email) || 'roushan@gmail.com';
        await apFetch('/credentials', {
          method: 'POST',
          body: JSON.stringify({
            siteUrl: window.location.hostname,
            loginId: loginId,
            password: window.__ap_staged_password,
            notes: 'Generated & secured by AstrePilot during application fill'
          })
        });
        window.__ap_needs_save = false;
        console.log('[AstrePilot] Generated credentials secured in Vault for ' + window.location.hostname);
      } catch (e) {
        console.warn('[AstrePilot] Failed to save staged credentials:', e);
      }
    }

    // Gatekeeper / Authentication Step Isolation:
    // If only email, login, or password fields exist, this is an authentication gateway, not a completed application.
    const isGate = isGatekeeperStep(detectedFields, window.location.href);
    if (isGate) {
      console.log('[AstrePilot] Gatekeeper/Login step filled. Withholding application logging and "done" state.');
      
      const loginBtn = findNextStepButton(document) || document.querySelector('input[type="submit"], button[type="submit"], button');
      const btnText = loginBtn ? (loginBtn.innerText || loginBtn.value || 'Log In').trim() : 'Log In';

      if (hud.settings && hud.settings.autoAdvance && loginBtn) {
        hud.setState('transitioning', { step: 'Logging in & loading application form...' });
        try {
          loginBtn.focus();
          loginBtn.click();
        } catch (e) {
          try { loginBtn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true })); } catch (err) {}
        }
        watchForStepTransition(() => {
          rescanFields();
        });
      } else {
        hud.setState('gatekeeper-ready', {
          buttonText: btnText
        });
      }
      return;
    }

    let logRes = null;
    let curSession = getNavSession() || createDefaultNavSession(window.location.href, (activeSession && activeSession.company) || '', (activeSession && activeSession.jobTitle) || '');
    
    // Check if there is an intermediate next step button
    const nextBtn = findNextStepButton(document);
    const hasNext = Boolean(nextBtn);

    // Record step completion in navigational memory
    const historyRecord = {
      stepIndex: curSession.currentStepIndex,
      stepCategory: curSession.stepCategory,
      stepName: curSession.stepName,
      fieldsTotal: detectedFields.length,
      fieldsFilled: filled,
      completedAt: Date.now()
    };

    const existingIdx = curSession.stepHistory.findIndex(s => s.stepIndex === curSession.currentStepIndex);
    if (existingIdx >= 0) {
      curSession.stepHistory[existingIdx] = historyRecord;
    } else {
      curSession.stepHistory.push(historyRecord);
    }

    curSession.cumulativeFieldsTotal = curSession.stepHistory.reduce((sum, h) => sum + h.fieldsTotal, 0);
    curSession.cumulativeFieldsFilled = curSession.stepHistory.reduce((sum, h) => sum + h.fieldsFilled, 0);
    curSession.isFinalStep = !hasNext;
    if (hasNext) {
      curSession.currentStepIndex += 1;
    }
    saveNavSession(curSession);

    try {
      const titleMatch = document.title.match(/(.+?)\s*[|\-]\s*(.+)/);
      const res = await apFetch('/log', {
        method: 'POST',
        body: JSON.stringify({
          siteUrl: window.location.href,
          company: (activeSession && activeSession.company) || (titleMatch ? titleMatch[2].trim() : ''),
          jobTitle: (activeSession && activeSession.jobTitle) || (titleMatch ? titleMatch[1].trim() : ''),
          fieldsTotal: curSession.cumulativeFieldsTotal || detectedFields.length,
          fieldsFilled: curSession.cumulativeFieldsFilled || filled,
          hasAiAnswers: hadAI,
        })
      });
      if (res && res.ok) {
        logRes = await res.json();
        curSession.activeFillId = logRes.fillId || logRes.id || null;
        curSession.activeApplicationId = logRes.applicationId || null;
        saveNavSession(curSession);

        // AstrePilot V3: Self-Learning Schema Cache Telemetry
        if (detectedFields && detectedFields.length > 0 && lastFormFingerprint) {
          try {
            apFetch('/schema-cache', {
              method: 'POST',
              body: JSON.stringify({
                fingerprint: lastFormFingerprint,
                domain: window.location.hostname,
                mappings: detectedFields.map(f => ({
                  id: f.element ? (f.element.id || f.element.name || f.id) : f.id,
                  fieldType: f.type,
                  confidence: f.confidence || 0.90
                })),
                feedback: { success: filled > 0 }
              })
            }).catch(() => {});
          } catch (e) {}
        }
        broadcastSync({
          type: 'APPLICATION_DRAFT_LOGGED',
          timestamp: Date.now(),
          payload: {
            fillId: curSession.activeFillId,
            applicationId: curSession.activeApplicationId,
            siteUrl: window.location.href,
            company: (activeSession && activeSession.company) || '',
            jobTitle: (activeSession && activeSession.jobTitle) || ''
          }
        });
      }
    } catch (e) { /* silent */ }

    if (activeHud !== hud) return;

    if (hasNext) {
      hud.setState('step-complete', {
        stepIndex: curSession.currentStepIndex - 1,
        stepName: historyRecord.stepName,
        stepFieldsFilled: filled,
        cumulativeFilled: curSession.cumulativeFieldsFilled,
        cumulativeTotal: curSession.cumulativeFieldsTotal,
        hasNext: true
      });
    } else {
      hud.setState('done', {
        fillId: logRes ? (logRes.fillId || logRes.id) : curSession.activeFillId,
        applicationId: logRes ? logRes.applicationId : curSession.activeApplicationId,
        fieldsFilled: curSession.cumulativeFieldsFilled || filled,
        fieldsTotal: curSession.cumulativeFieldsTotal || detectedFields.length,
        isConfirmed: false,
      });
    }
  }

  function runUndo() {
    if (!detectedFields) return;
    detectedFields.forEach(f => {
      if (f.originalValue !== undefined) {
        setNativeValue(f.element, f.originalValue);
        f.element.classList.remove('ap-field-active', 'ap-field-done');
      }
    });
    if (activeHud) {
      const hudFields = detectedFields.map(f => {
        const isAI = f.type === 'COVER_LETTER' || f.type === 'SCREENING';
        const preview = resolvePreview(f, userProfile, activeSession);
        return {
          id: f.id,
          type: f.type.toLowerCase().replace(/_/g, ''),
          label: TYPE_LABELS[f.type] || f.type,
          preview: preview || (isAI ? 'AI-generated on fill' : '-'),
          source: isAI ? 'ai' : 'profile',
          status: ''
        };
      });
      activeHud.setFields(hudFields);
      activeHud.setProgress(0, detectedFields.length);
      activeHud.setState('ready');
      activeHud.expand();
    }
  }

  /* -- CONTINUOUS SPA NAVIGATION & DYNAMIC DOM TRANSITION WATCHER -- */
  let lastTrackedUrl = window.location.href;
  let domCheckTimer = null;

  function initSpaNavigationWatcher() {
    // 1. Monkey-patch pushState & replaceState to detect SPA client-side navigations
    if (!history.__ap_patched) {
      const origPush = history.pushState;
      history.pushState = function() {
        const res = origPush.apply(this, arguments);
        handleNavigationChange('pushState');
        return res;
      };
      const origReplace = history.replaceState;
      history.replaceState = function() {
        const res = origReplace.apply(this, arguments);
        handleNavigationChange('replaceState');
        return res;
      };
      history.__ap_patched = true;
    }

    window.addEventListener('popstate', () => handleNavigationChange('popstate'));
    window.addEventListener('hashchange', () => handleNavigationChange('hashchange'));

    // 2. Heartbeat URL check for query/path/hash changes
    setInterval(() => {
      if (window.location.href !== lastTrackedUrl) {
        handleNavigationChange('url_poll');
      }
    }, 600);

    // 3. Continuous MutationObserver to detect dynamic form mounting (e.g. login -> candidate profile)
    const observer = new MutationObserver(() => {
      if (isFilling) return;
      if (domCheckTimer) clearTimeout(domCheckTimer);
      domCheckTimer = setTimeout(() => {
        checkIfNewFormMounted();
      }, 500);
    });

    try {
      observer.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true
      });
    } catch (e) {}
  }

  function handleNavigationChange(source) {
    if (window.location.href === lastTrackedUrl && source === 'url_poll') return;
    console.log(`[AstrePilot] SPA navigation detected (${source}): ${lastTrackedUrl} -> ${window.location.href}`);
    lastTrackedUrl = window.location.href;

    if (!activeHud || isFilling) return;

    if (activeHud.duplicateAlert) {
      activeHud.duplicateAlert = null;
    }

    setTimeout(() => {
      rescanFields();
    }, 400);
  }

  function checkIfNewFormMounted() {
    if (!activeHud || isFilling) return;
    
    // Only auto-wake if currently in done, gatekeeper-ready, step-complete, transitioning, or no-fields
    const wakeableStates = ['done', 'gatekeeper-ready', 'step-complete', 'transitioning', 'no-fields'];
    if (!wakeableStates.includes(activeHud.state)) return;

    // Guard: If currently in 'done', do NOT auto-reset to 'ready' if all previous fields are still attached in DOM and URL hasn't changed!
    if (activeHud.state === 'done') {
      if (window.location.href === lastTrackedUrl && detectedFields && detectedFields.length > 0) {
        const stillAttached = detectedFields.every(f => {
          const doc = (f.element && f.element.ownerDocument) || document;
          return doc.contains(f.element);
        });
        if (stillAttached) return;
      }
    }

    const currentFields = scanFields();
    if (!currentFields || currentFields.length === 0) return;

    // Check if new core application fields are now present using DOM element reference comparison
    const prevElements = new Set((detectedFields || []).map(f => f.element));
    const newFields = currentFields.filter(f => !prevElements.has(f.element));

    // If we were on gatekeeper (1-2 fields) and now 3+ fields exist, or if at least 2 brand new fields appeared
    if ((detectedFields.length <= 2 && currentFields.length >= 3) || newFields.length >= 2) {
      console.log(`[AstrePilot] Real form detected with ${currentFields.length} fields! Transitioning from ${activeHud.state} to ready.`);
      if (activeHud.duplicateAlert) {
        activeHud.duplicateAlert = null;
      }
      applyDetectedFields(currentFields);
    }
  }

  // Zero-Click Token Sync when user is on Stride or AstreWork web app
  const currentHost = (window.location.hostname || '').toLowerCase();
  const isStrideApp = currentHost === 'stride.app' || currentHost.endsWith('.stride.app') || currentHost === 'astrework.app' || currentHost.endsWith('.astrework.app') || currentHost === 'localhost' || currentHost === '127.0.0.1';

  if (isStrideApp) {
    (async function autoSyncStrideSession() {
      try {
        const res = await fetch('/api/autopilot/token', { credentials: 'include' });
        if (res.ok) {
          const data = await res.json();
          if (data && data.token) {
            const token = data.token;
            let candidateSlug = 'roushan';
            try {
              const pRes = await fetch('/api/autopilot/profile', {
                headers: { 'Authorization': 'Bearer ' + token },
                credentials: 'include'
              });
              if (pRes.ok) {
                const pData = await pRes.json();
                candidateSlug = pData.slug || (pData.email && pData.email.includes('ayushi') ? 'ayushi' : 'roushan');
              }
            } catch (e) {}

            const payload = {
              stridepilot_token: token,
              astrepilot_token: token,
              stridepilot_origin: window.location.origin,
              astrepilot_origin: window.location.origin,
              stridepilot_active_context: candidateSlug,
              astrepilot_active_context: candidateSlug,
              stridepilot_candidate_slug: candidateSlug,
              astrepilot_candidate_slug: candidateSlug
            };

            await new Promise((resolve) => chrome.storage.sync.set(payload, resolve));
            if (chrome.storage.local) {
              await new Promise((resolve) => chrome.storage.local.set(payload, resolve));
            }
            console.log('[StridePilot] Zero-Click Token auto-synchronized from active Stride web session for ' + candidateSlug);
          }
        }
      } catch (err) {
        console.debug('[StridePilot] Auto-sync session notice:', err);
      }
    })();

    // Listen for direct sync messages from AstrePilotCard / StridePilotCard
    window.addEventListener('message', async (event) => {
      if (event.data && (event.data.type === 'STRIDEPILOT_TOKEN_SYNC' || event.data.type === 'ASTREPILOT_TOKEN_SYNC') && event.data.token) {
        const token = event.data.token;
        const candidateSlug = event.data.slug || 'roushan';
        const payload = {
          stridepilot_token: token,
          astrepilot_token: token,
          stridepilot_origin: window.location.origin,
          astrepilot_origin: window.location.origin,
          stridepilot_active_context: candidateSlug,
          astrepilot_active_context: candidateSlug,
          stridepilot_candidate_slug: candidateSlug,
          astrepilot_candidate_slug: candidateSlug
        };
        await new Promise((resolve) => chrome.storage.sync.set(payload, resolve));
        if (chrome.storage.local) {
          await new Promise((resolve) => chrome.storage.local.set(payload, resolve));
        }
        console.log('[StridePilot] Token received via web dashboard postMessage and persisted.');
      }
    });

    // On Stride / AstreWork domain, do not auto-mount the job application HUD
    return;
  }

  // Initialize continuous SPA navigation and dynamic DOM observer
  initSpaNavigationWatcher();

  // Auto-launch if we just clicked an apply button or next/continue step and navigated
  if (sessionStorage.getItem('ap_auto_open') === 'true') {
    sessionStorage.removeItem('ap_auto_open');
    setTimeout(async () => {
      await toggleAstrePilotHUD();
      // If dynamic ATS loaded fields with a slight delay, trigger a re-scan
      setTimeout(() => {
        if (activeHud && detectedFields.length === 0 && !isFilling) {
          rescanFields();
        }
      }, 1000);
    }, 1000);
  }

  // Automated Test & Diagnostics Bridge
  window.__STRIDEPILOT_RUN_AUTOFILL__ = runAutofill;
  window.__STRIDEPILOT_TOGGLE_HUD__ = toggleAstrePilotHUD;
  window.__STRIDEPILOT_SCAN_FIELDS__ = scanFields;
  window.__STRIDEPILOT_GET_DETECTED_FIELDS__ = () => detectedFields;
  window.__STRIDEPILOT_GET_HUD__ = () => activeHud;
  window.__STRIDEPILOT_RESOLVE_VALUE__ = resolveValue;
  window.__STRIDEPILOT_FILL_COMBOBOX__ = fillUniversalCombobox;
  window.__STRIDEPILOT_RESOLVE_SCREENING_SELECT__ = resolveScreeningSelect;
  window.__STRIDEPILOT_GET_LABEL_TEXT__ = getLabelText;
  window.__STRIDEPILOT_PROFILES__ = STANDALONE_PROFILES;

  // Backward compatibility globals
  window.__ASTREPILOT_RUN_AUTOFILL__ = runAutofill;
  window.__ASTREPILOT_TOGGLE_HUD__ = toggleAstrePilotHUD;
  window.__ASTREPILOT_SCAN_FIELDS__ = scanFields;
  window.__ASTREPILOT_GET_DETECTED_FIELDS__ = () => detectedFields;
  window.__ASTREPILOT_GET_HUD__ = () => activeHud;
  window.__ASTREPILOT_RESOLVE_VALUE__ = resolveValue;
  window.__ASTREPILOT_FILL_COMBOBOX__ = fillUniversalCombobox;
  window.__ASTREPILOT_RESOLVE_SCREENING_SELECT__ = resolveScreeningSelect;
  window.__ASTREPILOT_GET_LABEL_TEXT__ = getLabelText;
  window.__ASTREPILOT_PROFILES__ = STANDALONE_PROFILES;
})();
})();
